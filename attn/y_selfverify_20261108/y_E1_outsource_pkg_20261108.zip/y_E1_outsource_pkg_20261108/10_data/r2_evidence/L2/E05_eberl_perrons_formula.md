# L2-E05 Eberl Perrons_Formula（2026-06）（Q3·逐字）
来源 URL: https://api.github.com/repos/isabelle-prover/mirror-afp-devel/contents/thys/Perrons_Formula/Perrons_Formula.thy?ref=master
版本锚: mirror-afp-devel master @ f81741033ad5e782a0e0aba461b292ea1c860b3d（2026-11-06）
取件时间: 2026-11-08；文件 1673 行

## 第一显式版（:1208-1222，逐字；作者注 This corresponds to Theorem 2 in §II.2.1 of Tenenbaum's book）
```
theorem perron_effective_strong:
  fixes fds :: "complex fds" and z :: complex and c x T :: real
  assumes c: "c > 0" "ereal c + ereal (Re z) > abs_conv_abscissa f" and T: "T > 0" and x: "x > 0"
  defines "A \<equiv> contour_integral (L c T) (\<lambda>s. eval_fds f (z + s) * of_real x powr s / s)"
  defines "B \<equiv> 2 * pi * \<i> * sum_upto' (\<lambda>n. fds_nth f n / of_nat n powr z) x"
  shows "dist A B \<le> 4 * (arctan (T / c) + pi + 1) * x powr c * perron_bound f (c + Re z) x T"
```
## 推论（:1224-1241，逐字）
```
corollary perron_effective:
  ...
  defines "C \<equiv> 6 * pi + 4"
  shows "dist A B \<le> C * x powr c * perron_bound f (c + Re z) x T"
```
## 第二显式版（:1340-1352，逐字；Tenenbaum Corollary 2.1）
```
theorem perron_effective':
  ...
  defines "C1 \<equiv> 4 * (3 * pi + 2)"
  defines "C2 \<equiv> 2 * (3 * pi + 2) / ln 2 * C"
  defines "C3 \<equiv> (if c + Re s \<ge> 0 then 2 else 1/2 :: real)"
  shows "dist (A x) I \<le>
           C1 * C3 powr (c + Re s) * B (2 * x) / x powr Re s * (1 + x / T * (4 * ln T + 9)) +
           C2 * x powr c * (c + Re s - \<sigma>\<^sub>a) powr (-\<alpha>) / T"
```
判定：**常数真显式**（4(arctan(T/c)+π+1)、6π+4、4(3π+2)、2(3π+2)/ln2·C、(1+x/T·(4lnT+9)) 全部逐字在卷）。第一轮「常数未列=partial」系仅读 abstract 页口径（grade=B），条目内容级不成立。残留 partial 面：承重项 perron_bound f 与入口假设参数 C（假设给定·非推导）。
