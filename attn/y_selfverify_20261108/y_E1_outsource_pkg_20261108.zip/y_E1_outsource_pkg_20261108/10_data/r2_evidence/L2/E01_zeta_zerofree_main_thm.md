# L2-E01 Song–Yao 零点自由区主定理（Q1·逐字）
来源 URL: https://api.github.com/repos/isabelle-prover/mirror-afp-devel/contents/thys/PNT_with_Remainder/Zeta_Zerofree.thy?ref=master
版本锚: mirror-afp-devel master @ f81741033ad5e782a0e0aba461b292ea1c860b3d（commit 2026-11-06T20:40:33Z）
取件时间: 2026-11-08（contents API + Accept: application/vnd.github.raw）
落盘: raw/Zeta_Zerofree.thy（891 行）

## 常数定义（PNT_Notation.thy，全文件 453B）
definition "PNT_const_C\<^sub>1 \<equiv> 1 / 952320 :: real"
（= `PNT_const_C₁ ≡ 1/952320 :: real`；notation C₁ 绑定。PNT_Notation.thy imports "Prime_Number_Theorem.Prime_Counting_Functions"）

## 参数化零点自由区（Zeta_Zerofree.thy:748-750, context zeta_bound_param）
```
theorem zeta_nonzero_region:
  assumes "zeta (Complex \<beta> \<gamma>) = 0" and "Complex \<beta> \<gamma> \<noteq> 1"
  shows "1 - \<beta> \<ge> 1 / 29760 * (\<theta> (2 * \<bar>\<gamma>\<bar> + 1) / \<phi> (2 * \<bar>\<gamma>\<bar> + 1))"
```

## 头条零点自由区定理（Zeta_Zerofree.thy:872-874，逐字）
```
theorem zeta_nonzero_region:
  assumes "zeta (Complex \<beta> \<gamma>) = 0" and "Complex \<beta> \<gamma> \<noteq> 1"
  shows "1 - \<beta> \<ge> C\<^sub>1 / ln (\<bar>\<gamma>\<bar> + 2)"
```
（证明内 :876: `1 / 952320 * (1 / ln (\<bar>\<gamma>\<bar> + 2))`，经 classical_zeta_bound 实例化 θ=1/2、φ=4·ln(12+2·max 0 t)（:789-870），:886 `unfolding PNT_const_C\<^sub>1_def`）

## 语义甄别（逐字链）
- 对象＝ζ 本体：`zeta` 来自 AFP Zeta_Function（Paulson）。依赖链：Prime_Number_Theorem_Library.thy 头部逐字 `imports Zeta_Function.Zeta_Function`；Zeta_Function.thy:174-175 逐字 `definition zeta :: "complex \<Rightarrow> complex" where "zeta = hurwitz_zeta 1"`。
- 形态＝dVp 型（σ ≥ 1 − c/ln 型），非 VK 型（无 log 幂）；**ln(|t|+2) 带偏移，且全 γ 无 |t| 下限**（小 |t| 由 θ=1/2 平凡带与 zeta_nonzero_small_imag 覆盖，:763-774）。
- 方向：`1 − β ≥ C₁/ln(|γ|+2)` ⟺ β ≤ 1 − 1/(952320·ln(|t|+2))。
