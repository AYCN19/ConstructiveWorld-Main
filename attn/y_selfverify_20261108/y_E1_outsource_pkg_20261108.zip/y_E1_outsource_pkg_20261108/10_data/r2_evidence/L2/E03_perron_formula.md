# L2-E03 Song–Yao Perron 公式（Q1·逐字）
来源 URL: https://api.github.com/repos/isabelle-prover/mirror-afp-devel/contents/thys/PNT_with_Remainder/Perron_Formula.thy?ref=master
版本锚: mirror-afp-devel master @ f81741033ad5e782a0e0aba461b292ea1c860b3d（2026-11-06）
取件时间: 2026-11-08

## 截断形主定理（Perron_Formula.thy:920-929，逐字）
```
theorem perron_formula:
  fixes b B H T x :: real and f :: "complex fds"
  assumes Hb: "0 < b" and hT: "b \<le> T"
    and Hb': "abs_conv_abscissa f < b"
    and hH: "1 < H" and hH': "b + 1 \<le> H" and Hx: "0 < x"
    and hB: "(\<Sum>`n \<ge> 1. \<parallel>fds_nth f n\<parallel> / n nat_powr b) \<le> B"
  shows "(\<lambda>s. eval_fds f s * x powr s / s) contour_integrable_on (linepath (Complex b (-T)) (Complex b T))"
        "\<parallel>sum_upto (fds_nth f) x - 1 / (2 * pi * \<i>) *
          contour_integral (linepath (Complex b (-T)) (Complex b T)) (\<lambda>s. eval_fds f s * x powr s / s)\<parallel>
         \<le> x powr b * H * B / T + 3 * (2 + ln (T / b)) * (\<Sum>n | x - x / H \<le> n \<and> n \<le> x + x / H. \<parallel>fds_nth f n\<parallel>)"
```

## 极限形（Perron_Formula.thy:936-942，逐字）
```
theorem perron_asymp:
  fixes b x :: real
  assumes b: "b > 0" "ereal b > abs_conv_abscissa f"
  assumes x: "0 < x" "x \<notin> \<nat>"
  defines "L \<equiv> (\<lambda>T. linepath (Complex b (-T)) (Complex b T))"
  shows   "((\<lambda>T. contour_integral (L T) (\<lambda>s. eval_fds f s * of_real x powr s / s))
               \<longlongrightarrow> 2 * pi * \<i> * sum_upto (\<lambda>n. fds_nth f n) x) at_top"
```
判定：截断形误差项**全显式**（x^b·H·B/T 与 3·(2+ln(T/b))·局部和），对象为一般 Dirichlet 级数 f（非 ζ 专属）；B 为入口假设参数。
