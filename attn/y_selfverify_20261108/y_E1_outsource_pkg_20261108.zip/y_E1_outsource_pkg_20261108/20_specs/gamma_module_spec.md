# γ 模块结构规范（冻结版·v1.0·20261101）

> **宪法从属声明**：本规范系 工单-γ解析核段战役总设计-20261101.md（宪法卷·R1-R6 六律）之 γ0 闸 2 交付件·执行依据＝工单-γ0勘形批详细全景-20261101.md（执行卷）§1.1。R2 计算证明分离律、R3 依赖卫生律在本卷成文为可执行条款；六律冲突处以宪法卷为准。
> **零编译零写树声明**：本席全席零编译（未跑 coqc/coqchk/coqdep）·零树内写入；一切判据为 dep_graph.json（行 14 正本）静态面＋本席工具链重算面。产出仅本沙箱 `kbgamma_work_20261101/`。
> **冻结语义**：本文冻结后，γ1-γ5 施工单的模块布局、文件命名、依赖方向、行数预算、证书面形状**以本卷为唯一结构正本**；改动须走「规范修订案＋主会话裁定」·施工席无权局部变通。

---

## 〇 · 输入三卷实读记录（本席实际读件）

| 卷 | 件 | 实读要点 |
|---|---|---|
| 执行卷 | `跨线资产/分析与工单/工单-γ0勘形批详细全景-20261101.md` | §1.1 本规范规格（85 节点布局/≤400 行谱/R2 证书分离/R3 lint/抽 10 边验收）；§1.2 四稿勘形分簇；§3 派发协议。反验证锚已跑：`grep -c 吸收式`＝**9 ≥3 ✓** |
| 宪法卷 | `跨线资产/分析与工单/工单-γ解析核段战役总设计-20261101.md` | R1-R6 六律（:33-40）；R2 vm_compute 证书化（zzPhi 正形·禁证明体内联巨算）；R3 单向分层/接口模块制/禁互锁对（τ 族闭包互锁教训）；§5.2 单文件 ≤400 行谱（zzPhi merge 2.43× 惩罚线） |
| DAG 正本 | `attn/kbdep_work_20261101/dep_graph.json`（1,439,219 B） | 1010 节点/10010 边/16,724 Require 语句；meta/graph/cycles/families/trio_cross_edges 段全读；`开工-行14依赖解耦施工序-20261101.md` §一（图账节）与 :150「dep_graph.json 为行 14 战役正本」宣告互证 |
| 卡册 | `kbgamma_work_20261101/cards_C1.md`(17)/`cards_C2.md`(18)/`cards_C3.md`(28)/`cards_C4.md`(22 编号卡) | 85 节点名册＋⑤前置节点字段＋②依赖机器字段——本规范布局的节点与依赖唯一来源 |

**DAG 正本位置登记（fail-loud）**：ask 指定路径 `kbgamma_work_20261101/dep_graph.json` **不在**（该领地仅有四段卡册）；实测正本在 `kbdep_work_20261101/dep_graph.json`（行 14 沙箱·施工序 :150 正本宣告）。本席按 ask 预案触发：图账节（施工序 §一）已读·并**直接实读正本 JSON**（优于转抄）。

---

## 一 · 口径裁定（四项·fail-loud 全录·施工席照此执行）

**裁 1（85 节点唯一集·C4 卡册重铸令）**：cards_C4 的 C4.1-01..12（复围道积分定义…Perron 终件）与 cards_C3 的 C3-P01..P12 为**同一 Perron 12 的重复卡**（cards_C3 文件头「⚠ 分段口径异见登记」及尾部「未辖余量名单」两处响亮在案；两卡 ② 字段内容逐点同构）。本规范按宪法卷/执行卷重混口径定谳正典集：**γ3/C3 段 28＝Perron 12（P01-P12·翻转簇吸收式通道）＋dVp 10（Z01-Z10）＋VK 核 6（V01-V06）；γ4/C4 段 22＝VK 残 12＋ψ 显式装配 6（C4.2-01..06）＋常数核算 4（C4.3-01..04）**。由此：①cards_C4 的 C4.1-01..12 四稿**作废重铸**；②**VK 残 12 卡册缺位**——cards_C3 尾部候选细目（W1 Weyl k≥3 合成｜W2 A-过程迭代｜W3 exponent pair 框架件｜W4 ζ 矩估计｜W5 近似函数方程｜W6 ζ′(1+it) Vinogradov 残件｜W7 N(T) 显式界｜W8 Selberg 备选面｜W9-W12 VK 常数核算/证书族 4 件）为本规范 §3.4 预留槽 V07-V18 的初排（该名单自署「最终分解候 γ0《γ 模块结构规范》冻结」——本规范即定谳席·γ4 卡册按 §3.4 槽位重铸）；③cards_C4 头部两张 born 落装卡（CxRealPairCore/ExpLog）**不计入 85**——归 γ5 收尾波（宪法卷 γ5 行正本），但其落装时点按裁 2 提前。

**裁 2（born 落装提前·排程冲突消解案）**：cards_C2.01 ⑤「CxRealPairCore/ExpLog **落装**（born 件·γ5 收尾波前需提前——全段第一前置·排程冲突登记见 notes）」＋cards_C3-P01 ⑤「born 须 γ1 波末落装」——两卡独立指认同一冲突。本规范裁定：**两件 born（CxRealPairCore.v·312 行/48 名/md5 dfcead7d；CxRealPairExpLog.v v2·520 行/18 名/md5 728c7a34·cards_C4 公共基座 B 段实勘账）于 γ1 波末联合认证时落装 Main Live**（R5「每波绿即资产化·后波可消费」正形）；γ5 行的落装席时预算相应前移·总量不变。落装**保名保形不改一字**（born md5 冻结·接口原子性）。

**裁 3（散文前置→机械边·修正语义四条）**：本席以正则机械抽取 85 卡 ⑤ 前置字段得 v1 边表 143 条·Kosaraju 复核出 **3 个二元环**——逐环追查均为**卡内散文语式误析**·非设计环：①「C1-01 ⑤：波内宜最先（**供** C1-02/03/05/06）」——「供」为供出方向·被误析为 C1-01 依赖彼四件；②「C1-16/17 ⑤：毕氏收口块（**与** C1-17/16 **共担**）」——共担非依赖；③「C1-14 ⑤：与 C1-01/C1-04 **可并行起步**」——并行非依赖。修正语义四条（v2/v3 据此）：**「供 X」→ (X, 本节点)**；**「与 X 共担」→ 双方各指共享基元件 G1-PYTH（新增·§3.1）**；**「可并行」→ 无边**；**「可选」→ 不入硬 DAG**。v3 终表 161 边·0 环（§6）。**规范后果**：R3 lint 一律以**机器可解析的 Require 头图**为唯一判据·散文前置表只作勘形参考——本席三版迭代的全部中间产物（v1 三环发现→v2 语义修正→v3 人工精配）留档 `tools/` 为证。

**裁 4（C4.1 重卡边重映射）**：ψ/常数链卡 ⑤ 引「C4.1-12」等重卡编号者·一律**重映射 C3-P 对应号**（C4.2-01/02/04/05→C3-P12 已入终表·tools/gamma_edges_canon.json）；C4.1-* 内部链边整链剔除。施工席消费 Perron 终件时 Require 的正典 stem 为 `GaC3_P12`（§2.2 命名律）。

---

## 二 · 模块布局

### 2.1 层号表（L0-L4·严格单向）

| 层 | 内容 | 形态 | 对 γ 的可见性 |
|---|---|---|---|
| **L0 树基座** | Main Live 既有 1010 件＋Stdlib/外部理论 | 只读（含 γ1 波末落装的 born 两件） | 任何 γ 文件可 `Require Import`·**禁 Export** |
| **L1 = γ1/C1 段** | 17 节点＋共享基元件 G1-PYTH（物理 18 件） | 新铸 | L0 ↓·段内按波 |
| **L2 = γ2/C2 段** | 18 节点 | 新铸 | L0/L1 ↓·段内按波 |
| **L3 = γ3/C3 段** | 28 节点（Perron 12·dVp 10·VK 核 6） | 新铸 | L0/L1/L2 ↓·段内按波 |
| **L4 = γ4/C4 段** | 22 节点（VK 残 12·ψ 6·常数 4） | 新铸 | L0/L1/L2/L3 ↓·段内按波 |
| γ5 落装波 | Main Live 装配＋全段联合认证＋云端 | 非新模块 | — |

**L0 锚登记（本席实存核验·`kbdep_work_20261101/dep_graph.json` 节点名逐一比对）**：S01_BaseRing·S02_CauchyComplete·S03_QExp·S04_RealExpLogConv·S07_RealSetoidExpLog·S10_KVQuantTrig·HansonLcm·abl_Pr_erdos_theta·abl_Pr_erdos_core·piu_zz_ln_rate_bound·piu_zz_pnt_qexp·piu_zz_pnt_rateup·piu_zz_pnt_assembly·piu_zz_tau_enclosure_base **15 锚全 IN-TREE ✓**；CxRealPairCore/CxRealPairExpLog **ABSENT（born 未落装·与卡册两席实勘互证）**。各卡 ② 字段新指锚（如 piu_zz_padic_clearing·Hanson3Pow·piu_zz_pnt_lcmpow 等）落刀前经 LINT-0 锚检（§5）核存后即入本表附录。**命名空间零冲突已验**：拟用 γ 前缀 `Ga*`/`gamma_*` 对 1010 节点名正则扫＝**0 命中**。

### 2.2 命名律

- γ 新铸文件 stem：**`GaC<段号>_<序号>_<Slug>.v`**·例 `GaC1_01_LogMono.v`·`GaC3_P08_PerronCutoff.v`·`GaC4_V07_Weyl3.v`。序号＝§3 波表节点号；Slug 由四稿定（snake→大驼峰·≤24 字符）。
- 三分文件后缀（R2·§4）：证明拓扑面＝stem 本体；证书面＝`<stem>_cert.v`；接口面＝`GaC<段>_Iface_<块>.v`（§2.3）。
- born 两件落装**保留原名** `CxRealPairCore.v`/`CxRealPairExpLog.v`（md5 冻结·裁 2）——不转 Ga 前缀·其行数超谱豁免见 §3.5。
- 禁变更树内既有文件名；γ 文件禁落 `Local/` 子目录（1010 树内唯一例外 LW0LeibSeparation 的口径教训·施工序 §一 1.1）。

### 2.3 接口模块制（R3「接口模块制」成文）

- **形状**：接口模块只含 `Require Import`（本段语句面定稿文件）＋`Require Export` 转供＋语句面具名项索引注释·**零证明体·零定义体**（定义与定理语句仍在各节点文件·Iface 只做名字转供）。
- **分片与扇入帽**：每段按块分片·**每片转供节点数 ≤16**（τ bank4 扇入 125/132 教训·施工序 §一 1.2 实测账）：

| Iface 片 | 转供节点 | 计数 |
|---|---|---|
| GaC1_Iface_Real | C1-01..C1-06 | 6 |
| GaC1_Iface_Cx | C1-07..C1-17＋G1-PYTH | 12 |
| GaC2_Iface_DS | C2.01..C2.05 | 5 |
| GaC2_Iface_Eta | C2.06..C2.10 | 5 |
| GaC2_Iface_VL | C2.11..C2.18 | 8 |
| GaC3_Iface_P / _Z / _V | P01-P12 / Z01-Z10 / V01-V06 | 12/10/6 |
| GaC4_Iface_V / _Psi / _Const | V07-V18 / C4.2-01..06 / C4.3-01..04 | 12/6/4 |

- **产出时点**：Iface 是**波末联合认证交付件**（γ1 波末产 GaC1_Iface_*，γ2 波末产 GaC2_Iface_*，余类推）——Iface 只 Export 已过四关的语句面定稿，禁提前铸空壳。
- **消费规则**：跨段消费者只许 `Require Import GaC<k>_Iface_<块>`；同段跨波消费者走节点 stem 直依（§2.4-②）；**禁跨段直依他段节点 stem**（防 Iface 被绕空·防下游闭包无谓膨胀）。

### 2.4 单向依赖声明（正典六条·违者即互锁·LINT-2 判据）

1. **层向律**：γ 文件的树内 Require 只许指向**更低层**（Lk→Lj·j<k）或 L0；**同级 Require 禁**；**上行 Require（j>k）禁**。
2. **波向律**：同段内 Require 只许指向**更低波号**节点 stem（W_a→W_b·b<a·§3 波表为判据）；**同波互 Require 禁**（并行件互不指名——C1-16/C1-17「共担」教训的正形＝共享件下沉 G1-PYTH）。
3. **跨段 Iface 律**：跨段依赖必经 §2.3 Iface 片；同段禁 Require 他段 Iface 片。
4. **L0 单向律**：γ 文件对 L0 只 `Require Import`；γ 文件 `Require Export` 任何 L0 文件禁（防新伞面）；L0 文件 Require γ 前缀文件禁（命名空间守恒·今日 0 命中为基线）。
5. **伞面禁令**：γ 文件对**同批波件**的 `Require Export`＝0 条（τ 伞 28 边互锁正形为戒——slim→wave1..8 与 wave1..8→bank4 双向各 14 条·trio_cross_edges 实测段·本席复核 `trio_cross_edges` 键值 14+14+0×4）；Iface 片为唯一 Export 豁免位（白名单＝§2.3 表·超表即 LINT-3 fail）。
6. **证书单向律**：`<stem>.v`（证明面）可 Require `<stem>_cert.v` 及更低波 cert；`*_cert.v` Require 证明面文件**禁**（R2 面分离的方向锁·§4）。

---

## 三 · 85 节点波号终表（机械深度法·v3·161 边·0 环）

> 波号 W＝1+max(依赖波号)（Kosaraju+拓扑长链·`tools/gamma_wave_table_canon.txt` 终版）。**层号＝段号，波号＝段内深度**；跨段依赖已计入（如 C4.2-01 W12←C3-P12 W11）。施工按波并行·波末闸见 §5。γ 内边集正本＝`tools/gamma_edges_canon.json`（161 条）。

### 3.1 G1 共享基元件（1 件·L1 附挂）

| 节点 | W | 依赖 | 说明 |
|---|---|---|---|
| G1-PYTH | W1 | L0（S10 三角面） | 毕氏收口块共享件——C1-16/C1-17「与 X 共担」的正形落位（裁 3-②）·C1-16/17 各自 Require 它·互不指名 |

### 3.2 C1 段（17 节点·L1·波跨度 W1-W5）

| W | 节点（依赖） |
|---|---|
| W1 | C1-01（—）·C1-04（—）·C1-07（—·born 补验）·C1-14（—） |
| W2 | C1-02（01）·C1-03（01）·C1-08（07）·C1-10（07,08）·C1-13（07,08）·C1-15（14） |
| W3 | C1-05（01,02）·C1-09（08）·C1-11（10）·C1-12（10）·C1-16（14,15,G1-PYTH） |
| W4 | C1-06（01,05） |
| W5 | C1-17（11,G1-PYTH） |

### 3.3 C2 段（18 节点·L2·波跨度 W1-W7）

| W | 节点（依赖） |
|---|---|
| W1 | C2.01（—·前置 born 落装＝裁 2）·C2.06（—·C1.1 弱依赖经 Iface）·C2.09（—·C1.4 残经 Iface） |
| W2 | C2.02（01）·C2.03（01）·C2.07（01,06）·C2.11（09） |
| W3 | C2.04（02,03）·C2.08（02,07）·C2.12（11）·C2.13（11） |
| W4 | C2.05（02,03,04）·C2.10（07,08,09）·C2.14（11,12） |
| W5 | C2.15（01,14）·C2.16（02,05,07） |
| W6 | C2.17（07,10,16） |
| W7 | C2.18（09,10,12,16,17） |

### 3.4 C3 段（28 节点·L3·波跨度 W1-W11）

| W | 节点（依赖） |
|---|---|
| W1 | P01（—）·P07（—）·Z01（—）·Z02（—） |
| W2 | P02（P01）·P08（P01,P07,Z01）·Z03（Z01,Z02） |
| W3 | P03（P01,P02）·Z04（Z03） |
| W4 | P04（P01,P02,P03）·V01（P01,P02,P03）·Z05（Z01,Z02,Z03,Z04）·Z09（Z04） |
| W5 | P05（P01,P03,P04）·V02（P01,P03,V01）·Z07（P04,Z05） |
| W6 | P06（P04,P05,Z03,Z04）·V03（V01,V02,Z01）·Z06（P05,Z04,Z05） |
| W7 | V04（V01,V02,V03,Z01,Z02,Z03,Z04,Z07）·Z08（Z05,Z06,Z07） |
| W8 | P10（P06,P07,V04,Z03,Z04,Z05）·V05（P05,V04,Z07）·Z10（Z05,Z06,Z08,Z09） |
| W9 | P09（P03,P07,V05,Z06）·V06（V04,V05,Z10） |
| W10 | P11（P08,P09,P10,V05,Z06,Z09） |
| W11 | P12（P11） |

### 3.5 C4 段（22 节点·L4·波跨度 W1-W17·VK 残 12 为预留槽）

| W | 节点（依赖） |
|---|---|
| W1 | C4.3-02（—·C1.1/D1 经 Iface） |
| W7 | V07（C3-V03）·V10（C3-V03）〔预留槽·初排映射＝cards_C3 尾 W1 Weyl/W4 ζ 矩〕 |
| W8 | V08（C3-V01,V07）·V11（C3-V03,C3-V04）·V12（C3-V03,V10）〔W2 A-迭代/W5 近函方/W6 ζ′ 残〕 |
| W9 | V09（C3-V02,V08）·V15（V11）·V16（V12）〔W3 exp pair/W9-W10 常数族〕 |
| W10 | V13（C3-Z06,V09）·V14（C3-V04,V09）〔W7 N(T)/W8 Selberg〕 |
| W11 | V17（V13）·V18（V14）〔W11-W12 常数族〕 |
| W12 | C4.2-01（C3-P12）·C4.2-02（C3-P12）〔←重卡 C4.1-12 重映射·裁 4〕 |
| W13 | C4.2-03（C4.2-01）·C4.2-04（C3-P12,C4.2-01） |
| W14 | C4.2-05（C3-P12,C4.2-01,C4.2-04）·C4.2-06（C4.2-04） |
| W15 | C4.3-01（C4.2-06,C4.3-02） |
| W16 | C4.3-03（C4.2-06,C4.3-01） |
| W17 | C4.3-04（C4.2-04,C4.3-03） |

**预留槽警示（fail-loud）**：V07-V18 的依赖边系本规范**结构初排**（防漏槽·非勘形断言）；γ4 卡册重铸（裁 1-②）时按同法重算·波号以重铸后机械表为准·**只许加深不许上浮**（上浮＝消费未波绿件）。C1-04（Q→real 桥）为全表唯一 γ 内孤立节点——其消费面全在 L2+（经 GaC1_Iface_Real）·形态正确。

---

## 四 · 单文件 ≤400 行谱与 R2 证书分离

### 4.1 行数谱（宪法卷 §5.2 成文）

- **γ 新铸任一 `.v` 文件 ≤400 行**（落刀前行数预算核算＋波末 LINT-6 复测·双闸）。判例锚：zzPhi 叶化 117min 单件→叶中位提速·merge 2.43× 惩罚线（宪法卷 §二.3/§5.2）；born 判例 CxRealPairCore 312 行合规·**CxRealPairExpLog 520 行超谱**——按裁 2 落装豁免（保名保形不改一字）·**新铸件不得效仿**；若其 γ1 补验后需增补，增补走新文件（`CxRealPairExpLog_Ext.v`·≤400）。
- **拆分主轴＝R2 三分**（§4.2）：证明拓扑面（stem）／证书面（`_cert`）／接口面（Iface）天然分文件。**拆分次轴＝波内叶化**：单文件触及 400 行预算时·按引理簇拆 `<stem>_a/_b/...`（同波内互不 Require·经 stem 或下沉件消费——禁 _a↔_b 互锁对）。
- 红线（KB34/KB57 判例）：**积形数字字面量 ≥5000 禁直书证明体**（宪法卷 R2「禁在证明体内联巨算」·回执-KB57:22 积形常数判例）——超线数值一律落 cert 文件字面证书。

### 4.2 R2 计算证明分离（zzPhi 正形成文）

- **证书面 `*_cert.v` 形状**：①字面证书——数值表/样点带/常数界的 `Definition`/`Lemma` 字面量（样点带工艺判例 `piu_zz_ln_rate_bound.v:246-277`）；②验收器——`vm_compute` 闭证的证书核对引理（zzPhi 正形·宪法卷 R2）；③证书文件可含 `vm_compute`/`native_compute`/`Compute`。
- **证明拓扑面 `<stem>.v` 形状**：只留定性推理与拓扑装配·词面 `vm_compute|native_compute|vm_cast_no_check|Compute` **=0**（注释剥除后·LINT-5 grep）；数值事实一律 Require 证书面引理消费。
- **方向锁**：proof→cert 单向（§2.4-⑥）·证书文件禁 Require 同节点证明面。
- **GAPASUME 槽形**：一切常数假设走 Section 变元出节参数化·**零 Axiom/Parameter 全局假设**（正形＝`piu_zz_tau_enclosure_base.v:1214/:1216` HLn_rate_up/lo 槽·cards_C4 工艺 D 段）——四关 `Print Assumptions` 必达 `Closed under the global context`。
- **REPL 冒烟豁免**：秒级 REPL 预演脚本（执行卷 §1.3）不落 `.v`·不占 400 行谱·不进树。

---

## 五 · 互锁 lint 规则（R3 成文·每批必跑）

**执行序**：落刀前→LINT-0/LINT-6 预算核算；**每波落装后→LINT-1..6 全跑**（批内回炉令：任一 fail 即当波回炉·禁带病过波）；波末联合认证→LINT-1..6＋四关四件套（rc=0／语句面具名项计数／PA Closed／coqchk·宪法卷终态判据）。工具：复用 `attn/kbdep_work_20261101/parse_dep_graph.py`（`python -I`·剥嵌套注释后解析 Require 四句式）跑 γ 领地图＋树图合图。

| # | 规则 | 判据（全量化·零解释空间） | 教训锚 |
|---|---|---|---|
| LINT-0 | 锚检 | 新指 L0 锚在树 grep 命中=1·否则停 | born 缺席实勘（CxRealPair 两件 ABSENT） |
| LINT-1 | 环检 | 合图 SCC>1＝0·互 Require 对＝∅ | τ 互锁面 155（施工序 §一 1.2）·本席 v1 三环发现（§6） |
| LINT-2 | 层向/波向 | §2.4-①② 全边核：γ→γ 边 (层,波) 严格降；γ→L0 仅 Import；L0→γ 前缀 grep=0 | §2.4 正典六条 |
| LINT-3 | 伞面禁令 | γ 波件间 `Require Export`=0；Export 白名单=§2.3 Iface 表·逐条实用位普查（消费名 grep≥1·**=0 即删**——段 A 删行案正形·施工序 §三/裁定 1） | τ 伞 28 边（slim→wave 14 Export + wave→bank4 14 Export）·第二伞 zzphi_e_slim_equiv |
| LINT-4 | 扇入帽 | 任一 γ 节点 Export 消费者闭包 ≤16；Iface 消费者闭包 ≤48；超限拆片 | bank 链扇入 125-132（施工序 §一 1.2 实测账） |
| LINT-5 | 证书面纯度 | 非 cert γ 文件 `vm_compute|native_compute|vm_cast_no_check|Compute` 词面=0（剥注释 grep）；cert 文件命中 ≥1 或头注挂「本件无可计算面」声明 | R2·zzPhi 正形·KB72 折价判例 |
| LINT-6 | 行数谱 | γ 任一 `.v` ≤400 行（born 豁免两件除外·裁 2） | zzPhi merge 2.43× 惩罚线 |

**前闸（fail-loud 惯例）**：改写/落装前的消费位普查非 0 即停（段 A 三层验证法·施工序 §三·其 ②「消费位普查＝fail-loud 前置闸」全文适用）。

---

## 六 · 抽 10 边核查记录（验收项·本席实跑）

**方法**：`PYTHONIOENCODING=utf-8 python -I tools/gamma_design_check.py`（本席自铸·只读 dep_graph.json＋roster·报告落 `tools/gamma_design_check.txt` 195 行）＋正典边集 `tools/gamma_edges_canon.json` 复核。全 10 边 PASS。

**全局图基复核（先于抽边）**：本席独立 Kosaraju 重算 1010 节点/10010 边——SCC>1＝**0**·互 Require 对＝**0**·与 JSON `cycles` 段（scc_count_gt1=0·mutual_require_pairs=[]）互证 ✓；`trio_cross_edges` 复核＝hb_wave→tau_enclosure 14 条＋反向 14 条＋s2_headledger 三向 0（伞面互锁形·LINT-3 禁令实据）；slim 出边 18 条 kinds={Export,Import} 与施工序 §一 1.3 一致 ✓。

| # | 边 | 形 | 层·波链 | 核查内容（实跑输出） | 判 |
|---|---|---|---|---|---|
| 1 | C3-P11→C3-P08 | γ内 | L3·W10→W2 | 严格降波=True·回边=False | PASS |
| 2 | C3-P11→C3-Z06 | γ内 | L3·W10→W6 | 同上 | PASS |
| 3 | C3-P11→C3-V05 | γ内 | L3·W10→W8 | 同上 | PASS |
| 4 | C3-P06→C3-Z03 | γ内 | L3·W6→W2 | 同上 | PASS |
| 5 | C3-P08→C3-Z01 | γ内 | L3·W2→W1 | 同上 | PASS |
| 6 | C1-01→S07_RealSetoidExpLog | γ→树锚 | L1·W1→L0 | 锚在树=True·out=6/in=447/dep_closure=6/consumer_closure=595·SCC 单点=True | PASS |
| 7 | C3-Z02→S10_KVQuantTrig | γ→树锚 | L3·W1→L0 | 锚在树=True·out=9/in=419·clos 9/577·单点 | PASS |
| 8 | C3-P12→piu_zz_pnt_qexp | γ→树锚 | L3·W11→L0 | 锚在树=True·out=3/in=3·clos 5/4·单点 | PASS |
| 9 | C4.3-04→piu_zz_tau_enclosure_base | γ→树锚 | L4·W17→L0 | 锚在树=True·out=2/in=4·clos 2/**132**·单点——132=bank 链扇入教训锚·本边只 Import 不 Export（§2.4-④⑤） | PASS |
| 10 | C1-03→abl_Pr_erdos_theta | γ→树锚 | L1·W2→L0 | 锚在树=True·out=3/in=4·clos 3/7·单点 | PASS |

**设计级零互锁结论**（基于上表＋§三终表）：γ 内 161 边 Kosaraju **0 环**（v3 终表·`tools/gamma_wave_table_canon.txt`）·抽样边全部严格降波·树锚边全部单向指向 L0 单点·无一同态于 τ 伞互锁形（双向 Export 伞/互 Require 对/自环）。

**诚实附记**：①JSON `closures` 段为聚合账（无逐节点闭包清单）——「锚闭包 γ 前缀直查」未执行·以**命名空间零冲突**（Ga*/gamma_* 对 1010 节点=0 命中）＋LINT-2 前向闸代偿·如实登记；②§三波表系散文前置机械抽取（v1 三环→修正语义→v3 终表）·**区间记法前置（如 P08 卡「P01-P07」）未展开→波号为下界**——落刀时真 Require 图以 LINT-1 复测为准·波表冲突时**加深不浅化**；③零编译——四关四件套全数未跑·属施工席义务（执行卷 §1.3 冻结令）。

---

## 七 · 反验证锚

```bash
ls "D:/ComplexAnalysis/attn/kbgamma_work_20261101/gamma_module_spec.md"          # 本规范在盘
grep -c "LINT-" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/gamma_module_spec.md"  # ≥6（lint 七条目）
grep -c "GaC"  "D:/ComplexAnalysis/attn/kbgamma_work_20261101/gamma_module_spec.md"   # ≥10（接口片命名）
PYTHONIOENCODING=utf-8 python -I "D:/ComplexAnalysis/attn/kbgamma_work_20261101/tools/gamma_design_check.py"  # 复跑零环复核
PYTHONIOENCODING=utf-8 python -I "D:/ComplexAnalysis/attn/kbgamma_work_20261101/tools/gamma_extract.py"       # 名册复抽 17/18/28/22
ls "D:/ComplexAnalysis/attn/kbdep_work_20261101/dep_graph.json"                  # DAG 正本在盘（行 14 战役正本）
```

**留档产物清单（本席落盘）**：`gamma_module_spec.md`（本件）｜`tools/gamma_extract.py`＋`gamma_roster.json(.txt)`（85 名册）｜`tools/gamma_design_check.py`＋`gamma_design_check.txt`（195 行核查报告）｜`tools/gamma_edges_v2.json`（机械修正版 151 边）｜`tools/gamma_edges_canon.json`（正典 161 边）｜`tools/gamma_wave_table_canon.txt`（终表）｜`tools/c3_tail2.txt`（VK 残 12 候选名单转录）。

---

## 八 · 本席未做（如实）

- **零编译**：未跑 coqc/coqchk/coqdep/Print Assumptions——四关四件套为 γ1+ 施工席义务；本卷一切判据为静态图面。
- **逐节点闭包 γ 前缀直查未执行**：JSON closures 段无逐节点清单（§6 诚实附记①）·以命名空间零冲突＋LINT-2 代偿。
- **VK 残 12 卡册未铸**：V07-V18 仅有结构槽位与初排依赖（§3.5 警示）·数学命题卡/四稿归 γ4 卡册重铸（裁 1-②·候主会话裁定归属后派工）。
- **网络零访问**：未 fetch AFP/mathlib 任何先例件——R4/fetch-before-cite 归勘形员与施工席·本席 ⑦ 检索词未引任何断言。
- **C2.01 排程冲突消解案（裁 2）未获主会话印可**：本席按 R5 律裁定·登记候印；若裁定驳回（born 仍 γ5 落装）·则 γ2/C2 段全体波号顺移·规范 v1.1 重冻。
