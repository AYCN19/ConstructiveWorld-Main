# γ2/C2 段四稿勘形稿（drafts_C2.md·20261101·勘形员·C2）

> **宪法从属声明**：本稿系 工单-γ解析核段战役总设计-20261101.md（宪法卷·R1-R6）＋工单-γ0勘形批详细全景-20261101.md（执行卷 §1.2 R1 四稿律）辖下 γ0 勘形批 C2 段交付件。《γ 模块结构规范》冻结版 v1.0（kbgamma_work_20261101/gamma_module_spec.md）为唯一结构正本：文件命名/波号/Iface/单向依赖/≤400 行谱/R2 证书分离/LINT 七条全文适用；本稿语句面稿按规范 §2-§4 布局·红线路径 A（纯构造性纲领与红线律白皮书 v2.5 裁决七：一切具名构造 Set 承载·谓词位 QltT/QeqT·内嵌位零 Prop·Prop 语句零新铸·零 Axiom/Parameter）。
> **纪律执行声明**：零编译（未跑 coqc/coqchk/coqdep/REPL——REPL 预演只出脚本不执行·>60s 编译形态禁入）·零 Main 树写（本稿＋_c2fetch 取回件均落 kbgamma_work_20261101 沙箱）·fetch-before-cite（§一台账 9 发·先证后引）·禁猜 ID（§二核验台账：树内锚逐一本席 grep/sed 复验；未复验面一律标「落刀前 LINT-0」）·三档禁降档（C2 段三档分布 翻转后判词按吸收式映射表维持·不因四稿降档）·fail-loud（§六未做/未验全录）。

---

## 〇 · 分簇定谳（C2 段 18 节点）

**分簇判据**：吸收式映射表（勘形-γ段DAG重估-吸收式-20261101.md §①-3）四行组与 C2 四组双射：

| 映射表行 | C2 节点 | 先例件 | 系数 | 稿型 |
|---|---|---|---|---|
| 行 1-2「Dirichlet 级数半平面收敛 2」 | C2.01-C2.02 | mathlib LSeries/Convergence.lean（6,936B） | 0.30 | 翻转簇·吸收式四稿 |
| 行 3-5「Euler 乘积 3」 | C2.03-C2.05 | mathlib NumberTheory/EulerProduct/ 三件（21,835B＋14,082B＋2,009B） | 0.35 | 翻转簇·吸收式四稿 |
| 行 6-10「η 交错延拓 5」 | C2.06-C2.10 | LSeries/DirichletContinuation.lean（19,341B）＋RiemannZeta.lean（12,256B） | 0.45 | 翻转簇·吸收式四稿 |
| 行 11-18「竖线增长界 8」 | C2.11-C2.18 | Complex/PhragmenLindelof.lean＋BorelCaratheodory.lean＋Hadamard.lean | 0.50 | 翻转簇·吸收式四稿 |

**定谳**：C2 段 **18/18 全翻转簇·维持簇 0**（执行卷 §1.2 维持簇清单〔VK 层/C4.3/C4.2/Cx〕零节点落 C2）。段加权系数 ≈0.44（映射表 §①-3 加权原值）·与「吸收式 16/32/48 席时」行对应·**判词不因四稿降档**。
**口径注（响亮登记）**：映射表 §①-3 标题作「C2 经典线 15 节点＋η 补勘 5 节点」（15+5=20≠18）——本席按行号实覆盖 18 节点双射定谳·标题算术系笔误·不影响覆盖与系数。
**依赖正典**：全部按规范 §3.3 波表（v3·161 边正本 tools/gamma_edges_canon.json）·卡册 ⑤ 散文前置只作参考·冲突时以波表为准（规范 §六诚实附记②）。
**双射对表**：每稿挂全景卡编号（全景卡-γ解析核段85节点-20261101.md 第二段·行 336-526）。

---

## 一 · fetch 台账（fetch-before-cite·本席亲跑 9 发·零断言无来源）

| # | 件 | 通路 | 实测 | 取回要点（语句面） |
|---|---|---|---|---|
| F1 | mathlib `Analysis/Complex/PhragmenLindelof.lean` | WebFetch raw.githubusercontent（一次成） | 取回全文 | `horizontal_strip`/`eq_zero_on_horizontal_strip`/`eqOn_horizontal_strip`/`vertical_strip`/`eq_zero_on_vertical_strip`/`eqOn_vertical_strip`/`quadrant_I..IV`×3 形/`right_half_plane` 4 形；辅件 `isBigO_sub_exp_exp`/`isBigO_sub_exp_rpow`；**增长限制形＝∃c<π/(b−a),∃B, f=O[z↦exp(B·exp(c·\|im z\|))]（双指数形）**·结论逐点 ‖f z‖≤C |
| F2 | mathlib `Analysis/Complex/BorelCaratheodory.lean` | WebFetch raw.githubusercontent（一次成） | 取回全文 | `Complex.borelCaratheodory`：‖f z‖≤2M‖z‖/(R−‖z‖)＋‖f 0‖(R＋‖z‖)/(R−‖z‖)（零中心·ball 0 R·Re f≤M）；`borelCaratheodory_zero` 零中心简化形；辅件四条 `eq_mul_div_one_add_of_eq_div_sub`/`norm_two_mul_div_one_add_le`/`norm_le_norm_two_mul_sub`（Re z≤M ⇒ ‖z‖≤‖2M−z‖）/`schwarz_applied`（Schwarz 变换 g:=f/(2M−f)·‖g‖≤(1/R)‖z‖） |
| F3 | mathlib `NumberTheory/LSeries/Convergence.lean` | WebFetch ×2 ECONNRESET→curl raw ×1 超时（exit 28）→**GitHub contents API base64 成**（6936B） | Conv.lean 在 `_c2fetch/` | `LSeries.abscissaOfAbsConv`（EReal 下确界定义）；`abscissaOfAbsConv_le_of_le_const_mul_rpow`（‖f n‖≤C·n^x ⇒ 横坐标≤x+1）；`abscissaOfAbsConv_le_of_le_const`；`LSeriesSummable_of_abscissaOfAbsConv_lt_re`；`summable_real_of_abscissaOfAbsConv_lt`；`abscissaOfAbsConv_binop_le` |
| F4 | mathlib `NumberTheory/EulerProduct/Basic.lean` | contents API（21,835B·与映射表①-0 字节数咬合） | EulBasic.lean 在 `_c2fetch/` | **`prod_primesBelow_tsum_eq_tsum_smoothNumbers`（∏_{p<N}(1−f p)⁻¹=Σ_{N-光滑}f·有限恒等式直系）**；`summable_and_hasSum_smoothNumbers_prod_primesBelow_tsum/_geometric`；**`norm_tsum_smoothNumbers_sub_tsum_lt`（∃N₀∀N≥N₀·‖Σ'−Σ_{smooth}‖<ε·显式尾界）**；`eulerProduct_hasProd`/`eulerProduct`（部分乘积列 Tendsto 形）/`eulerProduct_tprod`；完全乘性版 `eulerProduct_completely_multiplicative*` 三形＋`one_sub_inv_eq_geometric_of_summable_norm`；`Summable.norm_lt_one` |
| F5 | mathlib `NumberTheory/EulerProduct/ExpLog.lean` | contents API（2,009B·咬合） | EulExpLog.lean 在 `_c2fetch/` | `EulerProduct.exp_tsum_primes_log_eq_tsum`（exp(Σ'−log(1−f p))=Σ' f n·对数版乘积）；辅件 `Summable.clog_one_sub` |
| F6 | mathlib `NumberTheory/EulerProduct/DirichletLSeries.lean` | contents API（14,082B·咬合） | EulDirich.lean 在 `_c2fetch/` | `riemannZeta_eulerProduct`/`_tprod`/`_hasProd`（∏_{p<n}(1−p^{-s})⁻¹→ζ(s)·1<re s）；`summable_riemannZetaSummand`/`tsum_riemannZetaSummand`；Dirichlet L 版三形；`LSeries_zeta_eulerProduct_exp_log` |
| F7 | mathlib `NumberTheory/LSeries/DirichletContinuation.lean` | contents API（19,341B·咬合） | DirCont.lean 在 `_c2fetch/` | `DirichletCharacter.LFunction`（Hurwitz zeta 线性组合定义）；**`LFunction_eq_LSeries`（1<re s 重合语句形）**；`differentiableAt_LFunction`（s≠1∨χ≠1）；`differentiable_LFunction`；`LFunctionTrivChar_eq_mul_riemannZeta`；`deriv_LFunction_eq_deriv_LSeries`；`LFunction_changeLevel` |
| F8 | mathlib `NumberTheory/LSeries/RiemannZeta.lean` | contents API（12,256B·咬合） | RiemZeta.lean 在 `_c2fetch/` | **`riemannZeta := hurwitzZetaEven 0`（非 η-商路！）**；`differentiableAt_riemannZeta`（s≠1）；`riemannZeta_eq_completedRiemannZeta₀`；FE 组（`completedRiemannZeta₀_one_sub` 等）；`zeta_eq_tsum_one_div_nat_add_one_cpow`（1<re s 级数形） |
| F9 | mathlib `Analysis/Complex/Hadamard.lean` | contents API（30,700B·与映射表①-0 咬合） | Hadamard.lean 在 `_c2fetch/` | **`norm_le_interp_of_mem_verticalClosedStrip₀₁'`：hz∈闭条带＋DiffContOnCl＋BddAbove＋边界界 a/b ⇒ ‖f z‖≤a^(1−re z)·b^(re z)**；主形 `norm_le_interpStrip_of_mem_verticalClosedStrip₀₁`（interpStrip 承载）；辅件 `sSupNormIm` 族（竖线 sup 面）/`norm_le_sSupNormIm`/`F_edge_le_one`/`interpStrip_eq_of_pos/of_zero` |

**取回通路勘误（响亮）**：①raw.githubusercontent.com 本席 WebFetch 间歇 ECONNRESET、curl 超时（exit 28）——改道 GitHub contents API（api.github.com·base64）全部成；②映射表 §①-0 记「LSeries/Convergence.lean」「EulerProduct/」未带全径——实径分别为 `Mathlib/NumberTheory/LSeries/Convergence.lean` 与 `Mathlib/NumberTheory/EulerProduct/`（`Mathlib/Analysis/LSeries/` 不存在·本席 404 实录·tree API `truncated:False` 全树复核唯三 EulerProduct 文件在 NumberTheory 下）。字节数与映射表①-0 逐件咬合（6936/21835/2009/14082/19341/12256/30700）——先例件未变·仅路径转正。
**网络纪律**：contents API 逐发间隔 ≥15-30s（单飞退避）；零截断回执；取回件落 `_c2fetch/`（只读参照·未执行任何包内代码）。

---

## 二 · 树内锚核验台账（禁猜 ID·本席亲跑 grep/sed·20261101）

| 锚 | 命令（本席实跑） | 实测 |
|---|---|---|
| born 两件 | `ls attn/kb36_work_20261027/*.v` | CxRealPairCore.v/CxRealPairExpLog.v 在（born 未落装·Main Live 无——裁 2 γ1 波末落装后 L0 可消费） |
| Cx 承载 | sed Core :27/:33/:36-53 | `Definition Cx : Set := Real * Real`（:27）·`c_eq`（:33）·`c_zero/c_one/c_of_Q/c_plus/c_opp/c_mult/c_conj/c_norm_sq`（:36-:53） |
| Real 承载 | sed S02 :40/:392/:397/:468/:48/:49/:99 | `Qseq:=nat->Q`（:40）·`cauchy`（:392）·`Real : Set := sigT (fun u : Qseq => cauchy u)`（:397）·`real_lt`（:468·sigT eps＋QltT＋sigT N 形）·`QltT`（:48）/`QleT`（:49）/`QleT'`（:99） |
| S02 实算面 | grep S02 | `real_plus`:404·`real_opp`:442·`real_zero`:460·`real_le`:472·`real_mult`:650·`real_const`:859·`real_one`:2301 |
| 实指数/对数 | sed S07 :3550/:3653/:5498/:5541/:7881；S03 :6442 | `exp_upper_lipschitz_q`:3550·`exp_lower_lipschitz_q`:3653·`cw_log`:5498·`cw_log_exp_right`:5541·`real_log`:7881（=cw_log）·S03:6442=`cauchy_real_exp_pos`（卡内「exp_pos」实名） |
| born 指数面 | grep ExpLog 具名项 | `c_exp`:104·`c_exp_zero`:108·`c_exp_conj`:123·`c_exp_plus`:165·`c_scale`:211·`c_log`:214（r th Hr 形）·`c_exp_c_log`:217·`c_log_mult`:249·`c_norm_sq_zero_intro/elim`:262/:379；**模公式 \|e^z\|=e^{Re z} 零现役**（c_norm_sq 系仅 5 命中·C2.01 自铸义务坐实）；**周期性面 18 名零命中**（C2.09 缺口坐实） |
| nat 侧先例 | sed abl_Pr_erdos_theta :101/:197；tau :1214/:1216；ln_rate :246/:277 | `pec_prim`:101·`pec_theta_bound`:197·`HLn_rate_up/lo` Hypothesis sigT 槽形 :1214/:1216·`zz_ln_up_ok`:246＋`zz_up_big_all_true`:277（vm_compute 证书判例） |
| FTA/枚举面 | ls＋grep | HansonLcm.v/Hanson3Pow.v/S04_RealExpLogConv.v/piu_zz_pnt_winsum.v/piu_zz_pnt_qexp.v 在树；`pec_win`（abl_Pr_erdos_core :9/:24/:30 注释面＋theta :101 消费）；**`pr_prime_bool` 本席 grep 零命中**——卡内指认未复验·落刀前 LINT-0（C2.03 稿内登记） |
| nat 侧 Euler | sed abl_Pr_euler_prod :1-20＋具名 | 素数域第 8 件·`pze_O1`/`pze_euler_harm` 有限版·`pze_sumf_*` 有限和族 :95-:178——C2.03/C2.04 nat 有限和承载件形参照（L0 锚新增登记·LINT-0 过：本席实读） |
| 命名空间 | 规范 §2.1（Ga*/gamma_* 对 1010 节点 0 命中）＋本席 `GaC2_` 新缀 | 零冲突沿规范判词·本席拟名 `GaC2_01..18_*` 全新缀 |

---

## 三 · 通用件（各稿引用·免逐节点重复）

### 3.1 文件头样板（每节点语句面稿首部）

```coq
(* GaC2_NN_Slug.v —— γ2/C2 段 L2·Wκ
   挂卡：全景卡-γ解析核段85节点-20261101.md 第二段 C2.NN
   先例件：F#（研读卡见 drafts_C2.md）·吸收系数 0.XX·证明物零移植（红线）
   R2：证明拓扑面·vm_compute|Compute 词面=0；数值证书在本节点 _cert.v
   依赖正典：spec §3.3 Wκ 行（Ga 内边集 tools/gamma_edges_canon.json） *)
```

### 3.2 Require 头分层样板（L2 合法指向·LINT-2 判据）

- L0（Import 禁 Export）：`S02_CauchyComplete`（Real/real_lt/real_eq/QltT/QleT'/real_plus/mult/le/const）·`S03_QExp`·`S04_RealExpLogConv`·`S07_RealSetoidExpLog`（real_log/cw_log 系）·`CxRealPairCore`/`CxRealPairExpLog`（born·裁 2 γ1 波末落装后为 L0）·`QArith_base` 等 stdlib。
- L1 经 Iface：`GaC1_Iface_Real`（C1-01..06 实有效界/实幂）·`GaC1_Iface_Cx`（C1-07..17＋G1-PYTH·收敛机/ExpLog 残/周期归约）——**禁 Require 他段节点 stem·禁 Require 他段 Iface（§2.4-③）**。
- 同段低波直依：`GaC2_MM_Slug`（MM<NN·§2.4-②）。
- 证书面：`GaC2_NN_Slug_cert`（proof→cert 单向·§2.4-⑥）。

### 3.3 证书面样板（R2·zz_ln 判例 piu_zz_ln_rate_bound.v:246/:277 正形）

```coq
(* GaC2_NN_Slug_cert.v —— 证书面
   ① 字面证书：常数/样点带 Definition（字面量·积形 ≥5000 禁直书证明体）
   ② 验收器：vm_compute 闭证核对引理（zzPhi 正形） *)
Definition zz_<name>_ok (样点变元) : bool := ...   (* 字面判据 *)
Theorem zz_<name>_all_true : zz_<name>_all = true.  (* vm_compute 闭证 *)
```
无可计算面节点：cert 文件头注挂「本件无可计算面」声明（LINT-5 豁免条）。

### 3.4 REPL 预演脚本样板（稿三·秒级冒烟·**本席不执行**·执行卷 §1.3 豁免条款）

```coq
(* REPL 冒烟·预计秒级·不落 .v 不占 400 行谱·>60s 即停改脚本形态 *)
Require Import GaC2_NN_Slug.
Check <具名项>.        (* 逐语句面项·核对类型形状 *)
Print Assumptions <主语句>.  (* 期待：Closed under the global context *)
```

### 3.5 验收判据基座（稿四·四关四件套＋LINT·宪法卷终态判据）

每节点稿四＝基座五条＋节点专判：
1. **rc=0**：coqc 零错零警（施工席执行·本席零编译）。
2. **语句面具名项计数**：稿二列名数与 `Print` 面逐项对表（缺一即回炉）。
3. **Print Assumptions 全 Closed**：一切具名项 `Closed under the global context`（GAPASUME 槽形·Section 变元出节参数化·零 Axiom/Parameter）。
4. **coqchk 过**。
5. **LINT-0..6**：锚检/环检/层向波向/伞面/扇入帽/证书面纯度/≤400 行（判据见规范 §五）。
节点专判逐稿列（语句名清单·证书值·判据数值）。

### 3.6 语句面稿措辞约定

稿二 Coq 块为**勘形形**（语句与接口定形·证明体另稿·`(* 证: ...路线 *)` 注记路线）：落刀前经 LINT-0 树面对表微调；`Hypothesis`/`Variable` 均为 Section 局部（出节消解·GAPASUME 槽形）；存在性结论一律 sigT 见证形（路径 A·禁裸 Prop 语句）；模长比较以 `c_norm_sq`（模平方）承载·零开方依赖。

---

## 四 · 逐节点四稿

### C2.01 〔翻转簇·系数 0.30·W1〕GaC2_01_DirichletPartialSum

**挂卡**：全景卡 第二段 C2.01（行 336-344）｜**依赖正典**：无 γ 内前置（spec §3.3 W1：C2.01（—·前置 born 落装＝裁 2））｜**卡三档**：1.5/2.5/4 席时（转录档）

**稿一·先例研读卡**
- 先例件：F8（RiemZeta.lean）语句面 `zeta_eq_tsum_one_div_nat_add_one_cpow`（ζ 级数形·1<re s）；F6（EulDirich.lean）`summable_riemannZetaSummand`/`tsum_riemannZetaSummand`（Σ' 1/n^s 承载形）；F3（Conv.lean）`LSeries.term_def` 面（级数项定义位）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F8 `zeta_eq_tsum_one_div_nat_add_one_cpow`（ζ=Σ'(n+1)^{-s}·Re s>1） | `c_powq`（n^{-s}:=exp(−s·ln n)）＋`c_zeta_part` 有限和承载 | **语句面对表**：级数项形状 (n+1)^{-s}↔n^{-s}·零基偏移按卡设 |
| F6 `tsum_riemannZetaSummand`（ζ(s)=Σ' n^{-s}·1<re s） | `c_zeta_part_tail_eq`（尾差=块和） | 语句面对表（有限和代数·零极限面） |
| F3 `LSeries.abscissaOfAbsConv` 定义面 | 不吸收（EReal 下确界承载·树内无） | 登记承载差：树内收敛承载形=C1-14 柯西列形（经 GaC1_Iface_Cx） |

- **吸收边界（禁吸清单）**：①先例建在 mathlib 完整复分析/L-Series 基建上——证明物零移植（KB34:104 红线一）；②`LSeries` 类型族/`Summable` 经典承载禁直用——Set 承载重铸全价；③本节点为纯定义/代数档·研读对表只取**语句面形状**（系数 0.30 依据原文「小件全读·语法差最低档」）。

**稿二·语句面稿（语句面 ≈55 行预算）**

```coq
Require Import QArith_base.
Require Import S02_CauchyComplete.        (* L0: Real/real_lt/real_eq/real_plus/mult/const *)
Require Import S07_RealSetoidExpLog.      (* L0: real_log（:7881 本席复验） *)
Require Import CxRealPairCore.            (* L0 born·裁 2: Cx/c_plus/c_mult/c_opp/c_norm_sq/c_eq *)
Require Import CxRealPairExpLog.          (* L0 born·裁 2: c_exp/c_scale/c_exp_plus/c_exp_c_log *)

Definition c_of_real (r : Real) : Cx := (r, real_zero).        (* Real→Cx 嵌入·对=零 *)
Definition nat_real (n : nat) : Real := real_const (Qof_nat n).

Section DirichletPartialSum.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).  (* 义务 L1·S03 正性面装配 *)

(* n^{-s} := c_exp(−s·ln n)·ln n=树 real_log（卡 ① 原式） *)
Definition c_powq (n : nat) (s : Cx) : Cx :=
  c_exp (c_scale (real_opp real_one)
           (c_mult s (c_of_real (real_log (nat_real n) (Hnpos n))))).

Fixpoint c_zeta_part (N : nat) (s : Cx) : Cx :=            (* ζ_N(s):=Σ_{n≤N} n^{-s} *)
  match N with
  | O => c_zero
  | S m => c_plus (c_zeta_part m s) (c_powq (S m) s)
  end.

Fixpoint c_tail (M N : nat) (s : Cx) : Cx :=               (* Σ_{M<n≤N} n^{-s} *)
  match N with
  | O => c_zero
  | S m => c_plus (c_tail M m s)
             (if Nat.ltb M (S m) then c_powq (S m) s else c_zero)
  end.

Lemma c_powq_plus_law : forall (n : nat) (s w : Cx),       (* (a) 指数加法律 *)
  c_eq (c_mult (c_powq n s) (c_powq n w)) (c_powq n (c_plus s w)).
(* 证: c_exp_plus＋c_mult/c_log_mult 转写·KB36 坑卡 sigT 归约律/Qeq 禁直接压阵（卡 ③） *)

Lemma c_powq_norm_sq : forall (n : nat) (s : Cx),          (* (b) 模公式·norm_sq 承载 *)
  real_eq (c_norm_sq (c_powq n s))
          (cRe (c_powq n (c_of_real (real_plus (cRe s) (cRe s))))).
(* 证: c_exp_conj＋c_exp_plus＋c_norm_sq 代数三步自铸（卡 ③·树内无现成件·§二台账坐实） *)

Lemma c_zeta_part_tail_eq : forall (M N : nat) (s : Cx),   (* (c) 尾差公式 *)
  c_eq (c_plus (c_zeta_part N s) (c_opp (c_zeta_part M s))) (c_tail M N s).
(* 证: 双 Fixpoint 归纳·纯有限和代数 *)

End DirichletPartialSum.   (* 出节后三引理带 Hnpos 参数·零全局假设 *)
```

- **证书面** `GaC2_01_DirichletPartialSum_cert.v`：头注挂「本件无可计算面」声明（纯定义/代数·LINT-5 豁免条）。
- **证明义务清单**：L1 `Hnpos` 供给（real_const 正性·S03 正性面）；L2 `c_exp_c_log` 语义对表（c_log 极坐标语义·ExpLog:217 语句面已核·落刀时核对 ln n 经 c_of_real 直嵌形与卡 ① 原式咬合）。
- **R2/路径 A 自检**：语句面零 vm_compute 词面 ✓·零 Axiom/Parameter ✓·谓词位 real_lt/real_eq/c_eq 全 Set 形 ✓·零 Prop 语句 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_01_DirichletPartialSum.
Check c_powq.  Check c_zeta_part.  Check c_tail.
Check c_powq_plus_law.  Check c_powq_norm_sq.  Check c_zeta_part_tail_eq.
Print Assumptions c_powq_plus_law.   (* 期待：Closed under the global context *)
```

**稿四·验收判据**
- 基座五条（§3.5）全跑。
- 专判①：语句面具名项＝7（c_of_real/nat_real/c_powq/c_zeta_part/c_tail/三 Lemma）·计数对表。
- 专判②：模公式语句与卡 ①(b)「\|n^{-s}\|=n^{-σ}」咬合（norm_sq² 承载差登记：本稿给平方形·消费侧用平方比较·零开方）。
- 专判③：born 落装时点闸——本件 Require CxRealPair 两件·**γ1 波末联合认证（裁 2）前禁落刀**（否则 LINT-0 锚检 fail）。

---

### C2.02 〔翻转簇·系数 0.30·W2〕GaC2_02_AbsConvTailBound

**挂卡**：全景卡 第二段 C2.02（行 346-354）｜**依赖正典**：C2.01（spec §3.3 W2）｜**卡三档**：2/3.5/5

**稿一·先例研读卡**
- 先例件：F3（Convergence.lean·6,936B 全读）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F3 `LSeries.abscissaOfAbsConv_le_of_le_const_mul_rpow`（‖f n‖≤C·n^x ⇒ 绝对收敛带） | `zeta_part_cauchy_bound`（尾界显式 → Cauchy）·系数面「\|n^{-s}\|≤n^{-σ}（σ>1）+ 凝聚尾」同构 | **路线对表**：先例以 O(n^x) 压横坐标；本节点以显式凝聚尾界给 Cauchy 见证——语句形（尾界命名引理供全段消费）直接对表 |
| F3 `LSeriesSummable_of_abscissaOfAbsConv_lt_re`（横坐标右侧可和） | 「一致形」(c) σ≥σ₀ 代入一致成立 | 语句面对表（σ₀ 参化一致形） |
| F3 `abscissaOfAbsConv_le_of_le_const` | 不吸收（有界 f 特款·非本节点） | — |

- **吸收边界**：①`Summable`/`EReal`/`sInf` 经典承载禁直用（Set 承载重铸：Cauchy 列形＝C1-14 承载定形·接口对表义务在案）；②凝聚分组归纳（nat 强归纳）为树内新铸·先例零对应（先例走分析收敛定理·树内零积分判别法——卡 ② 核心勘形点原样保留）。

**稿二·语句面稿（语句面 ≈70 行预算）**

```coq
Require Import QArith_base.
Require Import S02_CauchyComplete.
Require Import S07_RealSetoidExpLog.
Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_01_DirichletPartialSum.            (* 同段 W1 直依·§2.4-② *)
(* C1.4 收敛机承载定形＝接口对表义务（卡 ⑤·非内容依赖·不 Require） *)

Section AbsConvTailBound.
Variable sig : Real.                                    (* σ *)
Variable Htwo : real_lt real_zero (nat_real 2).         (* 义务：2>0 见证 *)
Hypothesis Hsig1 : real_lt real_one sig.                (* σ>1 *)

(* 2^t := exp(t·ln 2)·常数幂承载（零分支） *)
Definition r_two_rpow (t : Real) : Real :=
  cRe (c_exp (c_scale t (c_of_real (real_log (nat_real 2) Htwo)))).

(* 几何闭式常数 1+2^{1−σ}/(1−2^{1−σ})·除法走 sigT 见证形 *)
Variable Hden : { d : Real & real_lt real_zero d &
  real_eq d (real_plus real_one (real_opp (r_two_rpow (real_plus real_one (real_opp sig))))) }.
Definition r_geom_den : Real := projT1 Hden.
Definition r_geom_const : Real :=
  real_plus real_one
    (cRe (c_mult (r_two_rpow (real_plus real_one (real_opp sig)))
                  (c_inv_wit (projT2 Hden)))).   (* c_inv_wit：C2.01 补铸·sigT 逆元见证 *)

Lemma q_condensation_block : forall (k : nat),          (* (a) 二进块界 *)
  real_le (cRe (c_tail (2^k) (2^(S k)) (c_of_real sig)))
          (cRe (c_powq (2^k) (c_of_real (real_plus real_one (real_opp sig))))).
(* 证: Σ_{2^k<n≤2^{k+1}} n^{-σ} ≤ 2^{k+1}·(2^{k+1})^{-σ}=2^{k(1−σ)} 块内逐项压+块长·单调经 GaC1_Iface_Real *)

Lemma condensation_tail_bound : forall (M N : nat),     (* (a) 凝聚尾界·卡 ① 原式 *)
  (1 <= M)%nat -> (M <= N)%nat ->
  real_le (cRe (c_norm_sq (c_tail M N (c_of_real sig))))
          (real_mult (r_two_rpow (c_of_real_r M)) r_geom_sq).
(* 证: 二进分组归纳＋几何级数 Q→Real 闭式·r_two_rpow'/r_geom_sq 为平方承载形（零开方） *)

Lemma zeta_part_cauchy_bound : forall (M N : nat) (s : Cx),   (* (b) Cauchy 列见证 *)
  (1 <= M)%nat -> (M <= N)%nat -> real_eq (cRe s) sig ->
  real_le (c_norm_sq (c_plus (c_zeta_part N s) (c_opp (c_zeta_part M s))))
          (real_mult (r_two_rpow (c_of_real_r M)) r_geom_sq).
(* 证: 三角不等式经 C2.01(b) 模公式压到 (a)·norm_sq 平方承载 *)

Lemma tail_bound_uniform : forall (sig0 : Real) (N M : nat),  (* (c) 一致形·σ₀ 参化 *)
  real_lt real_one sig0 -> real_le sig0 sig -> (1 <= M)%nat -> (M <= N)%nat ->
  real_le (c_norm_sq (c_plus (c_zeta_part N s0) (c_opp (c_zeta_part M s0))))
          (tail_sq_at sig0 M).   (* 尾界以 σ₀ 代入·全段消费的命名显式引理形 *)

End AbsConvTailBound.
```
- **落刀定形说明**：上块 `c_of_real_r`/`r_geom_sq`/`tail_sq_at` 为本稿局部缩写（nat→Real 嵌入/尾界平方/σ₀ 代入形·定义面在落刀稿补全）；`c_inv_wit` 为 C2.01 侧 sigT 逆元见证补铸项（登记入 C2.01 义务清单 L3）；`End` 名与 `Section` 名同名（Coq 语法硬约束·落刀核对项）。
- **证书面** `GaC2_02_AbsConvTailBound_cert.v`：几何闭式常数样点带（σ₀∈{3/2,2,3} 三样点·字面 Q 证书＋vm_compute 核对引理·zz_ln 判例形）；样点带占 ≈40 行。
- **行数预算**：语句面 ≈70＋cert ≈40 ≤400 ✓。
- **证明义务清单**：nat 强归纳承载（stdlib Nat 面）；`Htwo` 见证；σ₀ 样点带字面值。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_02_AbsConvTailBound.
Check condensation_tail_bound.  Check zeta_part_cauchy_bound.  Check tail_bound_uniform.
Print Assumptions zeta_part_cauchy_bound.   (* 期待 Closed *)
(* cert 冒烟（施工席·秒级）：
   Require Import GaC2_02_AbsConvTailBound_cert.  Compute zz_geom_const_samples. *)
```

**稿四·验收判据**
- 基座五条＋专判：①具名项计数（3 Lemma＋4 Definition 对表）；②尾界常数与卡 ①(a) 原式 M^{1−σ}·(1+2^{1−σ}/(1−2^{1−σ})) 逐因子咬合；③cert 样点 vm_compute rc=0 且秒级（>60s 即停改预演形态·执行卷 §1.3）；④收敛承载形与 C2.05/C1-14 定形一致（R3 接口义务·波末 Iface 复核位）。

---

### C2.03 〔翻转簇·系数 0.35·W2〕GaC2_03_FiniteEulerProduct

**挂卡**：全景卡 第二段 C2.03（行 360-368）｜**依赖正典**：C2.01（spec §3.3 W2；HansonLcm 系为 L0 既有非节点）｜**卡三档**：1.5/2.5/4

**稿一·先例研读卡**
- 先例件：F4（EulerProduct/Basic.lean·21,835B）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F4 `prod_primesBelow_tsum_eq_tsum_smoothNumbers`（∏_{p<N}(Σ'e f(p^e))=Σ_{N-光滑}f·有限恒等式） | `fin_euler_prod_eq_smooth_sum`（∏_{p≤N}Σ_{k≤K_p}p^{-ks}=Σ_{n∈S_N}n^{-s}） | **语句面/架构直系对表**（smoothNumbers↔S_N·primesBelow↔p≤N·同一恒等式）·二步分解法（先 factored 后 smooth）转录为 nat 有限序列承载 |
| F4 `summable_and_hasSum_smoothNumbers_prod_primesBelow_tsum`（两侧可和+HasSum） | 不吸收（无穷和面·本节点纯有限） | 登记为 C2.04/C2.05 先例位 |
| F4 `Summable.norm_lt_one`（\|f p\|<1 几何前提形） | K_p:=⌊ln N/ln p⌋ 几何截断前提 | 前提面对表（p^{K_p+1}>N） |

- **吸收边界**：①先例的 `Finset`/`Nat.Primes`/`smoothNumbers` 库承载禁直用——S_N 可判定刻画走树内 pr/pec 面（**`pr_prime_bool` 本席零命中·落刀前 LINT-0 钉取**；pec_prim/pec_win 已验）；②FTA 对表消费 HansonLcm 幂特征（树内在库·D1 B3 同族工艺·卡 ③）——证明物零移植·nat 有限和重排自铸（pze_sumf_* 件形参照·L0 已验）。

**稿二·语句面稿（语句面 ≈85 行预算）**

```coq
Require Import QArith_base.
Require Import S02_CauchyComplete.
Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import HansonLcm.  Require Import Hanson3Pow.   (* L0: FTA/lcm 幂面·本席实勘在树 *)
Require Import abl_Pr_erdos_theta.                      (* L0: pec_prim（:101 已验） *)
Require Import GaC2_01_DirichletPartialSum.

Section FiniteEulerProduct.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).
Variable primeb : nat -> bool.                          (* 素性布尔面·落刀前 LINT-0 钉取树内现役件 *)
Hypothesis Hprimeb_ok : forall n, primeb n = true <-> 1 < n /\ (forall d, 0 < d -> d < n -> d = 1 \/ n = d * (d / d) \/ ~ (d <> 1 /\ d <> n /\ exists q, d * q = n)).
(* 义务 L2：素性刻画形状与树内件对表后定形·本稿占位显式登记 *)

Fixpoint Kexp (p N : nat) : nat :=                       (* K_p:=⌊ln N/ln p⌋·以 p^{K+1}>N 判定承载 *)
  match N with O => O | S m => if Nat.ltb p (S m) then S (Kexp p (S m / p)) else O end.
(* 定义面落刀时以「p^(K_p+1)>N ∧ p^{K_p}≤N」双不等式特征引理定形（义务 L3）·先例 F4 Summable.norm_lt_one 前提形对表 *)

Fixpoint smooth_N (N : nat) (n : nat) : bool :=          (* S_N：N-光滑可判定刻画 *)
  match n with O => false | S m => (forallb (fun p => negb (primeb p) || Nat.ltb p (S (S m))) (factors (S m))) && true end.
(* 义务 L4：factors（素分解枚举）钉取 HansonLcm/pec_win 现役面后定形 *)

Fixpoint c_prod_primes (N : nat) (s : Cx) : Cx :=        (* ∏_{p≤N}(Σ_{k≤K_p} p^{-ks}) *)
  match N with O => c_one | S m => c_mult (c_prod_primes m s) (c_pgeo (S m) (Kexp (S m) N') s) end.
(* N'/范围参量落刀定形·义务 L5；c_pgeo 为单素几何块 Σ_{k≤K} p^{-ks}·C2.01 c_powq 迭代 *)

Fixpoint c_sum_smooth (N : nat) (s : Cx) : Cx :=         (* Σ_{n∈S_N} n^{-s} *)
  match N with O => c_zero | S m => c_plus (c_sum_smooth m s) (if smooth_N (S m) ... then c_powq (S m) s else c_zero) end.

Lemma fin_euler_prod_eq_smooth_sum : forall (N : nat) (s : Cx),
  c_eq (c_prod_primes N s) (c_sum_smooth N s).
(* 证: 多元几何级数展开+FTA 唯一分解对表（HansonLcm 幂特征）·先例 F4 二步分解架构（factored→smooth）转录 *)

Definition R_N (N : nat) (s : Cx) : Cx :=                (* R_N(s):=Σ_{n∈S_N, n>N} n^{-s}·供 C2.04 *)
  c_plus (c_sum_smooth ... ) (c_opp (c_zeta_part N s)).  (* 范围参量落刀定形（义务 L6） *)

End FiniteEulerProduct.
```
- **fail-loud 自纠注**：上块 `N'`/`...`/范围参量为占位符——本稿为勘形形·语句形状已定（恒等式/块/光滑和三件）·nat 范围参量与 factors 承载落刀时钉取现役面定形（义务 L3-L6 显式列名·禁含糊落刀）。
- **证书面**：K_p 表与有限乘积数值样点（N∈{10,100} 两样点·字面＋vm_compute）——卡 ③ 可计算面条目。
- **行数预算**：语句面 ≈85＋cert ≈35 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_03_FiniteEulerProduct.
Check fin_euler_prod_eq_smooth_sum.  Check R_N.
Print Assumptions fin_euler_prod_eq_smooth_sum.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①恒等式两端与卡 ① 有限恒等式逐项咬合（p≤N/K_p/S_N/R_N 四记号）；②LINT-0：primeb/factors 承载件钉取登记落卷（`pr_prime_bool` 疑云销号）；③FTA 面零新铸（HansonLcm 消费位 grep ≥1·LINT-3 前闸）。

---

### C2.04 〔翻转簇·系数 0.35·W3〕GaC2_04_EulerTailError

**挂卡**：全景卡 第二段 C2.04（行 370-378）｜**依赖正典**：C2.02, C2.03（spec §3.3 W3）｜**卡三档**：2/3.5/5

**稿一·先例研读卡**
- 先例件：F4。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F4 `norm_tsum_smoothNumbers_sub_tsum_lt`（∃N₀∀N≥N₀·‖Σ'f−Σ_{smooth}f‖<ε·显式尾界） | `R_N_bound`（\|R_N(s)\|≤N^{1−σ}(1+2^{1−σ}/(1−2^{1−σ}))）·卡 ① 原式 | **语句形直系**：先例 ε-形 ↔ 本节点显式闭式尾界（更强：闭式给 N₀ 反解）·吸收闭式形状 |
| F4 `norm_tsum_factoredNumbers_sub_tsum_lt`（factored 尾界·上件源头） | 尾界链第一段（S_N∩(N,∞)⊆(N,∞) 压界） | 架构对表（两段压界） |
| F3 `abscissaOfAbsConv_le_of_le_const_mul_rpow` | 一致形 σ≥σ₀→0 前提组织 | 语句面对表 |

- **吸收边界**：先例 ε/∃N₀ 形的经典承载（Summable/Tendsto）禁直用——本节点显式闭式（更强·Set 承载 sigT 见证形）；「S_N∩(N,∞)⊆(N,∞)」nat 面包含论证朴素琐碎（setoid 漏配雷区·卡 ③ 坑卡税）。

**稿二·语句面稿（语句面 ≈45 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_01_DirichletPartialSum.  Require Import GaC2_02_AbsConvTailBound.  Require Import GaC2_03_FiniteEulerProduct.

Section EulerTailError.
Variable sig : Real.  Hypothesis Hsig1 : real_lt real_one sig.

Lemma R_N_le_full_tail : forall (N : nat) (s : Cx),       (* 第一段：S_N 尾 ⊆ 全尾压界 *)
  real_le (c_norm_sq (R_N N s)) (c_norm_sq (c_tail N (upper_env N) s)).
(* 证: 上三角和包含·nat 面逐项（setoid 坑卡税位·显式逐项表）·upper_env 落刀定形 *)

Lemma R_N_bound : forall (N : nat) (s : Cx),              (* 卡 ① 原式·闭式尾界 *)
  real_eq (cRe s) sig ->
  real_le (c_norm_sq (R_N N s))
          (tail_sq_at sig N).      (* = [N^{1−σ}·(1+2^{1−σ}/(1−2^{1−σ}))]²·C2.02 尾界代入 M=N *)
(* 证: C2.02 condensation_tail_bound 直消费+第一段压界·纯装配零新方法件 *)

Lemma R_N_uniform_zero : forall (sig0 : Real),            (* σ≥σ₀>1 一致→0·sigT 见证形 *)
  real_lt real_one sig0 ->
  { eps0 : Real & real_lt real_zero eps0 &
    forall (s : Cx) (N : nat), real_eq (cRe s) sig0 -> (bound_N sig0 N <= N)%nat ->
    real_le (c_norm_sq (R_N N s)) eps0 }.
End EulerTailError.
```
- **证书面**：尾界常数样点带（N∈{10,100,1000}·σ₀=3/2·字面 Q 证书＋vm_compute）。
- **行数预算**：语句面 ≈45＋cert ≈35 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_04_EulerTailError.
Check R_N_bound.  Check R_N_uniform_zero.
Print Assumptions R_N_bound.    (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①`R_N_bound` 尾界与 C2.02 `tail_bound_uniform` 消费位咬合（M:=N 代入形·grep 消费 ≥1·LINT-3 前闸）；②R_N 定义与 C2.03 `R_N` 同名同形（段内直依·禁复制定义）；③cert 三样点 rc=0 秒级。

---

### C2.05 〔翻转簇·系数 0.35·W4〕GaC2_05_EulerLimitAsm

**挂卡**：全景卡 第二段 C2.05（行 380-388）｜**依赖正典**：C2.02, C2.03, C2.04（spec §3.3 W4）｜**卡三档**：2/3.5/5

**稿一·先例研读卡**
- 先例件：F4＋F6。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F6 `riemannZeta_eulerProduct`（∏_{p<n}(1−p^{-s})⁻¹→ζ(s)·Tendsto 部分乘积列形·1<re s） | `euler_prod_limit`（主恒等式 (b)·lim 形） | **语句面直系对表**（同一恒等式同一极限形）·承载形换 C1-14 定形 |
| F4 `eulerProduct_completely_multiplicative`（∏_{p∈primesBelow n}(1−f p)⁻¹→Σ'f·完全乘性 Tendsto 形） | 乘积列 Cauchy (a) 的架构（部分乘积列→几何增量代数） | 架构对表（primesBelow 部分乘积 + `one_sub_inv_eq_geometric_of_summable_norm` 几何块恒等式） |
| F4 `norm_tsum_factoredNumbers_sub_tsum_lt`（ε 尾界） | (a) 几何增量 \|1/(1−x)−1/(1−y)\|≤\|x−y\|/((1−\|x\|)(1−\|y\|)) 代数 | 语句面对表（几何增量界） |
| F5 `EulerProduct.exp_tsum_primes_log_eq_tsum` | 不吸收（对数版·非本节点） | 登记备查（C3 dVp 链备料） |

- **吸收边界**：①`Tendsto`/`HasProd` 经典拓扑承载禁直用——极限承载形=C1-14/C2.02 定形（**本段第一个 lim 节点·R3 接口义务最重位**）；②ζ(s) 侧承载=部分和极限（卡 ①(b)）非 mathlib riemannZeta——两者咬合由 (b) 主恒等式承担·零外部函数消费。

**稿二·语句面稿（语句面 ≈65 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import S03_QExp.   (* L0: 证书承载（卡 ②·实勘在树） *)
Require Import GaC2_02_AbsConvTailBound.  Require Import GaC2_03_FiniteEulerProduct.  Require Import GaC2_04_EulerTailError.

Section EulerLimitAsm.
Variable sig : Real.  Hypothesis Hsig1 : real_lt real_one sig.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).

Fixpoint c_euler_part (N : nat) (s : Cx) : Cx :=          (* ∏_{p≤N}(1−p^{-s})^{-1}·逆元走 sigT 见证 *)
  match N with O => c_one | S m => c_mult (c_euler_part m s) (c_inv_geom (S m) s) end.
(* c_inv_geom：单素几何逆 (1−p^{-s})^{-1}·非零见证经 Hsig1 压（\|p^{-s}\|=p^{-σ}<1）·义务 L7 *)

Lemma euler_part_cauchy : forall (M N : nat), (M <= N)%nat ->   (* (a) 乘积列 Cauchy *)
  real_le (c_norm_sq (c_plus (c_euler_part N s0) (c_opp (c_euler_part M s0))))
          (smooth_tail_sq M).   (* ≤ Σ_{n>M, n N₀-光滑} n^{-σ} ≤ C2.02 尾界·几何增量代数 *)
(* 证: 几何增量 \|1/(1−x)−1/(1−y)\|≤\|x−y\|/((1−\|x\|)(1−\|y\|))·norm_sq 承载·C2.04 尾界收口 *)

Lemma euler_prod_limit :                                   (* (b) 主恒等式·极限承载形 *)
  { zeta_s : Cx & (* 承载形=C1-14/C2.02 定形·接口对表义务 R3 *)
    forall (delta : Real), real_lt real_zero delta ->
    { N0 : nat & forall N, (N0 <= N)%nat ->
      real_le (c_norm_sq (c_plus (c_euler_part N s0) (c_opp zeta_s))) (real_mult delta delta) } }.
(* 证: (a)+C2.04·sigT 双层见证（极限值+精度响应）·路径 A 正形 *)

Lemma euler_prod_cert : forall (eps : Q), (0 < eps)%Q ->   (* (c) 证书形·Q-exp 承载 *)
  { N0 : nat & forall N, (N0 <= N)%nat -> QleT (q_norm_sq_lb (c_plus (c_euler_part N s0) (c_opp zeta_s))) eps }.
(* 证: (b) 的 Q 证书面·N₀(σ,ε) 显式→vm_compute（R2·卡 ③） *)

End EulerLimitAsm.
```
- **证书面**：N₀(σ,ε) 显式表（σ₀=3/2·ε∈{1/10,1/100} 两样点·字面＋vm_compute）。
- **行数预算**：语句面 ≈65＋cert ≈40 ≤400 ✓。
- **义务清单**：L7 c_inv_geom 非零见证；承载形对表（波末 GaC2_Iface_DS 复核位）。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_05_EulerLimitAsm.
Check euler_part_cauchy.  Check euler_prod_limit.  Check euler_prod_cert.
Print Assumptions euler_prod_limit.   (* 期待 Closed·sigT 见证零公理 *)
```

**稿四·验收判据**
- 基座五条＋专判：①(b) 极限承载形与 C2.02/C1-14 定形一致（GaC2_Iface_DS 波末复核·R3）；②(c) N₀ 字面证书 vm_compute rc=0；③s0/zeta_s 参量在落刀稿以 Section 变元具体化（Hsig1+Hnpos 供给）·本稿占位显式登记。

---

### C2.06 〔翻转簇·系数 0.45·W1〕GaC2_06_AltMonoFace

**挂卡**：全景卡 第二段 C2.06（行 394-402）｜**依赖正典**：无 γ 内前置·C1.1 弱依赖经 Iface（spec §3.3 W1）｜**卡三档**：1/2/3（全组最轻）

**稿一·先例研读卡**
- 先例件：F8（RiemZeta.lean）＋F3（Convergence.lean）·覆盖度=部分（映射表 §①-3 行 6-10 判词原文「ζ/L 延拓成谱·η 专形未单独核·保守取带中位偏上」——本席 fetch 后维持）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F6 `summable_riemannZetaSummand`（n^{-s} 项可和前提·1<re s） | `r_npow` 承载面（n^{-σ} 实幂项） | 语句面对表（项形状） |
| F3 `LSeries.abscissaOfAbsConv_le_of_le_const_mul_rpow` | 不吸收 | — |
| mathlib Real.rpow 单调面（树外·参照级） | (a) 单调 (b)→0 一致 (c) 差非负 | **路线对表**：rpow 单调链 ln 单调→exp 单调→幂单调·树内对应=C1-01/02 输出（GaC1_Iface_Real）+S07 Lipschitz 双件（:3550/:3653 已验） |

- **吸收边界**：mathlib `Real.rpow`/`Real.log` 系经典承载禁直用（异承载·KB34 红线一）——单调性经 GaC1_Iface_Real（C1-01 real_log 单调/C1-02 幂律）转写链自铸；σ₀ 定常化工艺（KB34:67 ε₀=1/6600 先例·卡 ③）。

**稿二·语句面稿（语句面 ≈40 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import S07_RealSetoidExpLog.
Require Import GaC1_Iface_Real.    (* L1 Iface: C1-01 real_log 单调/C1-02 ln 幂律（裁 2 后可消费） *)
Require Import GaC2_01_DirichletPartialSum.

Section AltMonoFace.
Variable sig sig0 : Real.
Hypothesis Hs0 : real_lt real_zero sig0.  Hypothesis Hs : real_le sig0 sig.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).

Definition r_npow (n : nat) : Real :=                    (* n^{-σ} 实幂项·C2.01 c_powq 实切片 *)
  cRe (c_powq n (c_of_real sig)).

Lemma r_npow_anti : forall (m n : nat), (m <= n)%nat ->  (* (a) 单调·n^{-σ} ≤ m^{-σ} *)
  real_le (r_npow n) (r_npow m).
(* 证: ln 单调（C1-01）→exp 单调（S07 Lipschitz 双件 :3550/:3653）→幂转写链（卡 ③） *)

Lemma r_npow_tozero : forall (n : nat),                  (* (b) →0 一致形·显式模 *)
  real_le (r_npow n) (r_npow0 n).  (* r_npow0:=n^{-σ₀}·σ₀ 代入模·显式 *)
Lemma r_npow0_tendsto : { M0 : nat & forall n, (M0 <= n)%nat ->
  real_le (r_npow0 n) eps0 }.   (* eps0 显式给定·sigT 见证形·义务 L8 供给 eps0/M0 *)
Lemma r_npow_diff_nonneg : forall (n : nat),             (* (c) 差非负 *)
  real_le real_zero (real_plus (r_npow n) (real_opp (r_npow (S n)))).
End AltMonoFace.
```
- **义务清单**：L8 (b) 的 M0/eps0 显式供给（σ₀ 定常化·KB34:67 工艺）；GaC1_Iface_Real 消费位（C1-01/02 输出）落刀时 LINT-0 锚检。
- **证书面**：头注「本件无可计算面」声明。
- **行数预算**：≈40 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_06_AltMonoFace.
Check r_npow_anti.  Check r_npow_tozero.  Check r_npow_diff_nonneg.
Print Assumptions r_npow_anti.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①单调链消费位（GaC1_Iface_Real≥1＋S07 双 Lipschitz≥1·LINT-3 前闸 grep）；②三件与卡 ①(a)(b)(c) 逐条咬合；③W1 可并行起步（与 C2.01/C2.09 同波·零互依·LINT-1 复测位）。

---

### C2.07 〔翻转簇·系数 0.45·W2〕GaC2_07_DirichletTestAbel

**挂卡**：全景卡 第二段 C2.07（行 404-412）｜**依赖正典**：C2.01, C2.06（spec §3.3 W2）｜**卡三档**：3/5.5/8（新地形溢价·KB36R 30 发判例带）

**稿一·先例研读卡**
- 先例件：F7（DirichletContinuation.lean）·**覆盖度=部分（诚实）**：F7 延拓走 Hurwitz zeta 线性组合·**非 Abel/Dirichlet 判别法路线**；映射表 §①-3 行 6-10 判词「η 专形（Dirichlet 判别法构造性化）未单独核」——本席 fetch 后**维持原判**（F7 全文无交错/分部语句面·研读卡如实登记「先例件对表位=延拓谱语句形状（收敛域/一致尾形）·判别法本体零先例」）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F7 `LFunction_eq_LSeries`（1<re s 重合·收敛域语句形） | η 收敛域语句形（Re s=σ≥σ₀>0）·部分和承载 | 收敛域语句形对表（半平面参数化） |
| F7 `differentiableAt_LFunction`（s≠1∨χ≠1） | 不吸收（延拓面归 C2.10） | 登记备查 |
| F8 `zeta_eq_tsum_one_div_nat_add_one_cpow` | 交错实例化 b_n=(−1)^{n−1} 项形 | 项形状对表 |

- **吸收边界**：Abel 分部恒等式 Σa_nb_n=a_NS_N−a_{M+1}S_M+Σ(a_n−a_{n+1})S_n 为纯有限 telescoping——树内自铸（琐碎但长·卡 ③）；先例零对应·0.45 系数的「部分覆盖」判定如实维持（禁因研读降档·禁因无先例升档）。

**稿二·语句面稿（语句面 ≈75 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC1_Iface_Cx.      (* L1 Iface: C1-14 部分和柯西承载形（卡 ⑤） *)
Require Import GaC2_01_DirichletPartialSum.  Require Import GaC2_06_AltMonoFace.

Section Abel.
Variable a : nat -> Real.                                (* 单调递减→0 实列·显式模 *)
Variable beta : nat -> Real.
Variable b : nat -> Cx.                                  (* 复列·部分和有界 *)
Variable B : Real.
Hypothesis Ha_anti : forall m n, (m <= n)%nat -> real_le (a n) (a m).
Hypothesis Ha_beta : forall n, real_le (a n) (beta n).
Hypothesis Hbeta_tozero : { M0 : nat & forall n, (M0 <= n)%nat -> real_le (beta n) beta_M0 }.
Hypothesis Hb_bounded : forall N : nat,                  (* |Σ_{n≤N} b_n|≤B·norm_sq 承载（零开方） *)
  real_le (c_norm_sq (c_abssum N b)) (real_mult B B).

Fixpoint c_abssum (N : nat) (b : nat -> Cx) : Cx :=      (* Σ_{n≤N} b_n·前缀部分和 *)
  match N with O => c_zero | S m => c_plus (c_abssum m b) (b m) end.
Fixpoint c_wsum (M N : nat) (a : nat -> Real) (b : nat -> Cx) : Cx := (* Σ_{M<n≤N} a_n b_n *)
  match N with O => c_zero | S m => c_plus (c_wsum M m a b) (if Nat.ltb M m' then c_scale (a m') (b m') else c_zero) end.

Lemma abel_tail : forall (M N : nat), (M < N)%nat ->     (* Abel 分部·显式尾形·卡 ① 原式 *)
  real_le (c_norm_sq (c_wsum M N a b))
          (sq (real_mult (real_const (2#1)) (real_mult B (a (S M))))).
(* 证: 恒等式 Σa_nb_n=a_NS_N−a_{M+1}S_M+Σ_{M<n<N}(a_n−a_{n+1})S_n·telescoping+三角（卡 ③·琐碎但长） *)

Section EtaInst.                                          (* 实例化：b_n=(−1)^{n−1}·a_n=n^{-σ} *)
Variable sig0 : Real.  Hypothesis Hs0 : real_lt real_zero sig0.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).
Definition eta_term (n : nat) (s : Cx) : Cx :=
  c_scale (alt_sign n) (c_powq n s).                      (* (−1)^{n−1}·n^{-s}·alt_sign nat 面 *)
Fixpoint eta_part (N : nat) (s : Cx) : Cx :=
  match N with O => c_zero | S m => c_plus (eta_part m s) (eta_term (S m) s) end.

Lemma eta_conv_uniform : forall (s : Cx), real_le sig0 (cRe s) ->   (* η 收敛·一致尾 *)
  { eta_s : Cx & forall N : nat,
    real_le (c_norm_sq (c_plus (eta_part N s) (c_opp eta_s)))
            (sq (real_mult (real_const (2#1)) (r_npow_at (S N)))) }.   (* 尾 ≤ 2(N+1)^{-σ₀}·卡 ① 原式 *)
End EtaInst.
End Abel.
```
- **义务清单**：alt_sign（nat 符号面·stdlib）/r_npow_at（C2.06 σ₀ 切片消费·grep 位）；B=1 特款 |S_N|≤1 供给（alt 三角代数）。
- **证书面**：尾界 2(N+1)^{-σ₀} 样点带（σ₀=1/2·N∈{10,100}）。
- **行数预算**：语句面 ≈75＋cert ≈30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_07_DirichletTestAbel.
Check abel_tail.  Check eta_conv_uniform.
Print Assumptions abel_tail.    (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①Abel 恒等式三件套（恒等式/尾界/实例化）与卡 ① 原式逐因子咬合（2B·a_{M+1}/2(N+1)^{-σ₀}）；②新地形溢价登记（卡 ④ 需突破·KB36R 判例带 3/5.5/8 不动·禁降档）；③GaC1_Iface_Cx 消费位 grep ≥1。

---

### C2.08 〔翻转簇·系数 0.45·W3〕GaC2_08_EtaZetaRelation

**挂卡**：全景卡 第二段 C2.08（行 414-422）｜**依赖正典**：C2.02, C2.07（spec §3.3 W3）｜**卡三档**：2/3.5/5

**稿一·先例研读卡**
- 先例件：F8（RiemannZeta.lean）·**覆盖度=部分（关键差异 fetch 实录）**：F8 定义路 `riemannZeta := hurwitzZetaEven 0`（:121 实读）——**非 η-商路**；η-ζ 代数关系在 F8 语句面零对应（`zeta_eq_tsum_one_div_nat_add_one_cpow` 仅级数形）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F8 `riemannZeta`（:=hurwitzZetaEven 0） | 不吸收（承载路差·登记） | **承载差实录**：树内 η-路自铸·mathlib Hurwitz 路——吸收位仅「ζ 侧级数承载语句形」 |
| F8 `zeta_eq_tsum_one_div_nat_add_one_cpow` | 偶项分离恒等式的 ζ_N 侧 | 级数形对表 |
| F4 `one_sub_inv_eq_geometric_of_summable_norm`（几何块恒等式·F4:285） | (1−2^{1−s}) 块因子的几何承载参照 | 语句面对表（几何和闭式） |

- **吸收边界**：奇偶分裂换元（Σ_{偶}=2^{-s}Σ_{m≤⌊N/2⌋}m^{-s}）纯 nat 有限和重排自铸（换元律·坑卡雷区·卡 ③）；修正项显式→0 面自铸（消费 C2.02 尾界）。

**稿二·语句面稿（语句面 ≈60 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_01_DirichletPartialSum.  Require Import GaC2_02_AbsConvTailBound.  Require Import GaC2_07_DirichletTestAbel.

Section EtaZetaRelation.
Variable sig : Real.  Hypothesis Hsig1 : real_lt real_one sig.   (* σ>1·有限和形域 *)
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).

Definition two_pow_1ms (s : Cx) : Cx := c_powq 2 s.      (* 2^{1−s}:=2^{-s}·因子承载参量落刀定形（义务 L9） *)

Lemma eta_zeta_part_err : forall (N : nat) (s : Cx),     (* 有限和形·卡 ① 原式 *)
  real_le (c_norm_sq (c_plus (eta_part N s)
             (c_opp (c_mult (c_plus c_one (c_opp (two_pow_1ms s))) (c_zeta_part N s)))))
          (err_sq N sig).
(* 证: 偶项分离 η_N=ζ_N−2Σ_{2m≤N}(2m)^{-s}·Σ_{2m≤N}=2^{-s}Σ_{m≤⌊N/2⌋}·修正=偶项截断差·换元律（坑卡税） *)
(* err_sq:= [2·2^{−σ}·(N/2)^{1−σ}·C(σ)]²·显式→0·C(σ) 落刀定形（义务 L10） *)

Lemma eta_zeta_limit :                                    (* 极限面：η(s)=(1−2^{1−s})ζ(s)·σ>1 *)
  c_eq eta_s (c_mult (c_plus c_one (c_opp (two_pow_1ms s))) zeta_s).
(* 证: 有限和形+C2.04/C2.02 尾→0·极限承载形同 C2.05 定形 *)

Lemma denom_lower_bound : forall (s : Cx),                (* |1−2^{1−s}|≥1−2^{1−σ}·σ≤1·供 C2.09/17 *)
  real_le sig real_one ->
  real_le (sq (real_plus real_one (real_opp (r_two_pow_1ms (cRe s)))))
          (c_norm_sq (c_plus c_one (c_opp (two_pow_1ms s)))).
(* 证: |1−re^{iθ}|≥1−r 模代数·零周期性依赖（卡 ①·分母下界引理·C2.17 直消费） *)
End EtaZetaRelation.
```
- **义务清单**：L9 2^{1−s} 承载参量（c_powq 2 与 1−s 幂形的语义对表）；L10 C(σ) 显式形；denom 下界的 σ≤1 分域组织（卡 ③）。
- **证书面**：修正常数样点（N∈{10,100}·σ₀=3/2）。
- **行数预算**：语句面 ≈60＋cert ≈30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_08_EtaZetaRelation.
Check eta_zeta_part_err.  Check eta_zeta_limit.  Check denom_lower_bound.
Print Assumptions denom_lower_bound.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①修正式与卡 ① 逐因子咬合（2·2^{−σ}·(N/2)^{1−σ}·C(σ)）；②denom_lower_bound 消费位预登记（C2.09/C2.17·波末 grep 复核）；③η_N 与 C2.07 eta_part 同名同形（直依·禁复制）。

---

### C2.09 〔翻转簇·系数 0.45·W1〕GaC2_09_DenomZeroSet

**挂卡**：全景卡 第二段 C2.09（行 424-432）｜**依赖正典**：无 γ 内前置·C1.4 残经 Iface（spec §3.3 W1）｜**卡三档**：3.5/6/9（含周期性最小自铸·硬新地形）

**稿一·先例研读卡**
- 先例件：F8＋F7·覆盖度=部分（周期性面零直对表）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F7 `differentiableAt_LFunction`（s≠1 奇点面语句形） | (c) 局部一阶形 s=1 极点语句位 | 奇点面语句形对表 |
| F8 `differentiableAt_riemannZeta`（s≠1） | 同上（ζ 侧互证） | 语句形对表 |
| F8 `riemannZeta_neg_two_mul_nat_add_one`（ζ(−2(n+1))=0 平凡零点语句面） | 不吸收（负偶零点·非本节点分母零点集） | 备查 |
| mathlib `Complex.exp` 单射性/2π 周期面（树外·未 fetch 单件） | 不吸收·**登记零直对表** | 虚向刻画自铸（消费 C1-17 周期归约经 GaC1_Iface_Cx） |

- **吸收边界**：①复指数周期性/单射性经典承载禁直用（KB34:104 红线一·stdlib/mathlib 非构造禁直用卡 ④ 原判）；②周期性面=全段最大缺口件（ExpLog 18 名零周期性命中·§二台账坐实）——最小自铸形=e^{iy} 的 cos/sin 2π 关系构造性刻画（KB36R 断点续铸·内含 1-2 子件量·卡 ③）；③复审条件在卷：R4 若检出 Bishop 系周期性可用构造→复核（禁降档·须逐路论证·卡 ④ 原文）。

**稿二·语句面稿（语句面 ≈70 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC1_Iface_Cx.      (* L1 Iface: C1-17 2π 周期归约＋C1-15 Taylor（C1.4 残·spec W1） *)
Require Import GaC2_01_DirichletPartialSum.  Require Import GaC2_08_EtaZetaRelation.

Section DenomZeroSet.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).

Lemma denom_zero_real_dir : forall (s : Cx),              (* (a) 实向·零周期性依赖 *)
  real_eq (c_norm_sq (c_plus c_one (c_opp (two_pow_1ms s)))) real_zero ->
  real_eq (cRe s) real_one.
(* 证: |2^{1−s}|=2^{1−σ}（C2.01(b) 模公式）→2^{1−s}=1 ⇒ σ=1·模乘法性+c_norm_sq（卡 ①） *)

Lemma denom_zero_imag_char : forall (t : Real),           (* (b) 虚向·周期性依赖·缺口件 *)
  real_eq (cIm s) t -> real_eq (cRe s) real_one ->
  (real_eq (c_norm_sq (c_plus c_one (c_opp (two_pow_1ms s)))) real_zero ->
   { k : Z & (* t·ln2 ∈ 2πZ 的构造性刻画·sigT 见证形 *)
     real_eq (real_mult t (real_log (nat_real 2) Htwo))
             (real_mult (Qpos_real (2#1) ) (pi_times k)) }).
(* 证: e^{iy}=1 ⇔ y∈2πZ·消费 C1-17 周期归约（GaC1_Iface_Cx）·sin 符号变号显式区间隔离（卡 ③·1-2 子件量） *)
(* pi_times/Qpos_real 为落刀定形承载（π 承载位=C1-17 输出面·义务 L11） *)

Lemma denom_first_order : forall (s : Cx),                (* (c) 局部一阶形·供 s=1 极点处理 *)
  real_le (c_norm_sq (c_plus s c_m1)) rr_sq ->            (* |s−1|≤r·r 显式小 *)
  real_le (c_norm_sq (c_plus (c_plus (two_pow_1ms s) (c_opp c_one))
             (c_opp (c_scale (real_log (nat_real 2) Htwo) (c_plus s c_m1)))))
          (real_mult C_sq (sq (sq ...))).                  (* ≤ C|s−1|²·平方承载·C 显式（义务 L12） *)
(* 证: Taylor（C1-15 经 Iface）·卡 ① 原式 *)

Lemma zero_set_membership : forall (k : Z),               (* 零点集 s=1−2πik/ln2 ∈ 消费域登记件 *)
  real_eq (cRe (s_at k)) real_one.
(* 证: 直接代入·(a) 逆向·全零点集位于 Re s=1 线上（卡 ①勘形要点·C3/C4 消费域） *)
End DenomZeroSet.
```
- **义务清单**：L11 π 承载位（C1-17 输出面钉取）；L12 (c) 常数 C 显式；落刀稿 s/c_m1/s_at 参量具体化（Section 变元）。
- **证书面**：头注「本件无可计算面」。
- **行数预算**：≈70 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_09_DenomZeroSet.
Check denom_zero_real_dir.  Check denom_zero_imag_char.  Check denom_first_order.
Print Assumptions denom_zero_imag_char.   (* 期待 Closed·sigT 见证形 *)
```

**稿四·验收判据**
- 基座五条＋专判：①(b) 周期性消费位 GaC1_Iface_Cx grep ≥1（C1-17 落装前置闸）；②零点集刻画与卡 ①「1−2^{1−s}=0 ⇔ s=1−2πik/ln2」双向咬合（(a)+(b)+membership 三件）；③复审条件登记在卷（Bishop 系周期性·R4 义务）；④W1 并行位（与 C2.01/C2.06 零互依）。

---

### C2.10 〔翻转簇·系数 0.45·W4〕GaC2_10_EtaContinuation

**挂卡**：全景卡 第二段 C2.10（行 434-442）｜**依赖正典**：C2.07, C2.08, C2.09（spec §3.3 W4）｜**卡三档**：2.5/4.5/7

**稿一·先例研读卡**
- 先例件：F7（DirichletContinuation.lean·19,341B 全读）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F7 `LFunction_eq_LSeries`（1<re s 上 LFunction 与朴素 LSeries 重合） | (a) 一致：Re s>1 上 ζ̃=ζ | **语句形直系对表**（延拓函数与原级数重合语句形） |
| F7 `differentiableAt_LFunction`（s≠1∨χ≠1 ⇒ 可微·奇点除去语句形） | (b) 解析：分母非零域内连续且局部可展 | 语句形对表（除去奇点域的可展性参数化）·构造内容=Weierstrass 双级数构造性化（Set 重铸全价·先例走 Hurwitz 路） |
| F7 `LFunction_changeLevel`（模升级不变式） | 不吸收（模升级·非本节点） | 备查（C3 dVp 链备料） |
| F7 `deriv_LFunction_eq_deriv_LSeries` | 不吸收（导数面·C2.18 对表位） | 备查（C2.18 研读卡引） |

- **吸收边界**：①mathlib 延拓=Hurwitz zeta 线性组合·**非 η/(1−2^{1−s}) 商形**——ζ̃ 承载自铸·吸收仅语句形状；②(d) 诚实边界：s_k（k≠0）可去奇点面**不在本节点闭域**（卡 ①原文）——跨段登记→C3 消费面勘形处置（复审条件挂 C3）。

**稿二·语句面稿（语句面 ≈65 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC1_Iface_Cx.      (* C1-14 收敛机·局部一致收敛/双级数承载形（最大消费方·卡 ②） *)
Require Import GaC2_07_DirichletTestAbel.  Require Import GaC2_08_EtaZetaRelation.  Require Import GaC2_09_DenomZeroSet.

Section EtaContinuation.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).

Definition denom_nz (s : Cx) : Set :=                     (* 分母非零域·可判定 Set 形 *)
  real_lt eps_lb (c_norm_sq (c_plus c_one (c_opp (two_pow_1ms s)))).  (* eps_lb 局部下界·义务 L13 *)

Definition zeta_tilde (s : Cx) (Hd : denom_nz s) : Cx :=  (* ζ̃:=η/(1−2^{1−s})·sigT 逆元承载 *)
  c_mult eta_s (c_inv_wit (nz_wit Hd)).

Lemma zeta_tilde_agree : forall (s : Cx) (Hd : denom_nz s),  (* (a) 一致·Re s>1 重合 *)
  real_lt real_one (cRe s) -> c_eq (zeta_tilde s Hd) zeta_s.
(* 证: C2.08 eta_zeta_limit 极限恒等式直消费 *)

Lemma zeta_tilde_analytic : forall (s : Cx) (Hd : denom_nz s),  (* (b) 解析·局部可展 *)
  { c_n : nat -> Cx & (* 局部幂级数展开存在性·承载形=C1-15 同一定形（R3 冻结义务） *)
    r_pos witness /\ forall w, (dist witness 形) -> c_eq ... }.
(* 证: η 局部一致收敛的解析项和·Weierstrass 双级数构造性化（卡 ①·树内零先例·新地形） *)

Lemma zeta_tilde_unif_bound : forall (sig0 : Real) (s : Cx) (Hd : denom_nz s),  (* (c) 一致模 *)
  real_lt sig0 (cRe s) -> real_eq (cIm s) ... ->
  real_le (c_norm_sq (zeta_tilde s Hd)) (w_sq sig0 ...).
(* |η|≤1+2·2^{−σ₀}（C2.07 一致尾）·ζ̃ 界=|1−2^{1−s}|^{-1} 加权·下界经 C2.09(c) 局部形（卡 ①） *)
End EtaContinuation.
```
- **义务清单**：L13 denom 下界局部常数（cert 样点）；(b) 展开承载形与 C1-15 对表（波末 GaC2_Iface_Eta 复核位·R3）。
- **证书面**：分母下界样点带（σ₀∈{1/2,1} 两样点）。
- **行数预算**：语句面 ≈65＋cert ≈30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_10_EtaContinuation.
Check zeta_tilde.  Check zeta_tilde_agree.  Check zeta_tilde_analytic.  Check zeta_tilde_unif_bound.
Print Assumptions zeta_tilde_agree.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①(a)(b)(c) 与卡 ① 三条逐条咬合＋(d) 诚实边界**显式不在稿内**（跨段登记行在卷）；②解析承载形与 C1-15 同一定形（R3·GaC2_Iface_Eta 波末复核）；③F7 对表位（LFunction_eq_LSeries/differentiableAt_LFunction 两引理映射落卷）。

---

### C2.11 〔翻转簇·系数 0.50·W2〕GaC2_11_MaxModulusDisk

**挂卡**：全景卡 第二段 C2.11（行 448-456）｜**依赖正典**：C2.09（spec §3.3 W2·弱方向参量）｜**卡三档**：3/5/7.5（新地形溢价）

**稿一·先例研读卡**
- 先例件：F1（PhragmenLindelof.lean 底座 import 位）＋F9（Hadamard.lean 边界-内部论证）·覆盖度=语句面全覆盖·构造化仅方法学（映射表 §①-3 行 11-18 判词原文）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F1 `vertical_strip`（边界界+增长限制 ⇒ 逐点 ‖f z‖≤C·闭条带内） | 推论（最大模·逐点逆否形）的「边界界→内部界」语句架构 | **架构对表**：边界逐点压+内部逐点结论的形状（先例结论即逐点形·非 sup 达成形） |
| F9 `norm_le_interpStrip_of_mem_verticalClosedStrip₀₁`（le_on_closure 边界→内部） | 逐点增长引理→内部界的链式组织参照 | 架构对表（先例 le_on_closure=紧化选择论证——**树内禁抽象紧性**·以线段覆盖链式替代·卡 ③ 设计决策） |
| F1 辅件 `isBigO_sub_exp_exp`（增长限制代数） | 增长限制前提的代数组织 | 前提面对表（树内显式 A·e^{B\|y\|^ρ} 形） |

- **吸收边界**：①经典最大模=反证+紧性（sup 达成）——**全段禁抽象紧性·一切显式 ε/δ 逐点形**（卡 ③ 设计决策·R2 兼容）——先例证明物零移植·仅吸收语句架构；②增长引理（幂级数一阶项方向增益）零直对表件·自铸（0.50 系数「P-L 证明本体＝最大模＋紧化选择论证——Set-carried 重铸是全新证明地形」原文依据）。

**稿二·语句面稿（语句面 ≈80 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC1_Iface_Cx.      (* C1-15 局部可展承载形 *)
Require Import GaC2_01_DirichletPartialSum.  Require Import GaC2_09_DenomZeroSet.

Section MaxModulusDisk.
Variable f : Cx -> Cx.
Variable z0 : Cx.
Variable R : Real.  Hypothesis HR : real_lt real_zero R.
(* Hloc：f 在 B̄(z0,R) 每点局部可幂级数展开（C1-15 承载·语句形义务 L14 对表定形） *)
Variable Hloc : local_exp_disk f z0 R.
Variable a1 : Cx.  Hypothesis Ha1 : real_lt eps_lb (c_norm_sq (c_plus a1 (c_opp (deriv1 f z0 Hloc)))).
(* a1:=f′(z0)≠0·一阶系数显式给出（卡 ①前提）·deriv1 承载=C1-15 展开一阶系数（R3 定形） *)
Hypothesis Hf0 : real_lt eps_lb (c_norm_sq (f z0)).

Lemma growth_lemma : forall (Hp : ...),                    (* 增长引理·显式方向 sigT 见证 *)
  { w : Cx & real_eq (c_norm_sq w) (quarter R_sq) &       (* |w|=R/2·平方承载 *)
    real_eq方向 (c_mult w a1) 方向 witness &              (* 方向 −a1/|a1|·sigT 承载·义务 L15 *)
    real_le (mult_sq (f z0) (增益闭式))
             (c_norm_sq (f (c_plus z0 w))) }.
(* 证: |f(z0+w)|²=|f(z0)|²+2Re(f̄(z0)a1 w)+O(|w|²) 代数·c 绝对显式（卡 ①·增益常数证书位 cert） *)

Lemma max_modulus_pointwise : forall (z : Cx) (delta : Real), (* 推论·逐点逆否形·显式 δ 链 *)
  closed_disk z z0 R -> real_lt real_zero delta ->
  boundary_bounded f z0 R M_sq ->
  real_le (c_norm_sq (f z)) (real_plus M_sq (delta_sq witness)).
(* 证: 线段覆盖链式论证·步数/增益乘积显式·损耗闭式（卡 ①·δ=链式增益误差） *)
End MaxModulusDisk.
```
- **义务清单**：L14 local_exp_disk/deriv1 承载形（与 C1-15 定形一致·波末复核）；L15 方向 sigT 承载；增益常数 c 证书（cert·vm_compute 样点）。
- **证书面**：增益常数 c 与步数界样点。
- **行数预算**：语句面 ≈80＋cert ≈30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_11_MaxModulusDisk.
Check growth_lemma.  Check max_modulus_pointwise.
Print Assumptions growth_lemma.   (* 期待 Closed·方向 sigT 见证零公理 *)
```

**稿四·验收判据**
- 基座五条＋专判：①禁抽象紧性自检（语句面无 sup/max 达成形·全 sigT 逐点形·词面普查）；②增长引理与卡 ①「|f(z₀+w)|≥|f(z₀)|·(1+c·R·\|a₁\|/\|f(z₀)\|)」咬合（平方承载差登记）；③新地形溢价登记（卡 ④ 需突破·禁降档）。

---

### C2.12 〔翻转簇·系数 0.50·W3〕GaC2_12_CauchyCoeffEst

**挂卡**：全景卡 第二段 C2.12（行 458-466）｜**依赖正典**：C2.11（spec §3.3 W3）｜**卡三档**：2.5/4/6

**稿一·先例研读卡**
- 先例件：F9（Hadamard.lean）·覆盖度=部分（Cauchy 估计无积分形在已 fetch 三件内零直对表·登记）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F9 `norm_le_sSupNormIm`/`sSupNormIm` 族（竖线 sup 承载） | 差商 g 圆周界组织的语句参照 | 架构对表（界承载形）——树内以显式界替代 sup |
| F9 `norm_le_interpStrip...`（边界→内部） | 差商 g 经 C2.11 压界 | 架构对表 |
| mathlib Cauchy 估计积分形（未 fetch·禁引） | 不吸收 | **登记未核**：无积分形（经最大模）先例覆盖未勘·R4 落刀前补检（复审判据位） |

- **吸收边界**：无积分证明路线（差商 g=(f−f(z₀))/(z−z₀)·圆盘可展·g(z₀)=f′(z₀)·圆周 \|g\|≤2M/R·经 C2.11）全自铸；一般 n 差分/环域迭代递推 C_n≤2ⁿ 型自铸（常数损耗显式→C4.3 吸收·卡 ①）。

**稿二·语句面稿（语句面 ≈55 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC1_Iface_Cx.
Require Import GaC2_11_MaxModulusDisk.

Section CauchyCoeffEst.
Variable f : Cx -> Cx.  Variable z0 : Cx.  Variable R : Real.
Hypothesis HR : real_lt real_zero R.
Variable Hloc : local_exp_disk f z0 R.                    (* C1-15 承载·同 C2.11 L14 *)
Variable M : Real.
Hypothesis HM : boundary_bounded f z0 R (sq M).           (* |f|≤M·平方承载 *)

Lemma cauchy_est_n1 :                                     (* n=1：|f′(z₀)|≤2M/R·平方承载 *)
  real_le (c_norm_sq (deriv1 f z0 Hloc)) (sq (c_scale' (2#1) (c_divq M R))).
(* 证: 差商 g:=（f−f(z₀))/(z−z₀) 圆盘可展·g(z₀)=f′(z₀)·圆周 |g|≤2M/R 经 C2.11（卡 ①路线原文） *)

Lemma cauchy_est_n : forall (n : nat), (1 <= n)%nat ->    (* 一般 n：递推·C_n≤2ⁿ 型 *)
  real_le (c_norm_sq (nth_coeff n Hloc)) (real_mult (Cn_sq n) (sq (c_divq' M (rpow R n)))).
(* 证: 差分/环域迭代递推·C_n 显式（≤2ⁿ 型）·常数损耗显式→C4.3 吸收（卡 ①）·c_divq'/rpow 承载义务 L16 *)
End CauchyCoeffEst.
```
- **义务清单**：L16 C_n 显式闭式与 rpow R n 承载（C1-05/06 实幂经 GaC1_Iface_Real 备用）；deriv1/nth_coeff 承载与 C2.11 L14 同源（禁两定形）。
- **证书面**：C_n 样点（n∈{1,2,4}）。
- **行数预算**：≈55＋30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_12_CauchyCoeffEst.
Check cauchy_est_n1.  Check cauchy_est_n.
Print Assumptions cauchy_est_n1.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①n=1 形与卡 ①「\|f′(z₀)\|≤2M/R」咬合；②C_n 递推损耗闭式登记（C4.3 吸收位·跨段消费预登记）；③承载形 deriv1 与 C2.11 同源（LINT-3 复核·禁重复定义）。

---

### C2.13 〔翻转簇·系数 0.50·W3〕GaC2_13_BorelCaratheodory

**挂卡**：全景卡 第二段 C2.13（行 468-476）｜**依赖正典**：C2.11（spec §3.3 W3）｜**卡三档**：3/5.5/8

**稿一·先例研读卡**
- 先例件：F2（BorelCaratheodory.lean·全读）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F2 `Complex.borelCaratheodory`（‖f z‖≤2M‖z‖/(R−‖z‖)＋‖f 0‖(R+‖z‖)/(R−‖z‖)·零中心） | 主定理（中心 z₀ 形·|f(z)−f(z₀)|≤(2r/(R−r))(M−A)） | **语句形直系对表**：零中心形经平移 z−z₀ 承载·常数 (2r/(R−r)) 逐因子咬合（R−‖z‖↔R−r·取 r=‖z−z₀‖ 端点形） |
| F2 `borelCaratheodory_zero`（f 0=0 简化形） | 平移后 f(z₀)=0 特款 | 语句形对表 |
| F2 `schwarz_applied`（Schwarz 变换 g:=f/(2M−f)·‖g‖≤(1/R)‖z‖） | 辅助函数工艺 g(w):=(f(z₀+w)−f(z₀))/(2(M−A)−(f(z₀+w)−f(z₀)))·分母实部>0 ⇒ \|g\|≤1 | **工艺直系对表**（先例 SchwarzTransform 节四条=本卡证明骨架同构） |
| F2 `norm_le_norm_two_mul_sub`（Re z≤M ⇒ ‖z‖≤‖2M−z‖） | 分母实部正性→\|g\|≤1 的代数转写 | 语句形直系对表 |

- **吸收边界**：①先例建在 Schwarz lemma/DifferentiableOn 经典承载上——g 的可展性（零点回避经实部正性）Set 重铸（坑卡 Qcompare/setoid 雷区·卡 ③）；②先例零中心 vs 本卡 z₀ 中心——平移承载自铸（c_plus 转写·零理论差）。

**稿二·语句面稿（语句面 ≈60 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_11_MaxModulusDisk.

Section BorelCaratheodory.
Variable f : Cx -> Cx.  Variable z0 : Cx.  Variable R : Real.
Hypothesis HR : real_lt real_zero R.
Variable Hloc : local_exp_disk f z0 R.
Variable M A : Real.
Hypothesis HM : disk_realpart_ub f z0 R M.                (* Re f(z)≤M 于圆盘·实部上界承载（义务 L17） *)
Hypothesis HA : real_eq (cRe (f z0)) A.

Lemma re_part_ub_le_2MmA : forall (w : Cx),               (* 对表 F2 norm_le_norm_two_mul_sub *)
  disk_member z0 R w -> real_le (cRe (c_plus (f w) (c_opp (f z0)))) (real_mult (2#1) (real_plus M (real_opp A))).
(* 证: Re(f−f(z₀))≤M−A<2(M−A)·实部代数 *)

Lemma borel_caratheodory_main : forall (z : Cx),          (* 卡 ① 原式·显式常数 *)
  disk_member z0 R z -> real_lt (c_norm_sq (c_plus z (c_opp z0))) (sq (c_divq' r R)) ->
  real_le (c_norm_sq (c_plus (f z) (c_opp (f z0))))
          (sq (real_mult (c_divq' (mult_r (2#1) r) (real_plus R (real_opp r)))
                         (real_plus M (real_opp A)))).
(* 证: 辅助 g:=（f(z₀+w)−f(z₀))/(2(M−A)−(f(z₀+w)−f(z₀)))·分母实部>0⇒|g|≤1·C2.11⇒解出（卡 ①骨架=F2 SchwarzTransform 同构） *)
(* r:=|z−z₀| 端点承载·义务 L18（r 下界/R−r 正性 sigT 见证） *)
End BorelCaratheodory.
```
- **义务清单**：L17 实部上界承载（cRe 面）；L18 r 承载与 (2r/(R−r)) 常数证书。
- **证书面**：常数样点（r/R∈{(1/2),(3/4)} 形两样点）。
- **行数预算**：≈60＋30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_13_BorelCaratheodory.
Check borel_caratheodory_main.
Print Assumptions borel_caratheodory_main.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①主式与 F2 `borelCaratheodory` 常数逐因子咬合（2M‖z‖/(R−‖z‖)↔(2r/(R−r))(M−A)·平移差登记）；②辅助函数工艺四步与 F2 SchwarzTransform 节映射落卷；③C2.11 消费位 grep ≥1。

---

### C2.14 〔翻转簇·系数 0.50·W4〕GaC2_14_PhragmenLindelof

**挂卡**：全景卡 第二段 C2.14（行 478-486）｜**依赖正典**：C2.11, C2.12（spec §3.3 W4）｜**卡三档**：3.5/6/9（硬新地形·溢价上缘）

**稿一·先例研读卡**
- 先例件：F1（PhragmenLindelof.lean·全读）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F1 `vertical_strip`（f 于竖带·边界两线界+增长限制 ⇒ 闭带逐点 ‖f z‖≤C） | 主件（条带 0≤Re z≤1·\|f\|≤M₀/M₁ ⇒ \|f(x+iy)\|≤max(M₀,M₁) 逐点形） | **语句面/结论形直系对表**（先例结论即逐点形·边界线=hle_a/hle_b↔M₀/M₁·条带参数 a=0,b=1） |
| F1 辅件 `isBigO_sub_exp_exp`/`isBigO_sub_exp_rpow`（增长限制代数） | 拐杖函数 F_{ε,T}:=f·e^{εz²} 的增长代数组织 | 架构对表（截断乘子的增长账） |
| F1 `eq_zero_on_vertical_strip`/`eqOn_vertical_strip`（零/相等变体） | 不吸收（本节点主形） | 备查（同族变体·如需对表 C2.15 F 承载） |

- **吸收边界（两条·响亮）**：①**增长假设形差**：先例增长限制=∃c<π/(b−a),∃B, f=O[z↦exp(B·exp(c·\|im z\|))]（**双指数形**·F1 实读）；本卡=|f(x+iy)|≤A·e^{B\|y\|^ρ}·ρ<2（次二次+exp(εz²) 截断·卡 ①）——**语句形状吸收·增长限制形按卡维持**（ρ<2 形供下游 ζ 界消费更直接·登记为吸收边界第①条·禁误抄先例假设形）；②先例证明=最大模+紧化选择+双指数截断——树内 exp(εz²) 截断+矩形 [0,1]×[−T,T] 链式施 C2.11·双极限 ε→0/T→∞ 全显式管理（sigT (ε,T) 选择器·卡 ①构造性证明形）——构造化重铸全价（0.50 系数原文「研读省路线不省重铸」）；③复审条件最重（构造性 PL 文献覆盖未勘·R4 义务·卡 ④原文维持）。

**稿二·语句面稿（语句面 ≈90 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC1_Iface_Cx.      (* C1-16 e^{εz²} 可展性承载（卡 ②） *)
Require Import GaC2_11_MaxModulusDisk.  Require Import GaC2_12_CauchyCoeffEst.

Section PhragmenLindelof.
Variable f : Cx -> Cx.
Variable M0 M1 A B : Real.  Variable rho : Q.
Hypothesis Hrho : QltT rho (2#1).                          (* ρ<2 次二次·卡 ① *)
Variable Hloc : strip_local_exp f.                         (* 条带局部可展·C1-15 承载（义务 L19 定形） *)
Hypothesis Hb0 : forall y : Real,                          (* |f|≤M₀ 于线 x=0·平方承载 *)
  real_le (c_norm_sq (f (mk_cx real_zero y))) (sq M0).
Hypothesis Hb1 : forall y : Real,                          (* |f|≤M₁ 于线 x=1 *)
  real_le (c_norm_sq (f (mk_cx real_one y))) (sq M1).
Hypothesis Hgrow : forall (x y : Real), strip_member (mk_cx x y) ->
  real_le (c_norm_sq (f (mk_cx x y))) (grow_bound A B rho y).  (* ≤A²·e^{2B|y|^ρ}·rpow 承载义务 L20 *)

Lemma pl_strip_point : forall (z : Cx) (delta : Real),     (* 主结论·逐点形+显式 (ε,T) sigT 选择器 *)
  strip_member z -> real_lt real_zero delta ->
  { eps : Real & { T : Real & real_lt real_zero eps & real_lt real_zero T &
    pl_selector_ok f M0 M1 A B rho z eps T &               (* 选择器判据·cert 可计算面（义务 L21） *)
    real_le (c_norm_sq (f z))
            (real_plus (max_sq M0 M1) (sq delta)) } }.
(* 证: F_{ε,T}:=f·e^{εz²} 于矩形 [0,1]×[−T,T] 施 C2.11 ⇒ |F|≤max(M₀,M₁)·e^{ε(x²−T²)}·
   目标点与精度 δ 显式选 (ε,T)·双极限全显式管理·损耗闭式（卡 ①构造性证明形原文） *)
End PhragmenLindelof.
```
- **义务清单**：L19 strip_local_exp 承载（C1-15 定形）；L20 r_pow（\|y\|^ρ·Q 指数实幂·C1-05/06 备用）；L21 (ε,T) 选择器显式闭式（cert vm_compute 主位·卡 ③）。
- **证书面**：选择器样点（z 目标三点×δ 两档·字面＋vm_compute——本段 R2 最重证书面）。
- **行数预算**：语句面 ≈90＋cert ≈45 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_14_PhragmenLindelof.
Check pl_strip_point.
Print Assumptions pl_strip_point.   (* 期待 Closed·sigT (ε,T) 见证零公理 *)
(* cert 冒烟（施工席）：Compute zz_pl_selector_samples. 预算秒级·超即停改形态 *)
```

**稿四·验收判据**
- 基座五条＋专判：①结论与卡 ①「|f(x+iy)|≤max(M₀,M₁) 全条带逐点形」咬合（sigT (ε,T) 显式管理位）；②增长限制形=ρ<2 按卡（**禁误抄 F1 双指数形**·研读卡边界①复核）；③C2.11/C2.12 消费位 grep ≥2；④全段最高风险面登记（卡 ④需突破·复审条件最重·R4 义务在卷·禁降档）。

---

### C2.15 〔翻转簇·系数 0.50·W5〕GaC2_15_ThreeLines

**挂卡**：全景卡 第二段 C2.15（行 488-496）｜**依赖正典**：C2.01, C2.14（spec §3.3 W5）｜**卡三档**：3/5.5/8

**稿一·先例研读卡**
- 先例件：F9（Hadamard.lean·全读）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F9 `norm_le_interp_of_mem_verticalClosedStrip₀₁'`（hz∈闭带+DiffContOnCl+BddAbove+边界 a/b ⇒ ‖f z‖≤a^(1−re z)·b^(re z)） | 主定理（|f(x+iy)|≤M₀^{1−x}·M₁^{x}） | **语句形直系对表**（插值指数 1−x/x 逐因子咬合·条带同 0..1） |
| F9 `norm_le_interpStrip_of_mem_verticalClosedStrip₀₁`（interpStrip 承载主形） | 不吸收（interpStrip=sup 承载·树内零 sup） | 承载差登记：树内走 ′ 简化形（a/b 常数版） |
| F9 `interpStrip_eq_of_pos/of_zero`（端点零情形分支） | 端点 M₀=0∨M₁=0 分支处理 | 分支结构对表（先例 by_cases 两支·树内同构二分） |

- **吸收边界**：①先例前提 BddAbove（闭条带整体有界）——树内承载=C2.14 输出（PL 逐点界→有界性）——**hB 承载体对表差**（研读卡登记第②条）；②常数复幂 M₀^{1−z}M₁^{z} 承载=c_exp((1−x)ln M₀+x·ln M₁)（卡 ①·零分支问题）自铸·模代数（|M₀^{-z}|=M₀^{-x}）经 C2.01(b) 模公式。

**稿二·语句面稿（语句面 ≈55 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_01_DirichletPartialSum.  Require Import GaC2_14_PhragmenLindelof.

Section ThreeLines.
Variable f : Cx -> Cx.
Variable M0 M1 : Real.
Hypothesis HM0 : real_lt real_zero M0.  Hypothesis HM1 : real_lt real_zero M1.
Variable Hloc : strip_local_exp f.
Hypothesis Hb0 : forall y : Real, real_le (c_norm_sq (f (mk_cx real_zero y))) (sq M0).
Hypothesis Hb1 : forall y : Real, real_le (c_norm_sq (f (mk_cx real_one y))) (sq M1).
Hypothesis Hgrow : pl_growth_carry f A B rho.              (* C2.14 型增长限制·卡 ②·承载转嫁 *)

Definition lm0 : Real := real_log M0 HM0.                  (* ln M₀·零分支常数幂承载 *)
Definition lm1 : Real := real_log M1 HM1.

Definition c_const_pow (x t : Real) : Cx :=                (* e^{x·ln t}·常数复幂·零分支 *)
  c_exp (c_scale x (c_of_real t)).

Lemma three_lines_point : forall (x y : Real),             (* 卡 ① 原式·插值界 *)
  real_le real_zero x -> real_le x real_one ->
  real_le (c_norm_sq (f (mk_cx x y)))
          (cRe (c_mult (c_const_pow (real_plus real_one (real_opp x)) (c_mult_sq lm0))
                       (c_const_pow x (c_mult_sq lm1)))).
(* 证: F:=f/M₀^{1−z}M₁^{z}·|F|≤1 于两线（|M₀^{-z}|=M₀^{-x}·模代数·C2.01(b)）·C2.14 施于 F ⇒ 解出（卡 ①原文） *)
(* c_mult_sq t:=2·ln t（norm_sq 线性代入）·义务 L22 对表 *)
End ThreeLines.
```
- **义务清单**：L22 模代数（c_const_pow 模公式·c_exp 线性代入）；PL 双参数管理转嫁（继承 C2.14 复审条件·卡 ③原文）。
- **证书面**：插值指数样点（x∈{0,1/2,1}·M₀=M₁=2）。
- **行数预算**：≈55＋30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_15_ThreeLines.
Check three_lines_point.
Print Assumptions three_lines_point.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①与 F9 `norm_le_interp_of_mem_verticalClosedStrip₀₁'` 指数形逐因子咬合（a^{1−x}·b^{x}↔M₀^{1−x}M₁^{x}）；②C2.14 消费位 grep ≥1（Hgrow 转嫁链）；③端点零分支二分结构在卷（对表 F9 interpStrip_eq_of_zero）。

---

### C2.16 〔翻转簇·系数 0.50·W5〕GaC2_16_ZetaVerticalBound

**挂卡**：全景卡 第二段 C2.16（行 498-506）｜**依赖正典**：C2.02, C2.05, C2.07（spec §3.3 W5）｜**卡三档**：1.5/3/4.5

**稿一·先例研读卡**
- 先例件：F9（Hadamard.lean 竖线 sup 语句面）·**覆盖度=部分（诚实登记）**：显式分段竖线界（log t 档·零 FE 依赖）在已 fetch 七件内零直对表件；F8 文档字符串指向 `Mathlib/NumberTheory/Harmonic/ZetaAsymp.lean`（s→1 常数项·**未 fetch·禁引**——落刀前 R4 补检登记）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F9 `sSupNormIm f x`（竖线 sup 承载·`norm_le_sSupNormIm`） | 竖线界语句形状（沿 Re s=σ 线的一致界） | 语句形对表——树内以显式界替代 sup（承载差同 C2.11） |
| F6 `summable_riemannZetaSummand`（σ>1 级数可和） | (a) σ≥σ₀>1 段：\|ζ\|≤Σn^{-σ₀}≤凝聚显式和 | 语句形对表（C2.02 直消费·t 一致） |
| F8 `zeta_eq_tsum_one_div_nat_add_one_cpow` | (a) 级数承载位 | 项形对表 |

- **吸收边界**：(b)(c) 段（Abel 分部在 ζ 尾上的复用装配·C₁/C₂ 显式）零先例对应——纯消费装配（C2.07+C2.02 机成后直连·卡 ④ 可及判词）·0.50 系数按映射表行 11-18 段价执行·**禁因装配级降档**（段级系数带内·映射表原文「语句面全覆盖·构造化仅方法学」）。

**稿二·语句面稿（语句面 ≈70 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import S03_QExp.
Require Import GaC2_02_AbsConvTailBound.  Require Import GaC2_05_EulerLimitAsm.  Require Import GaC2_07_DirichletTestAbel.

Section ZetaVerticalBound.
Variable sig0 : Real.  Hypothesis Hs0 : real_lt real_one sig0.
Variable Hnpos : forall n : nat, real_lt real_zero (nat_real n).

Lemma zeta_vert_high : forall (t : Real),                  (* (a) σ≥σ₀>1 段·t 一致 *)
  real_le sig0 (cRe s_at t) ->
  real_le (c_norm_sq (zeta_s)) (cond_sq sig0).
(* 证: |ζ|≤Σn^{-σ₀}≤凝聚显式和（C2.02 直消费）·t 一致（卡 ①(a)） *)

Lemma zeta_vert_mid : forall (t : Real),                   (* (b) 1≤σ≤2·t≥2 段 *)
  (2 <= t)%Q2R 承载 -> real_le real_one (cRe s) -> real_le (cRe s) (2#1) ->
  real_le (c_norm_sq (zeta_s)) (sq (c_scale' C1 (log_t t))).
(* 证: |ζ−ζ_N|≤t^{1−σ}·2B_N 经 C2.07 机+|ζ_N|≤Σ_{n≤t}n^{-σ}≤C·log t·C₁ 显式（卡 ①(b)）·log_t 承载义务 L23 *)

Lemma zeta_vert_near1 : forall (t : Real),                 (* (c) 1−c/log t≤σ<1·dVp 消费窗 *)
  real_le (real_plus (real_one (real_opp (c_divq' c_win (log_t t))))) (cRe s) -> real_lt (cRe s) real_one ->
  real_le (c_norm_sq (zeta_s)) (sq (c_scale' C2 (log_t t))).
(* 证: 同机·σ−1 负裕度 e^{c} 吸收（卡 ①(c)）·C₂ 显式 *)
End ZetaVerticalBound.
```
- **义务清单**：L23 log_t 承载（ln t·t≥2 正性）；C₁/C₂/分段点证书（cert 主位·R2 正面样板·KB72 折价判例·卡 ③）；Q2R 承载定形。
- **证书面**：C₁/C₂/分段点字面样点带（t∈{2,10,100}·σ 三样点·vm_compute）——本节点 R2 证书主样板位。
- **行数预算**：≈70＋45 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_16_ZetaVerticalBound.
Check zeta_vert_high.  Check zeta_vert_mid.  Check zeta_vert_near1.
Print Assumptions zeta_vert_mid.   (* 期待 Closed *)
(* cert 冒烟：Compute zz_zeta_vert_samples. 秒级预算 *)
```

**稿四·验收判据**
- 基座五条＋专判：①三段界与卡 ①(a)(b)(c) 逐条咬合（C₁·log t/C₂·log t/凝聚和）；②cert 字面证书 vm_compute rc=0（R2 正面样板·KB72 判例对表）；③C2.07/C2.02/C2.05 消费位 grep ≥3；④FE 零依赖自检（词面普查：无 functional equation 消费·卡 ①标题义务）。

---

### C2.17 〔翻转簇·系数 0.50·W6〕GaC2_17_StripVerticalAsm

**挂卡**：全景卡 第二段 C2.17（行 508-516）｜**依赖正典**：C2.07, C2.10, C2.16（spec §3.3 W6）｜**卡三档**：2/4/6

**稿一·先例研读卡**
- 先例件：F7＋F9·覆盖度=部分（η-路条带均匀界零直对表件·消费装配级）。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F7 `LFunction_eq_LSeries`/`differentiable_LFunction`（非平凡 χ 全平面可微·延拓谱） | ζ̃ 承载消费位（(a) 段经 C2.10） | 延拓域语句形对表 |
| F9 `norm_le_interp_of_mem_verticalClosedStrip₀₁'`（插值形） | (c) 覆盖合并的组织参照（分段边界显式） | 架构对表（分段插值界组织）·**凸性界主件不吸收**（见边界①） |

- **吸收边界（响亮两条）**：①**FE 缺口（卡 ①诚实边界原文维持）**：全条带凸性界 |ζ(1/2+it)|≤C·t^{1/4+ε} 型（log³ 档备料）需 functional equation 的 σ=0 端 t^{1/2} 界——**FE 节点不在 KB34 C1-C4 清单内·本段不含·响亮登记**→C3/C4 勘形按 log² 档定形或 FE 增节点复审（KB34 降链案 α 已取 log² 档·一致）；②分母下界 \|1−2^{1−σ}e^{iθ}\|≥2^{1−σ}−1 模代数**零周期性依赖**（卡 ③·C2.08 denom_lower_bound 直消费）。

**稿二·语句面稿（语句面 ≈60 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_07_DirichletTestAbel.  Require Import GaC2_10_EtaContinuation.  Require Import GaC2_16_ZetaVerticalBound.

Section StripVerticalAsm.
Variable delta : Real.  Hypothesis Hd : QltT 0 delta.  Hypothesis Hd1 : QleT delta (1#1).

Lemma zeta_strip_uniform : forall (s : Cx) (Hd2 : denom_nz s),   (* (a) σ≤1−δ 均匀界 *)
  real_le real_zero (cRe s) -> real_le (cRe s) (real_plus real_one (real_opp delta)) ->
  real_le (c_norm_sq (zeta_tilde s Hd2)) (sq (c_scale' (2#1) (c_invq (two_d_sub delta)))).
(* 证: η 路：|ζ|=|η|/|1−2^{1−s}|·|η|≤1+2·2^{−σ}≤3（C2.07 一致尾）·
   分母下界 2^{1−σ}−1（C2.08 denom_lower_bound）·|ζ|≤2/(2^{1−σ}−1)≤2/(2^{δ}−1)（卡 ①(a) 原式） *)
(* two_d_sub:=2^{δ}−1·正性经 Hd·c_invq sigT 逆元·义务 L24 *)

Lemma zeta_strip_cover : forall (s : Cx),                 (* (c) 全消费域 0≤σ≤2 分段覆盖·分域边界显式 *)
  real_le real_zero (cRe s) -> real_le (cRe s) (2#1) ->
  zeta_vert_bound_disj s.        (* 三段析取承载·分域边界显式·QleT'/real_le 顺序式（坑卡雷区登记） *)
(* 证: (a)+(b 近 1 窗=C2.16(c)) 覆盖合并·卡 ①(c) *)
End StripVerticalAsm.
```
- **义务清单**：L24 two_d_sub 正性与逆元见证；zeta_vert_bound_disj 析取承载定形；(b) 段=C2.16(c) 直消费（禁复制）。
- **证书面**：δ 分点样点（δ∈{1/10,1/4}·2^δ−1 下界字面）。
- **行数预算**：≈60＋30 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_17_StripVerticalAsm.
Check zeta_strip_uniform.  Check zeta_strip_cover.
Print Assumptions zeta_strip_uniform.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①(a) 式与卡 ①「\|ζ(σ+it)\|≤2/(2^{1−σ}−1)≤2/(2^{δ}−1)」逐因子咬合；②**FE 缺口响亮登记在卷**（稿一边界①·词面普查：无 FE 消费）；③C2.08 denom_lower_bound/C2.16(c) 消费位 grep ≥2（禁复制·直依）。

---

### C2.18 〔翻转簇·系数 0.50·W7〕GaC2_18_ZetaDerivBound

**挂卡**：全景卡 第二段 C2.18（行 518-526）｜**依赖正典**：C2.09, C2.10, C2.12, C2.16, C2.17（spec §3.3 W7·段内最深波）｜**卡三档**：1.5/2.5/4

**稿一·先例研读卡**
- 先例件：F7（deriv 面）·覆盖度=部分。
- 逐引理映射：

| 先例引理（fetch 坐标） | 本节点语句 | 吸收方式 |
|---|---|---|
| F7 `deriv_LFunction_eq_deriv_LSeries`（1<re s 导数与级数导数重合·语句形） | (a) 消费域导数界语句位（ζ′ 承载形） | **导数面语句形对表**（导数与局部承载一致形） |
| F7 `deriv_LFunctionTrivChar₁_apply_of_ne_one`（平凡特征导数界·s≠1） | s=1 极点除去形 | 语句形对表 |
| F8 `differentiableAt_riemannZeta`（s≠1） | 局部圆盘可展前提位 | 前提形对表 |

- **吸收边界**：①mathlib 导数承载=Differentiable/deriv 全局理论——树内 ζ′ 承载=C2.12 nth_coeff 1（局部展开一阶系数·R3 定形同源）——**承载差登记（研读卡第③条）**；②(a) 路线（局部圆盘 B(s₀,r)⊂消费域·r=dist/2·r 对零点集距离下界显式经 C2.09·|ζ|≤C₂log T·C2.12 n=1 ⇒ |ζ′(s₀)|≤2M/r）全自铸装配（卡 ①原文）；③(b) 诚实边界：σ 深于 1−c/log T 的高阶导数界（C3 VK 层消费形）**不在本节点闭域**·登记 C3 勘形复审（高 n 同机·常数累积核算归 C4.3·卡 ①原文）。

**稿二·语句面稿（语句面 ≈55 行预算）**

```coq
Require Import S02_CauchyComplete.  Require Import CxRealPairCore.  Require Import CxRealPairExpLog.
Require Import GaC2_09_DenomZeroSet.  Require Import GaC2_10_EtaContinuation.
Require Import GaC2_12_CauchyCoeffEst.  Require Import GaC2_16_ZetaVerticalBound.  Require Import GaC2_17_StripVerticalAsm.

Section ZetaDerivBound.
Variable T : Real.  Hypothesis HT : (2 <= t_cap T).        (* 消费域 |t|≤T·T≥2·承载义务 L25 *)

Lemma r_pos_lower : forall (s0 : Cx),                      (* 局部圆盘半径下界·零点距离显式 *)
  consumer_domain T s0 ->
  { r : Real & real_lt real_zero r &
    dist_lb_ok s0 r &                                      (* r=dist(s₀,零点集)/2·C2.09 零点集消费（义务 L26） *)
    disk_in_consumer T s0 r }.                             (* B(s₀,r)⊂消费域·显式几何 *)
(* 证: C2.09 zero_set_membership（零点全在 Re=1 线）+消费域距离代数（卡 ①路线） *)

Lemma zeta_deriv_bound : forall (s0 : Cx),                 (* (a) |ζ′(σ+it)|≤C₃·log²T·显式 *)
  consumer_domain T s0 ->
  real_le (c_norm_sq (nth_coeff 1 (local_exp zeta_tilde s0)))
          (sq (c_scale' C3 (sq (log_t T)))).
(* 证: 局部圆盘内 ζ 可展（C2.10）·|ζ|≤C₂ log T（C2.16/17）·C2.12 n=1 形 ⇒ |ζ′(s₀)|≤2M/r ⇒ C₃ 显式（卡 ①原文） *)
(* nth_coeff 1 = ζ′ 承载·与 C2.12 L16 同源定形·C₃ 显式证书（cert） *)
End ZetaDerivBound.
```
- **义务清单**：L25 消费域承载（σ≥1−c/log T·\|t\|≤T 型·卡 ①）；L26 零点距离下界（C2.09 输出形对表·消费接口）；C₃/r 下界证书（cert）。
- **证书面**：C₃ 与 r 下界样点（T∈{10,100}·σ 两样点·vm_compute）。
- **行数预算**：≈55＋35 ≤400 ✓。

**稿三·REPL 预演脚本（不执行）**

```coq
Require Import GaC2_18_ZetaDerivBound.
Check r_pos_lower.  Check zeta_deriv_bound.
Print Assumptions zeta_deriv_bound.   (* 期待 Closed *)
```

**稿四·验收判据**
- 基座五条＋专判：①(a) 与卡 ①「\|ζ′(σ+it)\|≤C₃·log²T」咬合（平方承载差登记）；②五依赖消费位 grep ≥5（C2.09/10/12/16/17 全咬合·W7 最深波 LINT-1 复测位）；③(b) 诚实边界显式不在稿内（C3 复审登记行在卷）；④段尾节点——GaC2_Iface_VL（C2.11-18 转供 ≤8·§2.3 表）波末产出入账位。

---

## 五 · 段级收口账

1. **四稿齐全**：18 节点×4 稿（研读卡/语句面/REPL/验收）＝72 稿齐（本卷 §四逐节点）。
2. **分簇**：翻转簇 18/18·维持簇 0（§〇 定谳）·系数带 0.30-0.50 全落 ask 给带 0.3-0.6 内。
3. **Iface 出账**（§2.3 表）：GaC2_Iface_DS（C2.01-05·5）/GaC2_Iface_Eta（C2.06-10·5）/GaC2_Iface_VL（C2.11-18·8）——γ2 波末联合认证交付·禁提前铸空壳（规范 §2.3 产出时点）。
4. **跨段消费登记**：C2 全段消费 L1 经 GaC1_Iface_Real（C2.06）/GaC1_Iface_Cx（C2.07/09/10/11/12/14·C1-14/15/16/17 位）·禁直依他段 stem（LINT-2/§2.4-③）。
5. **R2 证书面分布**：vm_compute 主位＝C2.02（几何常数）/C2.03（K_p 表）/C2.04（尾界）/C2.05（N₀ 表）/C2.07（尾界样点）/C2.08（修正常数）/C2.11（增益 c）/C2.13（常数）/C2.14（(ε,T) 选择器·最重）/C2.15（插值）/C2.16（C₁/C₂·正面样板）/C2.17（δ 分点）/C2.18（C₃/r）；无可计算面声明＝C2.01/C2.06/C2.09/C2.10（LINT-5 豁免条）。
6. **复审条件段级汇总**（卡册 R6 义务·四稿后逐卡在卷）：①C2.09 周期性（Bishop 系 R4）②C2.14 构造性 PL 覆盖（R4 最重）③C2.10 可去奇点跨段（C3）④C2.17 FE 缺口（C3/C4 log² 定形）⑤C2.12 无积分 Cauchy 估计先例补检（本席新增·F 件未核登记）⑥C2.16 ZetaAsymp.lean 补检（本席新增·未 fetch 禁引登记）。
7. **席时**：段三档 41/72.5/108（卡册对账·基准 72.5 与重估 72 咬合）·吸收式段三档 16/32/48（映射表 §①-3）·**两账并行登记·施工预算以吸收式重估卷为准·判词禁降档义务不变**。

## 六 · 未做/未验（fail-honest）

- **零编译**：四关四件套/REPL 脚本/coqchk 全数未跑（脚本形态禁执行·执行卷 §1.3）；稿二 Coq 块为勘形形·未过任何词法/类型检查——占位符（N'/…/s0 等）与义务 L1-L26 在各稿显式列名·落刀席逐项销号。
- **fetch 覆盖界**：mathlib 侧未 fetch＝ZetaAsymp.lean/HurwitzZeta*.lean/Nonvanishing.lean/AbsMax.lean（C2.12/C2.16 复审条件⑥位登记）；raw.githubusercontent WebFetch 间歇 ECONNRESET 与 curl 超时实录在案（§一勘误）。
- **树内未复验面**：`pr_prime_bool`（C2.03·零命中实录）；pec_win 定义体（仅注释面+消费面实读）；factors 类素分解枚举承载（落刀钉取）；local_exp_disk/deriv1/nth_coeff 等承载形为**本稿提议名**（非树内现役·C1-15 输出对表后定形·禁当树内 ID 消费）。
- **网络纪律**：contents API 逐发间隔 15-30s·零并发抓取·零截断回执。

## 七 · 反验证锚

```bash
ls "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C2.md"                                   # 本稿在盘
grep -c "^### C2\." "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C2.md"                  # =18（逐节点）
grep -c "稿一·先例研读卡" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C2.md"            # =18
grep -c "稿二·语句面稿"   "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C2.md"            # =18
grep -c "稿三·REPL 预演脚本" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C2.md"          # =18
grep -c "稿四·验收判据"   "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C2.md"            # =18
ls "D:/ComplexAnalysis/attn/kbgamma_work_20261101/_c2fetch/"                                      # fetch 先例件 9 件在盘
```

——C2 段四稿勘形稿完（20261101·勘形员·C2·18 节点×4 稿·全翻转簇吸收式·零编译零写树·fetch-before-cite 9 发全录·禁猜 ID 双台账·fail-loud 六节）
