# C3 段全景卡（γ0 勘形批·普查员·C3·20261101）

> **席位**：普查员·C3（γ 段全景卡普查·零编译零写树·先期调研）。本席产出唯一落位＝本件 `cards_C3.md`。
> **依据正本**：回执-KB34-γ阶段一定价-20261027.md（定价正本·D3 表 :93-99）｜工单-γ解析核段战役总设计-20261101.md（宪法卷·R1-R6 :33-40·γ3 行 :49）｜勘形-γ解析核段重估-20261101.md（fresh 单价判例 :50-70、:83）｜回执-γ段重估-20261101.md｜回执-KB33-γ路P0勘路-20261027.md（十四引理/消费形/槽形坐标）｜工单列表-待派工作流优先序-20261030.md（行 13 :38/:115·令 3 续文献复检 dwfrun-c480aacc 在飞）。
> **估席时锚**（ask 指定）：KB57 B6/B7 判例＝7 节点/17.7M tok/1-2 席日 → **1.1-2.3 席时/节点**（转录·装配档，重估 :50）；新地形单块溢价 **×3-4**（KB36R 零点刻画 30 发/0.5 席日判例，重估 :52）；重常数证书 vm_compute 折价（KB72 判例，重估 :53）；对齐重估 fresh 单价：C3 段基准 5.5-7 席时/节点（:63）、Perron 乐观 4/基准 8/悲观 12（:83）。
> **纪律**：R1 勘形前置（本件＝三稿之第一稿·数学命题卡）｜R2 计算证明分离（数值面 vm_compute 证书化标注入各卡③）｜R4 全库重用（⑦为 R4 检索输入）｜R6 逐节点三档分级·复审条件必填（12 零先例卡全附）·禁降档·证据不足写「待勘」。
> **诚实声明**：本席**全程零网络**——⑦先例检索词是供 R4 实检的输入（非命中断言）；文献坐标（Ford/Kadiri/Platt–Trudgian 常数等）出自本席数学面知识，**未经本会话网络核实**，R4 照 fetch-before-cite 复核；树内坐标逐处标注本会话实读出处。
> **⚠ 分段口径异见登记（响亮）**：KB34 正本（:97-98）C3＝零点自由区 28 节点（dVp 10＋VK 18）·Perron 12 记 C4.1；总设计 γ3 行（:49）与 ask 均记「C3 段 28 节点·含 Perron 12」。本卡**照 ask/总设计 执行**：28 卡＝Perron 12（P01-P12）＋零点自由区 16（dVp 10：Z01-Z10＋VK 核 6：V01-V06）；KB34-C3 的 **VK 残 12 节点本席未辖**（候选细目见文件尾「未辖余量名单」）——归属（并入 C4 段席 or 追补 ask）候主会话裁定，防重卡防漏卡。

---

## 第一块 · Perron 围道 12 节点（战役重心·全球零先例·逐卡四稿）

> KB34:98：「围道积分/Perron 截断 12/5.0（树内零积分理论·最大单件·全球零先例）」；重估 :66-70：前置链 24-44 节点末端·新地形连续 12 节点（积分定义→围道→参数化→截断→估计）。
> **勘形修正注记（R1 价值）**：经典有效 PNT 路（dVp 档·Schoenfeld/Dusart 2010 同型）把围道左沿压进零点自由区，矩形域内**唯一奇点＝s=1 单极点**——**无需逐零点求和 Σ_ρ x^ρ/ρ，也无需零点计数密度 N(T)**（零点全被 ZFR 挡在围道外）。此修正砍掉两类经典深坑，P10/P11 命题已按此铸形。
> **⚠ R4 全块碰撞警告**：「Perron」三义——①Perron 公式/围道（本块）②Perron–Frobenius 定理（AFP 有同名先例·无关）③Perron 积分（Denjoy–Perron·实积分论·无关）；检索时三义必分。

### C3-P01 · 复线积分定义（分段光滑路径·构造性基元）〔零先例链头〕
- **① 数学命题**：设 γ:[a,b]→ℂ 为分段 C¹ 路径（有限分段，每段导数连续），f:ℂ→ℂ 连续。定义线积分 ∫_γ f dz ＝ Σ_j ∫_{a_{j-1}}^{a_j} f(γ(t))·γ'(t) dt（每段为实区间上复值函数的 Riemann 型积分），并证：该定义良定（每段积分存在且和与分段加细无关）。Set 承载形：复域＝CxRealPair（树 real 线自铸·born），实参数区间、被积复值函数全构造性。
- **② 依赖的既有机器**：树内——CxRealPairCore.v（312 行/48 名·born 未落装）、CxRealPairExpLog.v（520 行/18 名·born：c_exp 极坐标/c_log 诚实接口）｜**实积分基元树内为零**（KB34:98「树内零积分理论」原判·本会话未见反证）→ 本件内含实积分新铸面｜C1.1 实有效界件（积分估计的上/下界输入形）｜外部理论参照——CoRN 构造实数积分论（IR 上的积分·转录候选）、UniMath 积分论、mathlib `intervalIntegral`（参照级·非构造禁直用，红线一）。
- **③ 形式化难点预判**：证明面＝构造性 Riemann 和极限（一致连续→可积性·构造性实分析纪律下一致收敛交换需显式模）；路径良定性（重参数化加细不变）。可计算面＝少（但可选区间积分证书器供 P09 常数面）。
- **④ 三档初判**：**需突破**——树内零积分理论＋全球构造性复积分零先例（KB34/重估 :66-70 双卷判·本会话实勘零反证），Perron 12 链头件。〔复审条件：R4/闸 1 若检出 CoRN/UniMath/构造性复分析可转录积分论→本件转「吸收式」折价；CxRealPair 两件落装后复勘〕
- **⑤ 前置节点**：C1.3（CxRealPairCore·born 须 γ1 波末落装）、C1.4 已毕 4 节点、C1.1（实有效界）；γ3 候 γ2（总设计 :49 批序）。
- **⑥ 估席时**：基准 **10-14 席时**（全新地形铸件·重估 :83 Perron 悲观 12 上探＋KB36R 溢价律·非 B6/B7 锚适用件）。
- **⑦ 先例检索词（供 R4·双倍档）**：中：构造性复分析/线积分 形式化/复值函数 黎曼积分/CoRN 积分/UniMath 积分论。英：constructive complex analysis; line integral formalization; contour integral Coq; complex-valued Riemann integral; CoRN integration constructive reals; UniMath integration theory; Isabelle HOL-Analysis Contour_Integration（Wenda Li·参照级）；mathlib intervalIntegral contour。⚠碰撞：Perron–Frobenius（AFP 同名）、Perron number（组合论）、**Denjoy–Perron integral（实积分论·词面撞车高危）**。证伪面（预期零命中·供闸 1 定谳）：AFP "Perron integral complex"; Coq Perron contour integral。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 prec_fetch/fetch_ledger_20261103.md）**：先例件＝AFP Perrons_Formula.thy（Eberl·2026-06-17·发次 #1 fetch＋在盘源件实测）｜**系数 0.55**（drafts_C3 §② 行 1-2）。实测坐标（本席 grep/sed）：`L ≡ λc T. linepath (Complex c (−T)) (Complex c T)` :51-53＋`perron_aux_integral a c T = contour_integral (L c T) (λz. of_real a powr z / z)` :56-57＋`contour_integral_primitive` 用例 :74——竖线围道定义形与三实参签名全数在案。实测差：contour_integral/linepath/rectpath 全为 HOL-Analysis 内建（AFP 消费不重证）→树内零积分理论判词维持（KB34:98），P01 定义层 Set 承载自铸全价；有限 T 截断形（:51-53 形状·禁无穷限）与吸收清单①一致。施工后果：0.55 只省研读不省自铸；W1 链头·本波施工位。
- **⑨ 施工记录（20261103·两片落袋·节点闭）**：`seg_C3/GaC3_P01_LineIntegralDef.v` 首片 245 行/具名项 17（cell·cw·qstep_sumR/I·step_integral 五定义＋qstep_sumR/I_cons·cmuloQ·cofQ_eq·split_block_R/I·split_invariant_append_R/I·step_concat_R/I·step_integral_const·vline_const_seed 十二证明）。**第二片（同日续推席）**：＋112 行→**357 行/具名项 27**——新增 split_cell（单格切分）·split_cell_cw_R/I·split_map_R/I（**均匀逐格切分不变·map-split 不变式**）·step_integral_split_map·refine_pt（逐格各自切分点）·refine_pt_R/I·step_integral_refine_pt 八件——**良定性种子面（分段加细不变）落袋**。**四关（两片全量）全绿**：rc=0（_log_P01_s2_r1.log·1 轮）、PA 20/20 Closed（_log_pa_P01_20261103_s2.log）、coqchk own rc=0＋Axioms `<none>`（_log_chk_P01_own_20261103_s2.log）；LINT-5 vm_compute 词面=0·LINT-6 357≤400·零 Axiom/Parameter/Admitted·禁无穷限 grep=0（词面 2 命中均为纪律注释）·md5 3d6637e98f9e92acae24b6f385d353a8 入 _md5_ledger_c3.txt。**面注记**：步积分载体＝Q-步数据（Perron 链消费形——P08 被积经 Z01 级数部分和即 Q-步数据）；**广义连续被积的存在面（一致连续模显式化）诚实开口**——降深面登记·消费位展开时复勘；路径型 cpath/line_integral 具名项归 P02（drafts P02 骨架本以 line_integral 为工作定义）。**节点闭（scoped）**。
### C3-P02 · 线积分代数（线性/拼接/反向/重参数化不变）
- **① 数学命题**：线积分满足：∫_γ(αf+βg)＝α∫_γ f＋β∫_γ g；路径拼接 γ=γ₁⌢γ₂ 时 ∫_γ＝∫_{γ₁}+∫_{γ₂}；∫_{γ⁻¹}＝−∫_γ（γ⁻¹ 反向）；若 φ 是 [a,b]→[c,d] 的单调 C¹ 满掖变换（保持分段光滑）则 ∫_{γ∘φ} f dz＝∫_γ f dz。全构造性显式。
- **② 依赖的既有机器**：树内——P01 定义；同类代数搬运工艺树内厚（ln_rate_bound 系/HansonLcm 整除代数·工艺参照）。外部：无新理论（标准分析代数）。
- **③ 形式化难点预判**：证明面＝Riemann 和逐件搬运＋分段边界点处理（纯代数档）。可计算面＝无。
- **④ 三档初判**：**可及**——P01 定义绿后即转录级代数·树内同工艺判例密集（B6/B7 锚直用）。
- **⑤ 前置节点**：P01。
- **⑥ 估席时**：基准 **3-5 席时**（KB57 B6/B7 锚 1.1-2.3×段内新环境系数≈1.5）。
- **⑦ 先例检索词（供 R4）**：中：线积分 可加性/路径拼接 积分/换元 积分不变。英：line integral additivity; path concatenation integral; change of variables line integral; reparameterization invariance contour integral。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1＋在盘实测）**：先例件＝Perron_Prerequisites.thy｜**系数 0.55**。实测坐标：`contour_integral_rmul` :447／`contour_integral_lmul` :462／`contour_integral_divide` :465（线性三件·命题形状逐字在案）＋`perron_aux_integral_1` :68（c>0 时竖线积分＝2·arctan(T/c)·i 闭形链）。实测差：线性三件建在 HOL-Analysis 代数闭包上→树内 P01 自铸后同构代数照抄骨架、证明体重铸；拼接/反向/重参数化 AFP 未单列（从零档确认）。施工后果：0.55 研读省时·代数件从零施工维持。
- **⑨ 施工记录（20261103·续推席·节点闭·两文件）**：`seg_C3/GaC3_P02_LineIntegralAlg.v`（stem·314 行/具名项 26）＋`seg_C3/GaC3_P02_LineIntegralAlg_b.v`（叶·146 行/具名项 10——LINT-6 触发波内叶化拆分：初稿单件 420 行超谱·照规范 §4.1 拆分次轴切 Section 7 反向律入叶·叶 Require stem 非互锁）。语句面：vertex/pseg/cpath/vline_seg（AFP L c T :53 形转录）/hline_seg/plen_ok/seg_dz/seg_contrib/path_sumR/I（Fixpoint）/line_integral 十定义＋path_sumR/I_cons·cploQ·coppoQ·line_integral_nil·vline_const（2T·i·v 路径级）·hline_const·path_concat_R/I·line_integral_concat·contrib_vmul_R/I（逐段双线性）·path_sumR/I_vmul·line_integral_linear（AFP contour_integral_lmul :462 形状·步层重建）·contrib_rev_R/I·qplus_0_r·qneg_swap·path_sumR/I_rev·path_reverse·line_integral_reverse 二十二证明。**四关全绿**：rc=0（stem _log_P02_r14.log·14 轮中 5 红——Fixpoint 误 Definition/ring 原子律 4 红；叶 _log_P02b_r1.log·1 轮）、PA 22/22 Closed（_log_pa_P02_20261103.log）、coqchk own rc=0＋Axioms `<none>`（_log_chk_P02_own_20261103.log·双模块同炉）；LINT-5 vm_compute=0·LINT-6 314/146≤400·零 Admitted·md5 b242dcc2ac3f9b2a09d1e5fdcb64f6d4＋3c2448dd269d50c66f226c7e8252490b 入 _md5_ledger_c3.txt。**工艺教训（本波定谳）**：ring 战术不吃「delta-可约常数应用」原子（seg_contrib/Fixpoint cons 应用在环目标内即 `not a valid ring equation`——五红根因·探针 _probe_ring.v 三发定谳）——对策＝逐对变量全拆＋纯 Q helper（qplus_0_r/qneg_swap）＋apply·禁 ring 混合目标。**重参数化不变面诚实开口**（monotone C¹ covering＝Real 层·步层级细化面已由 P01 split_map/refine_pt 承载）——降深面登记非降档。**节点闭（scoped）**。
### C3-P03 · ML 估计（路径长×上界·构造性）
- **① 数学命题**：γ 分段光滑、f 连续且在 γ 像上有**显式上界** M（输入形证书·非 sup 存在断言），L(γ)＝Σ_j∫|γ'(t)|dt 为路径长，则 |∫_γ f dz| ≤ M·L(γ)。配套：常见路径（水平/竖直线段、矩形四边）L 的闭式与 |γ'| 积分证书。
- **② 依赖的既有机器**：树内——P01/P02；C1.1 实有效界件（M/L 的 Q 证书输出形）；R2 纪律（L、M 数值面 vm_compute 证书化）。
- **③ 形式化难点预判**：证明面＝Riemann 和三角不等式（短）。可计算面＝L(γ)/M 的 Q 区间证书（R2 正形·zzPhi 判例）。
- **④ 三档初判**：**可及**——P01 绿后直接档·Perron 全链的估计引擎件（P09/P11 消费）。
- **⑤ 前置节点**：P01、P02、C1.1。
- **⑥ 估席时**：基准 **3-4 席时**（B6/B7 锚×1.5）。
- **⑦ 先例检索词（供 R4）**：中：围道积分 ML 不等式/路径长 可求长/积分估计引理。英：ML inequality; estimation lemma contour integral; rectifiable path length formalization; integral triangle inequality complex。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1＋在盘实测）**：先例件＝Perron_Prerequisites.thy｜**系数 0.35**。实测坐标：`contour_integral_bound_linepath'` :372-375（**ML 型逐字先例**：0≤B→∀x∈closed_segment·‖f x‖≤B→‖∮_{linepath a b} f‖ ≤ B·‖b−a‖）＋`contour_integral_linepath_same_Im` :378-395（竖线→实区间积分归约）。实测差：零（两坐标与 drafts §② 行 3 逐点吻合·0.35 骨架抄写最快带确认）。施工后果：P03 语句面以 :372-375 形状为正本·「显式上界 M 输入证书形」构造性化照 cards ①。
- **⑨ 施工记录（20261103 续批席·节点闭·两文件）**：`seg_C3/GaC3_P03_MLEstimate.v`（stem·288 行/具名项 15）＋`seg_C3/GaC3_P03_MLEstimate_cert.v`（证书面·36 行/3 名）。语句面：path_len1（L1 路径长·Q 精确无开方）·val_bounded（逐分量值界）·contrib_abs_le_R/I（逐段绝对贡献界）·path_sumR_ml/path_sumI_ml（**ML 主件：|Re Σ| ≤ B·L1 与 |Im Σ| ≤ B·L1**——AFP :372-375 形状的逐分量重建）·line_integral_ml_pair·len1_vline/len1_hline（闭式长 2T·x₁−x₀）·ml_vline/ml_hline（P08/P09 消费形）＋证书面 vm_compute 三样点（长闭式×2＋ML 实例 |−80|≤100）。**四关全绿**：rc=0（stem _log_P03_r12.log·12 轮中 9 红——Qabs 链/Qeq-rewrite-in-Qle/吸收引理名序等；cert _log_P03cert_r3.log）·PA 16/16 Closed（_log_pa_P03_20261103.log）·coqchk own rc=0＋Axioms `<none>`（_log_chk_P03_own_20261103.log·双模块同炉）；LINT-5 stem 剥注释=0（唯一词面命中系头注·已改写复编译）cert 命中=3·LINT-6 288/36≤400·零 Admitted·md5 ad435605a4c11eafe0bdbcf2018ebc97＋d220d97c8447100940f41c3f03b1869d 入 _md5_ledger_c3.txt；ls 断言 ✓（两 .vo 在 seg_C3）。**面注记**：same_Im 归约（:378-395）在此载体**定义性成立**（竖线积分即 Q 和·免单独定理）；平方范数 B·L 形（Qsqrt-free 序面）诚实开口·降面登记。**节点闭（scoped）**。
### C3-P04 · Cauchy–Goursat 定理（矩形构造性版）
- **① 数学命题**：f 在闭矩形 R 上全纯（复可微，导数连续版足用——Goursat 免连续版列为后续折价件），则 ∮_{∂R} f dz＝0。推论（原函数存在）：矩形域内 f 连续＋∂R 零积分条件（或全纯）⇒ 存在原函数 F，F'＝f，且积分路径无关。
- **② 依赖的既有机器**：树内——P01-P03；复可微承载面在 CxRealPairCore 48 名中的实况**本席未逐名勘定（待勘·R4 树内实检）**；C1.4（一致收敛/级数面）。外部参照——Isabelle HOL-Analysis Contour_Integration/Winding（Wenda Li 2018·参照级·经典逻辑需构造性重铸）；mathlib CauchyIntegral/winding number（参照级）。
- **③ 形式化难点预判**：证明面＝Goursat 四分割迭代＋构造性取极限（一致连续模显式化·构造性实分析下「紧致性取极限」须以显式模重述——本块最深证明面之一）。可计算面＝无。
- **④ 三档初判**：**需突破**——Perron 链核心理论件·构造性重铸无先例。〔复审条件：Isabelle/mathlib Cauchy 理论若被 R4 确认为可转录形→按「吸收式」重估折价；C1.4 残件收敛面绿后复勘〕
- **⑤ 前置节点**：P01、P02、P03、C1.4。
- **⑥ 估席时**：基准 **8-12 席时**（深新地形·KB36R 溢价上限档）。
- **⑦ 先例检索词（供 R4·双倍档）**：中：柯西积分定理 构造性/古萨定理/围道内零积分/单连通 原函数。英：Cauchy integral theorem formalization; Cauchy-Goursat constructive; rectangle contour integral zero; Isabelle Contour_Integration Winding_Number; mathlib CauchyIntegral circleIntegral; primitive existence simply connected; homotopy invariance integral formalization。证伪面：AFP "Cauchy integral theorem"（预期零命中）；Coq Cauchy-Goursat（预期零命中）。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1＋在盘实测）**：先例件＝Perrons_Formula.thy（路线）｜**系数 0.40**。实测坐标：`R b ＝ rectpath (Complex c (−T)) (Complex b T)` :129-131＋`path_image (R b) ⊆ cbox (Complex c (−T)) (Complex b T)` :134-136＋`Cauchy_theorem_convex_simple` 用例（矩形围道零积分）:134-140＋四边展开（vline c ＝ vline b − hline c b + hline′ c b·eventually 形）:141-153＋`contour_integral_primitive` 用例 :74（原函数路线）。实测差：Cauchy/Goursat 本体全在 HOL-Analysis 内建（AFP 零证明面）→四分割 Goursat 迭代树内构造重铸全价·「紧致性取极限→显式模」自铸位确认。施工后果：矩形围道四边分解恒等式形状（:143-153）为 P10 语句面直接消费形状。
- **⑨ 施工记录（20261103 续批席·未闭·部分落袋＋执行环境挂起登记）**：`seg_C3/GaC3_P04_CauchyRect.v` 已落（约 165 行/具名项 5：rect_boundary（AFP R=rectpath :129 形）·cauchy_rect_const（**常值被积闭环零——步载体的 Cauchy 零面**）·rect_four_edges（**AFP contour_integral_rectpath 展开 :145-151 形状·任意逐边值数据**——P10 消费形）·vline_shift_const（:143-153 移位形状·常值档）＋cploQ/coppoQ 桥接复用）。**语句面独立编译 exit=0**（_p04_stmt_probe.v·仅语句＋Abort 的诊断探针）；**证明体执行挂起（fail-loud）**：r6 起三发（r6·r6b·probe 改名副本）coqc 全部冻结于解析后战术执行前（cpu≈0.02s·工作集 6-8MB·1 线程·零进展 20 分钟级）——同环境对照：min_test/ladder1/ladder2（含 P01+P02 载入）与语句探针全数正常退出，唯独 P04 证明体触发挂起；四僵尸 coqc（PID 12228/14412/26016/26288）**零 taskkill 未动**·候主会话处置；r1-r5 红账（语法括号 2·类型失配 1·显式 trans 实例失配 1）已悉数修正（证据 _log_P04_r1..r5.log）。**深水面登记（禁降档）**：全纯 Cauchy–Goursat 本体（f 全纯 ⇒ 环积分零）为卡面主定理——born 载体无全纯谓词（复可微机器＝载体缺口·cards ② 待勘项）→本切片仅承载围道代数＋常值档面·**节点保持开口**·候载体补铸＋执行环境修复后复炉。**原函数存在推论未铸**（同候）。
### C3-P05 · Cauchy 积分公式＋Cauchy 导数不等式
- **① 数学命题**：f 在矩形/圆盘域全纯、z₀ 内点：f(z₀)＝(1/2πi)∮_{∂D} f(z)/(z−z₀) dz；导数界 |f⁽ᵏ⁾(z₀)| ≤ k!·M/rᵏ（∂D 上 |f|≤M、半径 r）——Perron 左竖线导数界（Z06/V05）的积分论消费件。
- **② 依赖的既有机器**：树内——P04、P01-P03；CxRealPairExpLog（c_exp·圆周参数化 z₀+re^{it}）；**2π 周期归约＝KB36R :149 诚实断点（sin/cos 周期性树内无·C1.4 残件）——本件强消费位**。
- **③ 形式化难点预判**：证明面＝积分公式（文献短论证·但吃 P04 全件＋几何因子 rᵏ 常数化）。可计算面＝2π、rᵏ 常数证书。
- **④ 三档初判**：**需突破**——依赖 P04＋周期归约断点双前置（缺一阻塞）。〔复审条件：C1.4 残件（2π 周期）落装即复勘；P04 绿后本件转转录档〕
- **⑤ 前置节点**：P04、C1.4 残件（周期归约）、P01-P03。
- **⑥ 估席时**：基准 **6-9 席时**（半新地形·溢价下带）。
- **⑦ 先例检索词（供 R4）**：中：柯西积分公式 形式化/解析函数导数界/圆周积分。英：Cauchy integral formula formalization; Cauchy estimates derivative bound holomorphic; circle integral complex mathlib; parametrization circle e^{it} periodicity。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1#2＋在盘实测）**：先例件＝PNT_with_Remainder PNT_Complex_Analysis_Lemmas.thy＋Zeta_Zerofree.thy｜**系数 0.40**。实测坐标：`Schwarz_Lemma1` :310／`Schwarz_Lemma2` :342（theorem）／`Borel_Caratheodory1` :375／`Borel_Caratheodory2` :484／`Borel_Caratheodory3` :497（theorem）／`holomorphic_logderiv` :20／`analytic_factorization` :288（theorem·E :197/I :217 辅件）＋ZZ `deriv_zeta_bound` :355-358（B/r＋1/‖s−1‖² 消费形逐字）。**复审条件触发实测（响亮）**：C1-17 TwoPiPeriod 已于 γ1 过四关（seg_C1/GaC1_17_TwoPiPeriod.vo 在盘·本席 ls 实测·GaC1_Iface_Cx :36 Require Export·pi_R/two_pi_R/gaC1_17_sin_pi 名在 Iface 索引）——cards ②「2π 周期归约断点（KB36R :149）」消解位已落装·P05 强消费位可经 GaC1_Iface_Cx 放电·原「双缺一阻塞」降为单前置（P04 绿）。施工后果：导数不等式取 :355 消费形（B/r＋1/‖s−1‖² 特化）为语句面正本。
- **⑨ 施工登记（20261103 续批席·未开工·阻塞）**：按禁跳序律列于 P04 之后——P04 仅部分落袋且其深水面（全纯谓词承载）未铸，而本件两主面（Cauchy 积分公式·Cauchy 导数界 ZZ deriv_zeta_bound :355 消费形）均消费「非常值被积积分」（圆周 f(z)/(z−z₀) 型）＝P01 诚实开口的一致连续准入面＋P04 未铸的全纯面·双缺一阻塞（cards ⑤ 硬闸的载体内形态）。2π 周期前置已落装（GaC1_Iface_Cx·⑧ 复审条件已消解）·非阻塞项。候 P04 深水面＋P01 准入面落位后开工·本波零编译零写。
### C3-P06 · 留数提取（单极点·ζ'/ζ 极点面）
- **① 数学命题**：f 在矩形域内除孤立单极点 s₀ 外全纯：∮_{∂R} f dz＝2πi·Res(f,s₀)，Res(f,s₀)＝lim_{s→s₀}(s−s₀)f(s)。应用：−ζ'(s)/ζ(s) 在 s＝1 处 Res＝1（由 Z04 主部 ζ(s)＝1/(s−1)+O_B(1)）；在零点 ρ 处 Res(−ζ'/ζ,ρ)＝−m(ρ)（m＝重数）。
- **② 依赖的既有机器**：树内——P04、P05、Z04（主部）、Z03（1-线非零保证域内极点仅 s=1）；系数提取证书工艺＝S03_QExp 同型。
- **③ 形式化难点预判**：证明面＝留数定理（P05 特化＋洛朗系数比较档）。可计算面＝Res(−ζ'/ζ,1)＝1 的系数证书（纯 Q 面）。
- **④ 三档初判**：**需突破**——P05 绿后半转录级·但零点重数判别面（域内零点重数=1 的可判定承载）**待勘**（dVp 档若以「零点在围道外」陈述可绕开重数·见 P10 勘形修正）。
- **⑤ 前置节点**：P04、P05、Z03、Z04。
- **⑥ 估席时**：基准 **5-8 席时**。
- **⑦ 先例检索词（供 R4）**：中：留数定理 形式化/对数导数 留数/单极点 系数。英：residue theorem formalization; residue logarithmic derivative; simple pole residue extraction; Isabelle Residue_Theorems HOL-Analysis; mathlib residue。⚠碰撞：residue 一词在 CS/图论多义·检索加 "complex analysis" 限定。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1#2＋在盘实测）**：先例件＝两件接缝｜**系数 0.35**。实测坐标：`perron_indicator a ＝ (if a > 1 then 1 else if a = 1 then 1/2 else 0)` :26-27＋simps :29-33（半整数指示·sum_upto′ 语义位）；Song-Yao 侧 `perron_integrable` :124／`perron_aux_1` :286／`perron_aux_2` :443／`perron_aux_3` :460／`perron_formula` :920。**实测差（坐标修正登记）**：留数步（`winding_number (R b) 0 * residue …`＋`residue_simple_pole_deriv` 用例）实测在 `perron_aux_integral_bound` 证明内 **:272-285**（drafts §③-P06 记 :792 链——:792 实为 perron_asymp_aux2 引理位·留数步不在彼）·且 AFP 走 winding_number 机器（HOL-Analysis 内建）→树内单极点残差（洛朗系数比较）自铸全价·m 重泛化禁入维持。施工后果：Res(−ζ′/ζ,1)=1 由 Z04 主部系数证书直给（纯 Q 面·cert 正位）。
### C3-P07 · x^s/s 与 x^ρ/ρ 增长刻画（被积函数参数化面）
- **① 数学命题**：x>1, s＝σ+it：|x^s|＝x^σ（c_exp 极坐标恒等式 |e^{(σ+it)ln x}|＝e^{σ ln x}）；|1/s| ≤ 1/max(σ,|t|)（显式）；推论（零点项衰减承载）：对 β ≤ 1−1/(R·ln τ)，|x^ρ/ρ| ≤ x·exp(−(ln x)/(R·ln τ))/|ρ|——实 exp 换算全显式。
- **② 依赖的既有机器**：树内——CxRealPairExpLog（c_exp 极坐标·c_log·born）；C1.2 实幂 x^{1/k}/x^σ 承载（KB34:95·2 节点）；S04 real_log＋E840/E841/E845 坑卡税；QleT'/qpow 传递代数。
- **③ 形式化难点预判**：证明面＝|e^z| 模恒等式（c_exp 极坐标直给·KB36R :110-129 后延一件）。可计算面（主体）＝实幂/exp 换算 Q 证书·全 vm_compute 化（R2·KB72 工艺）。
- **④ 三档初判**：**可及**——c_exp 极坐标+实幂承载在树/born·纯刻画档无新地形。
- **⑤ 前置节点**：C1.2、C1.4（born）、S04。
- **⑥ 估席时**：基准 **2-4 席时**（B6/B7 锚直用带）。
- **⑦ 先例检索词（供 R4）**：中：复指数 模 极坐标/实幂 x^s 承载。英：modulus complex exponential polar; |e^z| identity formalization; real power complex exponent；树内 R4 检索：c_exp_abs/norm 系（CxRealPairExpLog.v）。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1＋在盘实测）**：先例件＝DSIIB theory（515 行）｜**系数 0.40**。实测坐标：`eval_fds_smallo_Im_going_to_infinity` :484（theorem·o(‖Im w‖^{1−a}) 显式）＋`fds_at_ii_infinity_bound` :48-49／`fds_at_ii_infinity_bound_deriv` :54-58（显式界函数对）＋`dist_consec_nat_powr_complex_le` :11。实测差：o() 渐近算子禁直搬（构造性承载）→取「Re s 窗内一致界」定量重述——本席施工已按 squared-norm 载体（c_norm_sq）落装 6 名·PA 6/6 Closed·coqchk own rc=0（20261103 fresh 四关账·_log_chk_P07_own_20261103.log/_log_pa_P07_20261103.log）·零点项衰减与 1/‖s‖ 面留待 P08/P09 消费位展开。施工后果：P07 **已闭**（本波核销）。
### C3-P08 · Perron 截断公式（有限 T 竖线积分＝ψ(x)−误差）
- **① 数学命题**：x>1、c>1、T>0（x 取半整数位移或 x∉ℕ 细节见③）：ψ(x)＝(1/2πi)∫_{c−iT}^{c+iT} (−ζ'(s)/ζ(s))·x^s/s ds ＋ R(T,x)，其中 |R(T,x)| ≤ Σ_{n≥1} Λ(n)·(x/n)^c·min(1, 1/(T·|ln(x/n)|))（Perron 经典截断界·显式形；文献坐标 Titchmarsh Thm 3.12 / Montgomery–Vaughan Thm 5.3·Dusart 2010 附录同型——坐标自本席知识·R4 复核）。
- **② 依赖的既有机器**：树内——P01-P07、Z01（−ζ'/ζ Dirichlet 级数·绝对收敛域）、D1 GREEN 九件之 ψ 承载（piu_zz_pnt_psi/rateup·KB57 五件接口）；C1.4 一致收敛（逐项交换）。
- **③ 形式化难点预判**：证明面＝Dirichlet 级数逐项积分＋sin 核逐项估计（逐项交换的一致收敛面·文献 2 页论证·中等新地形）；**x 为整数时的端点项**（Λ(x) 半整数位移技巧）显式化。可计算面＝min(1,·) 截断界 Q 证书（vm_compute）。
- **④ 三档初判**：**需突破**——Perron 本体第一主件·全球零先例核心段（KB34:98/重估 :68 双卷判）。〔复审条件：闸 1 若检出任何 ITP 的 Perron 截断形式化→立即吸收式重估全块〕
- **⑤ 前置节点**：P01-P07、Z01、C1.4（收敛残件）。
- **⑥ 估席时**：基准 **10-14 席时**（与 P01 并列全块最深两件）。
- **⑦ 先例检索词（供 R4·双倍档）**：中：Perron 公式 截断 误差/佩龙公式 显式/素数计数函数 围道积分。英：Perron's formula explicit error term; Perron truncation integral; Titchmarsh Theorem 3.12; Montgomery-Vaughan Multiplicative Number Theory Perron; Perron integral formula psi(x)。证伪面（预期零命中·闸 1 靶标）：AFP "Perron's formula"；Isabelle Perron zeta；Lean Perron formula formalization。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1#2＋在盘实测）**：先例件＝两件互证｜**系数 0.35**。实测坐标（Eberl）：`perron_bound` :1019-1020（Σ‖a_n‖/(n^c·(1+T·‖ln(x/n)‖))）＋`sums_perron_bound` :1026＋`perron_effective_strong` :1208（4·(arctan(T/c)+π+1)·x^c·perron_bound 形）＋corollary `perron_effective` :1230（C=6π+4 :1235）；（Song-Yao）：`perron_formula` :920／`perron_asymp` :936——两件独立成品互证确认（drafts §③-P08 判词成立）。实测差：min(1,1/(T‖ln(x/n)‖)) 形与 4(arctan+π+1) 形并存→两形并登记·换算证书落 cert（P11 T 竞速消费 min 形）。施工后果：复审条件（cards ④·任何 ITP Perron 截断→吸收式重估）已兑现检视：AFP 两件在案·剩余风险面收敛到构造重铸全价。
### C3-P09 · 水平尾项估计（|t|=T 边·T 选取优化）
- **① 数学命题**：水平边 ∫（σ 从 1−η(T) 到 c，t＝±T）：|∫| ≤ (c−1+η(T))·sup_{边上}|−ζ'/ζ·x^s/s| ≤ (c−1+η(T))·C_b·ln^b T·x^c/T（ML 界·P03）；T 优化表：取 T＝τ^A（A 显式·Dusart 2010 形）时尾项对 x 的显式函数式。
- **② 依赖的既有机器**：树内——P03（ML）、P07（x^s 界）、Z06/V05（−ζ'/ζ 边界界）；R2（T 表常数 vm_compute）。
- **③ 形式化难点预判**：证明面＝ML 直接应用（P03 绿后转录级）。可计算面＝T 选取表与 ln^b 常数证书。
- **④ 三档初判**：**可及**——P03＋Z06/V5 绿后直接档（链内装配件·无新地形）。
- **⑤ 前置节点**：P03、P07、Z06、V05。
- **⑥ 估席时**：基准 **3-5 席时**。
- **⑦ 先例检索词（供 R4）**：中：围道 水平边 估计/截断高度 优化。英：Perron contour horizontal integral bound; truncation height optimization explicit PNT; T selection zeta contour。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1＋在盘实测）**：先例件＝Perrons_Formula.thy｜**系数 0.35**。实测坐标：`perron_aux_integral_bound` :96-100（dist I (perron_indicator a) ≤ perron_remainder a c T）＋`perron_remainder` :59-66（a^c/(πT)·(if a = 1 then c else 1/‖ln a‖)——分情形形状逐字）＋arctan 闭形链 :117-122（arctan_le_self 用例）＋`perron_effective'_aux` :1273（‖ln(x/n)‖ ≥ ‖x−n‖/(bx)）＋`MVT2'` :1256。实测差：零（全坐标与 drafts §③-P09 吻合）。施工后果：树内水平边＝ML（P03）直接档·T 优化表与 ln^b 常数全落 cert；无 stdlib arctan→构造性 arctan 界新铸小件（born c_log/c_exp 承载）义务登记。
### C3-P10 · 围道左移与贡献分解（极点项 x·零点全在围道外）
- **① 数学命题**：矩形围道（右 c、左 1−η(T)、上/下 ±T，η(T) 取 ZFR 边界形 c₀/ln T〔dVp〕或 c₁/L(τ)〔VK〕）：由零点自由区（Z05/V04）域内**无非平凡零点**、trivial 零点（s＝−2m）与 s=0 均在域外，故 (1/2πi)∮_{∂R} (−ζ'/ζ)·x^s/s ds ＝ Res_{s=1} ＝ x（Z04 主部）——无逐零点求和项（勘形修正注记见块头）。
- **② 依赖的既有机器**：树内——P06（留数）、P07、Z04、Z05/V04（零点自由区限定）；Z03（1-线唯一极点保证）。
- **③ 形式化难点预判**：证明面＝围道内零点缺失的「几何↔解析」接缝（ZFR 陈述→围道域内无零点的机器化·含 t=0 竖线上实零点缺失小件 ζ(s)<0 于 (0,1)）；留数求和退化单极点（P06 消费）。可计算面＝η(T) 边界常数证书。
- **④ 三档初判**：**需突破**——Perron 链中部主件·「ZFR→围道域内无零点」接缝为经典文献默认跳步·形式化需自铸。〔复审条件：Z05/V4 任一降档翻转即连带重估〕
- **⑤ 前置节点**：P06、P07、Z03、Z04、Z05、V04。
- **⑥ 估席时**：基准 **8-12 席时**。
- **⑦ 先例检索词（供 R4·双倍档）**：中：显式公式 围道左移/零点自由区 围道内无零点/留数 极点贡献。英：explicit formula contour shift; contour rectangle inside zero-free region no zeros; Perron contour shift residue pole x; effective PNT proof contour rectangle。证伪面：contour shift formalization（预期零命中）。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1#2＋在盘实测）**：先例件＝rectpath 链＋perron_indicator｜**系数 0.45**。实测坐标：四边恒等式 `∮(vline c) ＝ ∮(vline b) − ∮(hline c b) + ∮(hline′ c b)`（eventually 形）:134-141＋`path_image (R b) ⊆ cbox` :134-136＋`perron_indicator` :26-35。实测差：「ZFR→围道域内无零点」接缝 AFP 零面（rectpath 像集⊆cbox⊆−{0} 链仅处理 x^z/z 的单极点情形）→零点谓词面自铸（Z05/V04 消费）；trivial 零点域外核验的 mathlib 形状参照（riemannZeta_eq_zero_iff_of_re_nonpos :483·禁直用）维持。施工后果：语句面禁铸 Σ_ρ 逐零点项与 N(T)（勘形修正执行位·词面 grep=0）。
### C3-P11 · 左竖线估计＋四边合并 → ψ(x) 显式界
- **① 数学命题**：ψ(x)＝x＋E(x)，且 |E(x)| ≤ C₉·x/ln²x（log² 档·x≥x₁·显式 C₉）或 C₁₀·x·exp(−c₁₁(ln x)^{3/5}(ln ln x)^{−1/5})（log³ 档·Karatsuba–Korobov 品质·Dusart 2018 Thm 5.2 所需）——右竖线（Perron 精确项）＋水平边（P09）＋左竖线（|−ζ'/ζ|×x^{1−η}/|s|×段长·Z06/V5 消费）＋极点项合并·T 优化竞速逐常数。
- **② 依赖的既有机器**：树内——P08、P09、P10、Z06/V05、Z09（小 t 段）；S04；R2 证书化。
- **③ 形式化难点预判**：证明面＝四边估计合并＋T 竞速（常数级·但项多易错·B6/B7 红点密度教训直接适用——勘形必须先清项表）。可计算面（主体）＝C₉/C₁₀/c₁₁/x₁ 全常数族 vm_compute 证书＋验收器。
- **④ 三档初判**：**需突破**——Perron 链终装主件·零先例段（重估 :68「连续 12 节点新地形」末端）。〔复审条件：P08/P10 绿后复勘；常数项表勘形不足即返工——R1 强制三稿先行的本块验证位〕
- **⑤ 前置节点**：P08、P09、P10、Z06、V05、Z09。
- **⑥ 估席时**：基准 **8-12 席时**。
- **⑦ 先例检索词（供 R4·双倍档）**：中：有效素数定理 误差项 显式常数/de la Vallée Poussin 误差/ψ(x) 显式界。英：effective prime number theorem error term; de la Vallée Poussin explicit psi bound; Schoenfeld 1976 ψ(x) bounds derivation; Dusart 2010 psi explicit; Karatsuba Korobov error term exp(-c log^{3/5}); x exp(-c sqrt(log x)) PNT。证伪面：formalized effective PNT error term（预期零命中·闸 1 终极靶标）。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #1#2＋在盘实测）**：先例件＝perron_effective′ 全式｜**系数 0.45**。实测坐标（:1340-1354 逐项）：C1 ＝ 4·(3·π+2) :1349／C2 ＝ 2·(3·π+2)/ln 2·C :1350／C3 ＝ (if c+Re s ≥ 0 then 2 else 1/2) :1351／界式双项（C1·C3^(c+Re s)·B(2x)/x^{Re s}·(1+x/T·(4 ln T+9)) ＋ C2·x^c·(c+Re s−σ_a)^{−α}/T）:1352-1354＋Tenenbaum Big-O 显式化文注 :1337-1338；3653 常数纪律（Song-Yao 条目页·台账 #2 fetch）。实测差：先例常数集≠树内消费常数（C₉/C₁₀/c₁₁/x₁ 树内自算）→cert 面全族 vm_compute·(1+x/T·(4lnT+9)) 项结构为左竖线项分解形状参照。施工后果：四边合并项表勘形（右竖线 1｜水平 2｜左竖线 1｜极点 1＝五项）与双档语句（log²⊕log³）义务维持。
### C3-P12 · ψ 显式界 Q-离散化终装（GAPASUME 槽放电对表形）
- **① 数学命题**：P11 解析界 → Q-exp 整数证书消费形：∀ M ≥ N₀, hl_le_t (psi_lo M) (ψ 树内承载 M) ∧ hl_le_t (ψ 树内承载 M) (psi_hi M)（θ 侧经 ψ−θ 桥尾项换算——对表 tau_enclosure_base:1214 HLn_rate_up / :1216 lo 槽形与 KB34:67 消费形；ε₀ 定常化点取消费域最小端 X₀＝664000000·KB33 :67 勘形修正注记）。
- **② 依赖的既有机器**：树内——P11；D1 GREEN 九件（piu_zz_pnt_qexp/ipow/rateup/assembly·KB57 五件接口对表在卷）；S03_QExp；KB72 vm_compute 工艺；pec_theta_bound（abl_Pr_erdos_theta:191·ψ−θ 尾项消费）。
- **③ 形式化难点预判**：可计算面（主体）＝ε₀ 定常化＋证书字面生成＋验收器（R2 正形·zzPhi 判例）。证明面＝Q-exp 反演离散化（D1-B5 同工艺重用·零新地形）。
- **④ 三档初判**：**可及**——P11 绿后＝消费侧同工艺转录·KB57 B6/B7 判例直接档（1.1-2.3 席时带）。
- **⑤ 前置节点**：P11、D1-B5（GREEN）、D1-B4（ψ−θ 桥 GREEN）。
- **⑥ 估席时**：基准 **2-4 席时**。
- **⑦ 先例检索词（供 R4）**：中：GAPASUME 槽 放电/假设消融 显式界/Q 指数证书。英：hypothesis discharge explicit bound; assumption elimination certificate; Q-exponential discretization；树内 R4 检索：piu_zz_pnt_assembly / piu_zz_tau_enclosure_base:1214（本会话实读坐标）。

---

## 第二块 · 零点自由区 dVp 经典 10 节点（log² 档·显式常数＝KB34 降链案 α 锚）

> KB34:97：「经典 de la Vallée Poussin（log²·显式常数）10/4.0」；重估 :63 fresh 单价乐观 3-3.5/基准 5.5-7/悲观 7 席时/节点。

- **⑧ AFP 对表记录（γ3 施工席·20261103 对表波·台账 #2＋在盘实测）**：先例件＝无 ψ-Q 离散化成品（条目页 8 theories 清单确认无该面·台账 #2）｜**系数 0.45（树内工艺为主）**。对表面＝树内工艺先例：D1 GREEN 九件（piu_zz_pnt_qexp/ipow/rateup/assembly）＋S03_QExp＋KB72 vm_compute 工艺＋pec_theta_bound（abl_Pr_erdos_theta:191）；AFP 侧仅 Relation_of_PNTs/PNT_Subsummable 装配工艺旁证（条目页 theory 清单在台账）。实测差：ε₀=1/6600@X₀=664000000 定常化点与 hl_le_t 双向槽形（tau_enclosure_base:1214/:1216）为树内消费形·AFP 无对价件。施工后果：cards ④「可及」维持·W11 终装位。
### C3-Z01 · −ζ'/ζ 的 Dirichlet 级数表示与绝对收敛界
- **① 数学命题**：对 σ＝Re s > 1：−ζ'(s)/ζ(s)＝Σ_{n≥1} Λ(n)·n^{−s}（绝对收敛）；定量形：σ≥1+δ 时 |−ζ'/ζ(s)| ≤ Σ Λ(n)n^{−σ} ≤ 1/(σ−1)＋C₁（显式 C₁；Σ_{n≤N}Λ(n) ≤ ln lcm(1..N) 树内承载核算）。Λ(n) 承载＝lcm 幂差分（D1-B3 GREEN）。
- **② 依赖的既有机器**：树内——CxRealPairExpLog（n^{−s}＝e^{−s ln n}）；D1-B3 lcmpow（GREEN）；S04 real_log 坑卡税；C2.2 Euler 乘积（前置·ζ'/ζ＝(log ζ)' 级数面）；C2.1 Dirichlet 级数半平面收敛。
- **③ 形式化难点预判**：证明面＝级数逐项求导的一致收敛交换（C2.1 消费）。可计算面＝ΣΛ(n)n^{−σ} 截断＋余项 Q 证书（vm_compute）。
- **④ 三档初判**：**需突破**——树内 ζ/Dirichlet 级数词面零施工命中（重估 :34-35 grep 实勘·本会话未见反证）·文献级新证档。
- **⑤ 前置节点**：C2.1、C2.2、C1.4、D1-B3。
- **⑥ 估席时**：基准 **5.5-6.5 席时**（重估 C3 带内）。
- **⑦ 先例检索词（供 R4）**：中：ζ 对数导数 狄利克雷级数/von Mangoldt 函数 形式化。英：logarithmic derivative Riemann zeta Dirichlet series; von Mangoldt Lambda formalization; mathlib LSeries derivative（R4 验证 mathlib LSeries 面积）。

### C3-Z02 · 三余弦不等式
- **① 数学命题**：∀u∈ℝ：3＋4cos u＋cos 2u＝2(1+cos u)² ≥ 0；等号 ⇔ cos u＝−1。本会话独立验算：3+4cos u+(2cos²u−1)＝2+4cos u+2cos²u＝2(1+cos u)² ✓。
- **② 依赖的既有机器**：树内——rs_add_cos/rs_add_cos/cauchy_real_exp_plus 三角件（KB36R :106 在树·重估 :33 登）＋实平方非负；cos 2u 倍角面（三角代数延拓）；**等号面需 2π 周期归约＝KB36R :149 诚实断点（若全链只需不等号可缩面）**。
- **③ 形式化难点预判**：可计算面＝无。证明面＝恒等式展开＋平方非负（纯初等）；周期归约断点若消费则连带 C1.4 残件。
- **④ 三档初判**：**可及**——树内三角代数直接覆盖（缩掉等号面后零新地形）。
- **⑤ 前置节点**：C1.4 三角件（在树）；（可选）C1.4 残件周期面。
- **⑥ 估席时**：基准 **1.5-2.5 席时**（B6/B7 锚直用）。
- **⑦ 先例检索词（供 R4）**：中：三余弦不等式/3 4 1 不等式。英：3+4cos(t)+cos(2t) inequality; three cosines inequality; sum of cosines nonnegative trigonometric identity。

- **⑨ 施工记录＋核销（20261103 续推席·节点闭·已毕核销入账）**：`seg_C3/GaC3_Z02_ThreeCosine.v` 落袋（前席 20261103 晨·B6/B7 锚顶格 1.5 席时·工装成本教训）；本席按双取证律以在盘产物真值复验——coqchk own（与 P07 同炉）rc=0＋`Modules were successfully checked`＋**Axioms `<none>`**（_log_chk_Z02P07_reverify_20261103.log·guard exit=0）；语句面具名项 7（倍角 cos_double_rs＋三余弦非负主件等）·等号面/2π 周期词面=0（缩面执行位）·判词「可及」维持。**核销入账 ✓**。

### C3-Z03 · ζ(1+it) ≠ 0（非零线·定量版）
- **① 数学命题**：∀t≠0：ζ(1+it)≠0。论证骨架（三余弦法）：对 σ>1，0 ≤ Re{−3ζ'/ζ(σ)−4ζ'/ζ(σ+it)−ζ'/ζ(σ+2it)}（Z01+Z02 逐项）；若 ζ(1+it₀)=0（m 重）则 −Re ζ'/ζ(σ+it₀)＝−m/(σ−1)+O(ln τ)，令 σ→1⁺ 得 0 ≤ (3−4m)/(σ−1)+O(ln τ)→−∞·矛盾。定量版＝显式矛盾半径。
- **② 依赖的既有机器**：树内——Z01、Z02；C2.3 η 交错延拓（ζ 延拓至 Re s>0·连续性消费）；CxRealPair 极限面；C1.4。
- **③ 形式化难点预判**：证明面＝σ→1⁺ 竞速矛盾的构造性化（极限论证·实不等式链）；零点邻域 −ζ'/ζ 主部＝−m/(s−s₀) 的局部刻画（复可微+零点因子分解·C1.4/CxRealPair 消费）。可计算面＝无。
- **④ 三档初判**：**需突破**——推理拓扑短（文献 ~10 行）但零先例面·KB36R 新地形溢价带内可容。〔复审条件：Harrison 2009/Newman 路 R4 确认含非零线构造性化→折价〕
- **⑤ 前置节点**：Z01、Z02、C2.3、C1.4。
- **⑥ 估席时**：基准 **6-8 席时**。
- **⑦ 先例检索词（供 R4）**：中：ζ 无零点 Re s=1/阿达马-德瓦布瓦桑 非零线。英：no zeros on line Re(s)=1; Hadamard de la Vallée Poussin proof; three cosines inequality zeta nonvanishing; zeta non-zero on sigma equals 1。

### C3-Z04 · ζ 主部展开（ζ(s)＝1/(s−1)+O_B(1) 显式常数化）
- **① 数学命题**：条带 1/2 ≤ σ ≤ 2、|t| ≤ T 内：|ζ(s)−1/(s−1)| ≤ B（显式 B）；推论：|ζ'(s)+1/(s−1)²| ≤ B'（显式）·即 −ζ'/ζ(s)＝1/(s−1)+O_{B₂}(1) 定量形。
- **② 依赖的既有机器**：树内——C2.4 竖线增长界（Borel–Carathéodory/Phragmén–Lindelöf 构造性化·KB34:96 的 8 节点输出）；C2.3（η 延拓→ζ 延拓）；P05（Cauchy 导数界·若用积分路）或直接法。
- **③ 形式化难点预判**：证明面＝文献 asymptotic → 显式不等式的逐常数核算（O 常数化＝全战役通病面·Dusart 2010 附录型工作）。可计算面＝B/B₂ Q 证书。
- **④ 三档初判**：**需突破**——C2.4 新地形为前置·本体为常数化收尾档。
- **⑤ 前置节点**：C2.4、C2.3、Z03（域内非零前提部分消费）。
- **⑥ 估席时**：基准 **5-7 席时**。
- **⑦ 先例检索词（供 R4）**：中：ζ 极点主部 显式有界/ζ 带状区域界。英：zeta near pole 1/(s-1) explicit bound; zeta bounded in critical strip explicit; Riemann zeta explicit estimates strip。

### C3-Z05 · dVp 零点自由区主定理（显式常数）
- **① 数学命题**：ζ(σ+it) ≠ 0 对 σ ≥ 1−1/(R·ln τ)、τ＝max(|t|, τ₀)（显式 R·正典锚三件〔勘定 20261104·fetch-before-cite 已毕·坐标表 prec_fetch/litfeed_20261104/Z05-R.md〕：M–T–Y 5.558691＝5558691/10⁶（arXiv:2212.06867 Thm 1.3·经典型现役最优·|t|≥2）／M–T 5.573412＝1393353/250000（arXiv:1410.3926 Thm 1·|t|≥2·定理本体严格 >）／Kadiri 5.69693＝569693/10⁵（Acta Arith 117(4) Théorème 1.1·|Im s|≥2）——原候选「Ford 5.5666307」「Kadiri 4.56383」系勘形漂移幽灵〔五件全文＋全网字面零命中·禁入证书；Ford 真值 8.463 存目不消费·Kadiri 真值即 5.69693〕·选定值待施工席裁）；Set 消费形＝非零性 bool/hl 证书承载。
- **② 依赖的既有机器**：树内——Z01-Z04、Z02；C2 全件。外部文献：de la Vallée Poussin 1899 原法（(1−σ)³ 加权竞速）。
- **③ 形式化难点预判**：证明面＝三余弦加权不等式＋零点邻域主部＋1/(σ−1) 竞速·逐显式常数展开（C3 段主件·(1−σ)^k 幂技巧的区间算术化）。可计算面＝R/τ₀ 证书。
- **④ 三档初判**：**需突破**——文献标准但全链显式常数化零先例（KB34 C3 全未启·重估 :35 实勘）。〔复审条件：显式零点自由区构造性库出现（闸 1 复检靶标）→吸收式重估〕
- **⑤ 前置节点**：Z01、Z02、Z03、Z04。
- **⑥ 估席时**：基准 **6-8 席时**。
- **⑦ 先例检索词（供 R4）**：中：德瓦布瓦桑 零点自由区 显式常数/ζ 零点自由区 有效。英：de la Vallée Poussin zero-free region explicit; explicit zero free region zeta constant; Ford 2002 zero-free region 8.463; Mossinghoff Trudgian zero-free region; Mossinghoff Trudgian Yang zero-free region; Kadiri explicit zero-free region。

### C3-Z06 · 零点自由区内 −ζ'/ζ 增长界（log² 型）
- **① 数学命题**：σ ≥ 1−1/(R ln τ) 且 1+1/ln τ ≤ σ 或经邻域分域：|−ζ'/ζ(σ+it)| ≤ C₄·ln²τ（显式 C₄）；|ζ'(σ+it)| ≤ C₃·ln^b τ（b∈{2,3}·显式）——P09/P11 左竖线消费件。
- **② 依赖的既有机器**：树内——Z05、Z04；C2.4（B–C 构造性化输出）；P05（Cauchy 导数界·交叉依赖·若 γ3 内 P 链先行可消费·或改直接法避开——**归属待勘**）。
- **③ 形式化难点预判**：证明面＝分域讨论（邻域内主部/邻域外 Dirichlet 级数）＋B–C 消费。可计算面＝C₃/C₄ 证书。
- **④ 三档初判**：**需突破**——C2.4 新地形为前置·本体转录-半新档。
- **⑤ 前置节点**：Z05、C2.4、Z04、（P05 或直接法）。
- **⑥ 估席时**：基准 **5-7 席时**。
- **⑦ 先例检索词（供 R4）**：中：ζ 对数导数 零点自由区 界。英：zeta logarithmic derivative bound zero-free region log squared; Borel-Carathéodory zeta explicit; zeta prime growth effective bound。

### C3-Z07 · log ζ 单值解析分支（零点自由+非极域）
- **① 数学命题**：域 Ω＝{σ ≥ 1−1/(R ln τ)}∖{1}（或 1+δ 右邻域）上 ζ 无零点 ⇒ 存在解析 g:Ω→ℂ 满足 e^{g}＝ζ（构造性：g(z)＝∫_{z₀}^z ζ'/ζ dξ＋log ζ(z₀)·经 P04 路径无关性良定）。
- **② 依赖的既有机器**：树内——Z05、P04（原函数/路径无关）、P01-P03、CxRealPairExpLog（c_log 诚实接口）。
- **③ 形式化难点预判**：证明面＝解析 log 存在＝ζ'/ζ 原函数构造（P4 推论档）；基点与分支规范化。可计算面＝少。
- **④ 三档初判**：**需突破**——P 链积分基建绿后转录级·但 P 链未绿则阻塞（γ3 内部 DAG 交叉点·登记）。
- **⑤ 前置节点**：Z05、P04。
- **⑥ 估席时**：基准 **4-6 席时**。
- **⑦ 先例检索词（供 R4）**：中：解析对数 分支存在/单值分支 构造性。英：analytic logarithm branch existence; log zeta single valued zero-free region; constructive complex logarithm branch; primitive of logarithmic derivative。

### C3-Z08 · 1/ζ 在零点自由区的有效界
- **① 数学命题**：σ ≥ 1+1/ln τ：|1/ζ(σ+it)| ≤ ζ(σ) ≤ ln τ＋C₅；零点自由区内经 ζ'·(1/ζ) 分解：|1/ζ(σ+it)| ≤ C₆·ln^b τ（b≈1-2·显式）——θ 下界侧与 |ζ'/ζ| 分解估计消费件。
- **② 依赖的既有机器**：树内——Z05、Z06、Z07、C2.4。
- **③ 形式化难点预判**：证明面＝Cauchy/B–C 从 ζ 界导 1/ζ 界（转录级）。可计算面＝C₅/C₆ 证书。
- **④ 三档初判**：**需突破**——同 Z06 逻辑（前置链绿后转转录）。
- **⑤ 前置节点**：Z05、Z06、Z07。
- **⑥ 估席时**：基准 **4-6 席时**。
- **⑦ 先例检索词（供 R4）**：中：ζ 倒数 显式界/1/ζ 零点自由区。英：1/zeta bound zero-free region effective; reciprocal zeta explicit estimate log t。

### C3-Z09 · 小 |t| 段与 τ₀ 有限窗显式核查
- **① 数学命题**：|t| ≤ τ₀ 段 ζ 的无零点/有界性显式化（紧矩形上 Q 区间证书·vm_compute 全值核算）；连带统一参数化 τ＝max(|t|, τ₀) 的语句面整编（Z05 等各件的 τ₀ 段闭合）。**锚值证书两件〔勘定 20261104·坐标表 prec_fetch/litfeed_20261104/Z09-tail.md〕**：①HLY v3 Thm 1 锚 |ζ(1+it)| ≤ 1.731·(ln t)/(ln ln t)（t ≥ 3·arXiv:2306.13289 v3 现行〔2024-08-14〕·ar5iv 旧版 1.721 系版本漂移已勘误·引锚取 v3 1.731＝1731/1000·1.721 并登存目）；②PT 2021 Thm 1 锚 H＝3000175332800（精确整数·arXiv:2004.09765 Thm 1·Bull. LMS 53(3) 2021 792-797·Arb 区间算术逐字点名·零点计数 12363153437138·参照级锚·禁整体直引充构造性语句）。
- **② 依赖的既有机器**：树内——C2.3（ζ 数值求值面）；S03_QExp；KB72 vm_compute 判例工艺；**复数值区间求值器树内为零**（S03_QExp 是 nat/Q 整幂证书机·非区间求值器）——缺口登记。
- **③ 形式化难点预判**：可计算面（主体）＝复区间算术求值器新铸＋ζ 值域证书（KB72 判例是 nat/Q 面·复区间面量级待勘）。证明面＝小。
- **④ 三档初判**：**待勘**——可计算面工具缺口实况未勘（复区间证书器有无现成工艺·R4 树内+生态实检后定档；量级参考 KB72 4-8 席时带）。
- **⑤ 前置节点**：C2.3、Z04。
- **⑥ 估席时**：**4-8 席时（待勘带·KB72 判例折价若区间器可铸）**。
- **⑦ 先例检索词（供 R4）**：中：区间算术 ζ 求值 证书/复区间 证书器。英：interval arithmetic zeta evaluation certificate; coqinterval complex functions; Arb interval zeta Platt; rigorous computation Riemann zeta; interval arithmetic Coq complex。⚠参照级（非 ITP 构造性）：Platt–Trudgian 区间算术 ζ 计算（Arb 逐字点名〔arXiv:2004.09765 全文〕·「Sage」系卡面转述漂移未定谳·存目〔或出自 Platt 2017 算法件·未 fetch〕）。

### C3-Z10 · dVp 链常数一致化与 ZFR 陈述层终装
- **① 数学命题**：打包定理：∃ R, τ₀, C₃, C₄, C₅, B, B₂ ∈ ℚ 证书族使〔Z05 非零性 ∧ Z06 界 ∧ Z08 界 ∧ Z09 有限窗 ∧ Z04 主部〕全链同源一致（各件常数无漂移·统一 Q 区间证书族·GAPASUME 槽形输出供 P 链/C4 消费）。
- **② 依赖的既有机器**：树内——Z05-Z09 全件；R2 纪律正形（字面证书+验收器·zzPhi 判例）；KB72 工艺。
- **③ 形式化难点预判**：可计算面（主体）＝常数族 vm_compute 全值核算＋验收器。证明面＝常量依赖图理清（接口档）。
- **④ 三档初判**：**可及**——工艺件·无新证明地形（KB72/zzPhi/S03_QExp 判例直用）。
- **⑤ 前置节点**：Z05、Z06、Z08、Z09。
- **⑥ 估席时**：基准 **2-4 席时**（KB72 折价带）。
- **⑦ 先例检索词（供 R4）**：中：常数 证书 验收器/vm_compute 数值证书。英：numeric certificate acceptance checker Coq; vm_compute literal certificate；树内 R4 检索：zzPhi 正形（交付-KB70）、S03_QExp。

---

## 第三块 · 零点自由区 VK 核 6 节点（log³ 品质必需层·核心切片）

> KB34:97：「＋Vinogradov–Korobov 层 18/8.0（van der Corput 指数和估计——log³ 品质必需）」。本席辖其**核心 6 节点**；残 12 节点见文尾「未辖余量名单」。

### C3-V01 · van der Corput 指数和第 2 阶估计（A-过程）
- **① 数学命题**：f∈C²([N,2N])、|f''| ≍ λ₂（双向显式常数）：|Σ_{N<n≤2N} e(f(n))| ≤ C_{vdc}·(N·λ₂^{1/2}＋λ₂^{−1/2})（van der Corput 二阶导数检验·e(x)=e^{2πix}·显式 C_{vdc}）；k 阶一般形列为残档。
- **② 依赖的既有机器**：树内——P01-P03（积分机器·A-过程证明含积分算子面）；C1.1/C1.2；外部文献：Graham–Kolesnik《van der Corput's method》/Iwaniec–Kowalski Ch.8。
- **③ 形式化难点预判**：证明面＝vdC 二阶检验逐显式常数证明（文献多形·选定一形逐常数化·深新地形）。可计算面＝C_{vdc} 证书。
- **④ 三档初判**：**需突破**——指数和估计 ITP 零先例（KB34 检索台账 #1·本会话零网络未复核）。〔复审条件：任何 ITP 出现 exponent pair/vdC 形式化→本件及 V 层全折价（W-3 复审②·闸 1 靶标）〕
- **⑤ 前置节点**：P01、P02、P03、C1.1、C1.2。
- **⑥ 估席时**：基准 **8-10 席时**（新地形深块·溢价上限带）。
- **⑦ 先例检索词（供 R4）**：中：范德科普 指数和/二阶导数检验/外尔和 形式化。英：van der Corput second derivative test explicit; exponential sum estimates formalization; Weyl bound formalization; Graham Kolesnik van der Corput method。证伪面（预期零命中）：exponent pairs Coq/Lean/Isabelle；van der Corput AFP。

### C3-V02 · B-过程（完成法/泊松核）
- **① 数学命题**：光滑幅度 g、相位 f：Σ_{n∈[N,2N]} g(n)e(f(n)) ＝ Σ_m ∫ g(x)e(f(x)−mx) dx ＋ 余项（截断核 sin(πy)/(πy)·Srinivasan–van der Corput B-过程形·余项显式常数）。
- **② 依赖的既有机器**：树内——P01-P03（积分）；C1.4（复幂级数/一致收敛）；rs 三角件；**傅里叶变换理论树内为零＝本块最大依赖缺口（登记）**；外部：mathlib PoissonSummation（R4 验证是否在库·若在＝唯一强参照）。
- **③ 形式化难点预判**：证明面＝截断核积分表示＋余项常数（复+实傅里叶双层·深新地形）。可计算面＝少。
- **④ 三档初判**：**需突破**——傅里叶变换面树内零＋全球构造性 B-过程零先例。〔复审条件：mathlib/CoRN 傅里叶理论实况（R4）；若 B-过程可被 A-过程迭代替代（文献有此路线）→降本重估〕
- **⑤ 前置节点**：V01、P01-P03、C1.4。
- **⑥ 估席时**：基准 **8-12 席时**。
- **⑦ 先例检索词（供 R4）**：中：B 过程 完成法/泊松求和 形式化/傅里叶变换 构造性。英：B-process completion method exponential sums; Srinivasan van der Corput; Poisson summation mathlib（R4 验证）; Fourier transform constructive Coq; CoRN Fourier analysis。证伪面：B-process formalization（预期零命中）。

### C3-V03 · ζ 与 ζ' 在 1-线附近的 Vinogradov 型界
- **① 数学命题**：|ζ(1+it)| ≤ C_V·(ln τ)^{2/3}(ln ln τ)^{1/3}；|ζ'(1+it)| ≤ C'_V·(ln τ)^{4/3}(ln ln τ)^{1/3} 型（显式常数·文献坐标 Vinogradov 1958/Korobov 1958/Karatsuba–Korobov 1963·具体最佳显式值待勘）——V04 零点自由区竞速的直接弹药。
- **② 依赖的既有机器**：树内——V01（指数和）、V02（若需 B-过程）、Z01（Dirichlet 级数部分和）、C2.4；近似函数方程若需＝**跨段依赖（归属 C2 竖线 8 节点或本块残档·待 γ0 结构规范冻结裁定）**。
- **③ 形式化难点预判**：证明面＝vdC 消费的 ζ 界逐常数化（部分和→部分求和→1-线·中等深新地形）。可计算面＝C_V/C'_V 证书。
- **④ 三档初判**：**待勘**——跨段依赖边界（近似函数方程归属）未定·定界前不定档；按最坏情形预列需突破档预算（禁降档原则下保守记账）。
- **⑤ 前置节点**：V01、V02、Z01、C2.4、（近似函数方程·归属待勘）。
- **⑥ 估席时**：基准 **6-9 席时**（待勘带·按需突破档预列）。
- **⑦ 先例检索词（供 R4）**：中：维诺格拉多夫 ζ 1+it 界/ζ 在 1 线 log^{2/3}。英：Vinogradov bound zeta on 1-line log^{2/3}; zeta(1+it) explicit bound; Korobov Vinogradov method zeta bounds。

### C3-V04 · VK 零点自由区主定理
- **① 数学命题**：ζ(σ+it) ≠ 0 对 σ ≥ 1−c₁/((ln τ)^{2/3}(ln ln τ)^{1/3})（显式 c₁·文献坐标：Korobov 1958/Vinogradov/Karatsuba–Korobov 1963 原法·正典锚〔勘定 20261104·fetch-before-cite 已毕·坐标表 prec_fetch/litfeed_20261104/V04-c1.md〕：Ford c₁=1/57.54＝50/2877 主案（Ford 2002 Thm 5·arXiv:1910.08205v5·|t|≥3）／M–T–Y c₁=1/55.241＝1000/55241 次案（arXiv:2212.06867 Thm 1.1·|t|≥3）／Bellotti 1/54.004＝250/13501（abs 级·全文核验候缺口收口·未核前不升主案）——原候选「Kadiri–Lumley 2018」负定谳删除（件不存在·五路互证）·「Ford 2016」年份漂移正主＝Ford 2002·τ₀=3）。
- **② 依赖的既有机器**：树内——V01、V02、V03、Z01-Z04、Z07；竞速骨架复用 Z05 同型（换界函数 ln→L(τ)）。
- **③ 形式化难点预判**：证明面＝VK 法全链（指数和+1-线界+1−σ 竞速逐显式常数）＝C3 段最深证明面之一。可计算面＝c₁ 证书。
- **④ 三档初判**：**需突破**——VK 层战役级深块·禁降档（KB34 定价 18/8.0 周独层·本会话零反证）。〔复审条件：VK 形式化库出现（KB34:136 W-3②·闸 1 在飞 dwfrun-c480aacc 靶标）→全 DAG 重估〕
- **⑤ 前置节点**：V01、V02、V03、Z01、Z02、Z03、Z04、Z07。
- **⑥ 估席时**：基准 **8-12 席时**。
- **⑦ 先例检索词（供 R4·双倍档）**：中：维诺格拉多夫-科罗博夫 零点自由区 显式/卡拉楚巴-科罗博夫。英：Vinogradov Korobov zero-free region explicit constant; Karatsuba Korobov 1963; Ford 2002 zero-free region 1/57.54; Ford zero-free region log^{2/3} log log^{1/3}。证伪面（预期零命中·闸 1 靶标）：Vinogradov-Korobov formalization ITP；zero-free region Lean/Coq/Isabelle。

### C3-V05 · VK 区内 ζ'/ζ 与 1/ζ 界（log^{2/3} 型）
- **① 数学命题**：VK 区内 |−ζ'/ζ(σ+it)| ≤ C₈·(ln τ)^{2/3}(ln ln τ)^{1/3} 型；|1/ζ(σ+it)| ≤ C₇·(ln τ)^{2/3}(ln ln τ)^{4/3} 型（显式）——P09/P11 log³ 档左竖线消费件。
- **② 依赖的既有机器**：树内——V04、Z06/Z08 同型骨架、C2.4、P05。
- **③ 形式化难点预判**：证明面＝B–C 手法在 VK 区的常数化（Z06/Z08 骨架复用·换界函数）。可计算面＝C₇/C₈ 证书。
- **④ 三档初判**：**需突破**——V04 绿后转录-半新档·视 C2.4 成色。
- **⑤ 前置节点**：V04、Z07、C2.4、P05。
- **⑥ 估席时**：基准 **6-8 席时**。
- **⑦ 先例检索词（供 R4）**：中：VK 区 对数导数 界/log 2/3 型 界。英：zeta logarithmic derivative Vinogradov-Korobov region bound; 1/zeta log^{2/3} bound。

### C3-V06 · ZFR 陈述层统一（dVp⊕VK 双档输出槽）
- **① 数学命题**：零点自由区统一槽：η(τ) 双档（dVp：1/(R ln τ)｜VK：c₁/L(τ)）输出为同一 GAPASUME 槽形语句（σ ≥ 1−η(τ) ⇒ 非零性+ζ'/ζ 界+1/ζ 界三合取·证书族双套）——消费方（P 链/C4）按档位取用＝KB34 降链案 α 的接口位。
- **② 依赖的既有机器**：树内——Z10、V04、V05；R2；GAPASUME 工艺（tau_enclosure_base:1214 先例形）。
- **③ 形式化难点预判**：可计算面（主体）＝双套证书族。证明面＝接口归一（小）。
- **④ 三档初判**：**可及**——工艺装配件·零新地形。
- **⑤ 前置节点**：Z10、V04、V05。
- **⑥ 估席时**：基准 **2-4 席时**。
- **⑦ 先例检索词（供 R4）**：中：零点自由区 统一接口/误差项 档位切换。英：zero-free region interface; error term quality switching log squared log cubed。

---

## 附 · 未辖余量名单（KB34-C3 的 VK 残 12 节点·候主会话裁定归属）

> KB34:97 VK 层＝18 节点；本席辖核心 6（V01-V06）·残 12 未辖。以下为候选细目（**粒度系本席勘形推断·最终分解候 γ0《γ 模块结构规范》冻结**·诚实标注）：W1 vdC k≥3 阶一般估计（Weyl 合成）｜W2 A-过程迭代与差分多项式档｜W3 指数对（exponent pair）框架件（若 VK 证明路线需要）｜W4 ζ 矩估计（均方/四阶·备选路线件）｜W5 近似函数方程（若裁定归 C3）｜W6 ζ'(1+it) Vinogradov 界残件｜W7 零点计数 N(T) 显式界（若改走零和显式公式路线才需）｜W8 Selberg 型备选论证面｜W9-W12 VK 常数核算/证书族细档 4 件。
> 若 C4 段席按 KB34 口径（Perron 12＋ψ 6＋常数 4＝22 节点）出卡，则本席 P01-P12 与之**重复 12 卡**、上列 W1-W12 **零覆盖**——归属务必先裁再派（异见登记见文件头）。

## 附 · C3 段三档分布与席时汇总（本席 28 卡）

| 档 | 卡 | 计 |
|---|---|---|
| 可及 | Z02、Z10、V06、P02、P03、P07、P09、P12 | 8 |
| 需突破 | Z01、Z03、Z04、Z05、Z06、Z07、Z08、V01、V02、V04、V05、P01、P04、P05、P06、P08、P10、P11 | 18 |
| 待勘 | Z09（复区间证书器缺口未勘）、V03（跨段依赖归属未定） | 2 |
| 真墙 | 无（非墙判沿 KB34 判词「数学真·路线在·缺全球零先例形式化」·R6 熔断条款沿用） | 0 |

- 席时基准带汇总（中值）：dVp 10 卡 ≈ 53｜VK 核 6 卡 ≈ 46｜Perron 12 卡 ≈ 86｜**合计 ≈ 185 席时**。
- 校准自检：dVp10+Perron12 子集 ≈ 139 席时 vs 重估 fresh 基准（C3 log² 55＋C4.1 Perron 96＝151）——同带 ✓；总设计 γ3 批预算 ~110 对本席 28 卡 fresh 基准 ≈ 185——**张力 1.7× 响亮登记**（未含 VK 残 12·若并入张 力再升）。
- 复审条件汇总：P01（积分论转录面）、P04（Isabelle/mathlib Cauchy 实况）、P08（任何 ITP Perron 截断）、V01/V04（指数和/VK 库·闸 1 靶标）、V03（跨段归属裁定）、Z09（区间器工艺实勘）、Z05（显式 ZFR 库）。

——C3 段全景卡完（20261101·普查员·C3·零编译零写树·28 卡·Perron 12 零先例卡全附复审条件·⑦ 全部为 R4 输入非命中断言）
