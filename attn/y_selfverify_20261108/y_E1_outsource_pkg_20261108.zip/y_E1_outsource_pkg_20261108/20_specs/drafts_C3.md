# C3 段四稿勘形（γ0 勘形批·勘形员·C3·20261101）

> **席位**：勘形员·C3（γ 段 R1 四稿律·吸收式分簇·零编译零写树）。输入四卷全读：全景卡-γ解析核段85节点-20261101.md（C3 段 28 卡 :548-829·与 cards_C3.md 逐字同构实核）＋勘形-γ段DAG重估-吸收式-20261101.md（映射表·§①-1/①-2 对表坐标）＋kbgamma_work_20261101/gamma_module_spec.md（冻结版 v1.0·§2.2 命名律/§2.3 Iface/§2.4 六条/§3.4 波表/§4 R2 分面/§5 LINT）＋工单-γ0勘形批详细全景-20261101.md（规格 §1.2·四稿格式·纪律块）。
> **辖属账（裁 1 生效·跳过登记）**：本席辖 C3 段 28＝Perron 12（P01-P12·翻转簇吸收式）＋dVp 10（Z01-Z10·翻转簇吸收式）＋VK 核 6（V01-V06·维持簇从零）。**VK 残 12（V07-V18）已裁归 γ4/C4 段——本席零四稿零卡·仅在 §⑤ 段级账登记槽位名**。分簇分布：**吸收式 22·从零 6**。
> **纪律**：零 Main 树写（本席产出唯一落位＝本件＋prec_fetch/ 取件遗物）·零编译（未跑 coqc/coqchk/coqtop——§各节点 REPL 预演脚本只出脚本不执行）·fetch-before-cite（§① 实跑账逐件标注）·禁猜 ID（先例坐标全部本会话实读核实·树内 born 内名以 md5 冻结实名为准）·三档禁降档（全 28 节点判词沿 cards_C3 ④·吸收式折价只动席时不动档）·同形红熔断·网络单飞（curl 间隔 ≥30s·本会话三发退避实录）。
> **诚实声明**：①映射表 §①-1 的 12 节点推断拆分与正典 P01-P12 拆分**非逐点同构**（映射表自注 ±1 节点不确定度）——本席按主题重映射·逐节点登记于 §②·正典重映射加权 0.42 vs 映射表 0.425 同带·不动总估；②维持簇 V01-V06 无先例可读（映射表 §② 查无维持）·四稿＝数学命题卡＋语句面稿＋REPL＋验收判据·未做也无从做先例 fetch；③PNT4_ZeroFreeRegion.lean 仅体量核实（316954B·git-trees API）内容未读（映射表同口径「研读取主线不全读」）。

---

## 〇 · 红线路径 A 定义（本席执笔定谳·全段语句面稿统一适用）

**路径 A＝红线一合规道**（KB34:104「stdlib Complex/Reals 系非构造承载·不可直用（红线一：经典实数禁）——C 为树 real 线自铸」·工单 §1.2「语句面稿（Coq 形·适配红线路径 A）」）：

1. **承载律**：一切 ℂ/ℝ/exp/log 对象承载于树自铸基座——born 两件 `CxRealPairCore.v`（312 行/48 名/md5 dfcead7d）＋`CxRealPairExpLog.v`（v2·520 行/18 名/md5 728c7a34·c_exp 极坐标/c_log 诚实接口）＋S04 real 线（S04_RealSetoidExpLog）。**stdlib `Complex`/`Reals` 零直用**；stdlib `QArith`/`nat` 面足用可直用（KB34:104 同句）。
2. **槽形律**（规范 §4.2）：一切常数假设走 Section 变元出节参数化·**零 Axiom/Parameter 全局假设**（正形＝piu_zz_tau_enclosure_base.v:1214/:1216 槽）；四关 `Print Assumptions` 必达 `Closed under the global context`（消费侧对表件 P12/V06 除外——其 GAPASUME 槽为**放电位**·消费树内 GREEN 件后即 Closed）。
3. **分面律**（R2）：证明拓扑面＝stem 本体（`vm_compute|native_compute|vm_cast_no_check|Compute` 词面=0）；证书面＝`<stem>_cert.v`（字面证书＋vm_compute 验收器·积形数字字面量 ≥5000 禁直书证明体）；REPL 预演脚本不落 `.v` 不占 400 行谱（规范 §4.2-REPL 冒烟豁免）。
4. **依赖律**（规范 §2.4 六条）：Require 只许指向更低层/更低波；跨段只经 `GaC<k>_Iface_<块>`；同波互 Require 禁；对 L0 只 Import 禁 Export。

**四稿格式约定（全 28 节点统一）**：
- 翻转簇四稿＝**研读卡 → 语句面稿 → REPL 预演脚本 → 验收判据**；维持簇四稿＝**数学命题卡 → 语句面稿 → REPL 预演脚本 → 验收判据**（工单 §1.2 两分簇格式原文）。
- 语句面稿为**命题骨架**（Coq 形语句＋占位注释·不含证明体·不写 `Admitted`·不落盘 `.v`）；Require 头为 LINT-0 候位（锚检与 Iface 实名落刀时定）。
- 承载位记法（各语句面稿头部统一挂注）：`ℂ := CxRealPairCore 承载型`·`cexp/clog := CxRealPairExpLog c_exp/c_log`·`ℝ := S04 real 线`·`Q := QArith`。落刀时以 born md5 冻结实名替换·born 件保名保形不改一字（裁 2）。
- 每稿挂全景卡编号＝cards_C3 对应卡（全景卡底册 :548-829 原卷照录·双向对照）。

---

## ① · fetch-before-cite 实跑账（本席本会话实跑·逐件标注）

| # | 先例件 | 取件通路（本席实跑） | 实读范围 | 关键坐标（本席亲核） |
|---|---|---|---|---|
| 1 | **AFP Perrons_Formula** 条目页 | WebFetch `isa-afp.org/entries/Perrons_Formula.html` | 全文摘要/作者/日期/theory 清单/依赖 | Eberl·**2026-06-17**·3 theories（Perron_Prerequisites/Dirichlet_Series_At_I_Infinity_Bound/Perrons_Formula）·依赖 AFP Dirichlet_Series·摘要「various explicit bounds for the remainder」＋f(σ+it)∈o(t^{1−a}) as t→±∞ |
| 2 | **Perrons_Formula 源件**（沙箱遗物解包·非本席下载·本席直读即 fetch 实核） | `absorb_work_20261101/Perrons_Formula/*.thy`·wc -l＝**1673+616+515＝2804 ✓**（与映射表 §①-0 一致） | Perrons_Formula.thy :40-153/:982-1056/:1208-1282/:1332-1376 全读＋三件语句全表 grep | 见 §③ 各研读卡（`perron_aux_integral`:56-57·`perron_remainder`:59-66·`perron_aux_integral_1`:68-94·`perron_aux_integral_bound`:96-124·vline/hline :106-108·rectpath 分解 :129-153·`perron_bound`:1019·`perron_effective_strong`:1208·`perron_effective`:1230（C=6π+4）·`perron_effective'`:1340（C1=4(3π+2)）·Prerequisites `contour_integral_bound_linepath'`:372·`contour_integral_linepath_same_Im`:378·DSIIB `eval_fds_smallo_Im_going_to_infinity`:484） |
| 3 | **AFP PNT_with_Remainder** 条目页 | WebFetch `isa-afp.org/entries/PNT_with_Remainder.html` | 全文 | Song & Yao·**2024-05-05**·**8 theories**（PNT_Notation/PNT_Remainder_Library/Relation_of_PNTs/PNT_Complex_Analysis_Lemmas/Zeta_Zerofree/PNT_Subsummable/Perron_Formula/PNT_with_Remainder）·依赖 AFP Prime_Number_Theorem·π(x)=Li(x)+O(x·exp(−√(log x)/3653))·零点自由区 β≥1−(1/952320)(log(\|γ\|+2))⁻¹·「revised version of Perron's formula」 |
| 4 | **PNT_with_Remainder 源件** | curl 下载 `afp-PNT_with_Remainder-current.tar.gz`（51561B）解包 `kbgamma_work_20261101/prec_fetch/pntwr/` | 8 theories 全 wc -l＝**5232 行**（Zeta_Zerofree 891/Perron_Formula 1017/PNT_Complex_Analysis_Lemmas 808/余五件合计 2516）＋Zeta_Zerofree 语句全表＋:9-23/:136-163/:180-215/:283-341/:355-360/:409-415/:486-492/:748-777/:872-891 全读＋Perron_Formula 语句全表＋:920-942 | **映射表 §⑤ 未核项「PNT_with_Remainder 行数」本席补核闭环**。主坐标：`cos_inequality_1`:9-23·`fds_mangoldt_eq`:29·`logderiv_zeta_ineq`:136·`inverse_zeta_bound'`:180·`zeta_bound'`:197·`zeta_bound_trivial'`:212（\|ζ(s)\|≤12+2\|Im s\|）·`zeta_nonzero_small_imag'`:283（13/22 窗）·`deriv_zeta_bound`:355（B/r+1/\|s−1\|²）·`logderiv_zeta_bound`:409（5/4·1/(σ−1)）·`zeta_nonzero_region`:872-891（**C₁=1/952320 终形**·:874-882 常数换算链 1/29760·θ/φ→ln）·Borel_Caratheodory1/2/3 :375/:484/:497 |
| 5 | **mathlib LSeries 目录** | WebFetch GitHub API `leanprover-community/mathlib4` contents `Mathlib/NumberTheory/LSeries` | 全目录 23 文件尺寸 | Convergence.lean **6936B**/Nonvanishing.lean **25871B**/RiemannZeta.lean 12256B/DirichletContinuation.lean 19341B——**与映射表 §①-0 尺寸逐一吻合 ✓**；另勘得 `RiemannZetaLogDeriv.lean` 2508B（映射表未列·Z01 辅件候位） |
| 6 | **mathlib Nonvanishing.lean** | curl raw master（493 行/25871B ✓） | 语句全表 grep | `LFunction_ne_zero_of_re_eq_one`:391·`LFunction_ne_zero_of_one_le_re`:404·**`riemannZeta_ne_zero_of_one_le_re`:417（1≤Re s ⇒ ζ≠0）**·`riemannZeta_eq_zero_iff_of_re_nonpos`:483（trivial 零点刻画·P10 域外件） |
| 7 | **strongpnt 仓库** | WebFetch GitHub search API → `math-inc/strongpnt`（updated 2026-10-24）＋git-trees recursive | 全 .lean 清单 | **StrongPNT/ZetaZeroFree.lean 11588B ✓**·PNT1_ComplexAnalysis 278118B/PNT2_LogDerivative 206324B/PNT3_RiemannZeta 238015B/PNT4_ZeroFreeRegion **316954B**/PNT5_Strong 269208B——**与映射表 §①-0 全部吻合 ✓** |
| 8 | **strongpnt ZetaZeroFree.lean** | curl raw main（11588B ✓·两次 ECONNRESET+SSL35 退避后第三发成） | 全文语句＋:63-70/:185-200/:242-262 全读 | `ZetaNoZerosOn1Line'`:35（ζ(1+tI)≠0）·`ZetaNoZerosInBox'`:63（**∃σ<1 存在型**）·`LogDerivZetaHolcSmallT'`:185（**∃σ₂ 存在型**）·`LogDerivZetaHolcLargeT'`:242（**∃A∈Ioc(0,1/2) 存在型**）——**映射表「c 存在型·品质不足」判词本席亲读坐实** |

**未 fetch/未读（fail-loud 登记）**：①mathlib Convergence.lean/RiemannZeta.lean/DirichletContinuation.lean/PhragmenLindelof.lean/EulerProduct 三件——仅目录尺寸核实（#5）·内容坐标一律转引映射表 §①-0 实勘·本席不另引内容坐标；②strongpnt PNT4_ZeroFreeRegion.lean/PNT5_Strong.lean 内容未读（体量 316954B/269208B 已核·#7）；③Lean PNT+（复检席第三线）未 fetch——映射表未给仓坐标·禁猜 ID·留闸 1；④V01-V06 维持簇无先例对象·零 fetch（判词依据＝映射表 §② 四库扫空原文）。

**网络单飞合规**：WebFetch×4（#1/#3/#5/#7）＋curl×4（#4 下载·#6 下载·#8 三发中二败一成·间隔 30-45s 退避实录）·零截断回执·取件遗物全落 `prec_fetch/`（未执行任何包内代码·tar 解包只读）。

---

## ② · 映射表行 → 正典节点主题重映射（±1 不确定度登记）

映射表 §①-1/①-2 的节点拆分系其勘形推断；正典集＝规范裁 1 定谳 P01-P12/Z01-Z10（cards_C3 卡面）。本席按**内容主题**重映射·每节点取所映行的系数·正典重映射加权落映射表给带内：

**Perron 12（映射表 §①-1 六行 → P01-P12）**：

| 正典节点 | 所映行（映射表） | 行系数 | 对表先例坐标（本席实核） |
|---|---|---|---|
| P01 复线积分定义 | 行 1-2「复线/竖线积分定义」 | 0.55 | `perron_aux_integral` :56-57（linepath 竖线 L c T）·HOL-Analysis contour_integral **依赖内建**（AFP 消费不重证→树内须自铸·部分覆盖） |
| P02 线积分代数 | 行 1-2 | 0.55 | Prerequisites `contour_integral_rmul/lmul/divide` :447/:462/:465＋`perron_aux_integral_1` :68-94 |
| P03 ML 估计 | 行 3「围道几何/矩形分解」 | 0.35 | Prerequisites `contour_integral_bound_linepath'` :372-375（**ML 型逐字先例**）＋`contour_integral_linepath_same_Im` :378-395（竖线→实积分归约） |
| P04 Cauchy–Goursat（矩形） | 行 4-5「围道参数化/路径积分计算」 | 0.40 | Perrons_Formula.thy:137 `Cauchy_theorem_convex_simple` 用例（HOL-Analysis 内建·rectpath 全纯零积分）＋:74 `contour_integral_primitive` 用例（原函数存在）——AFP 消费面全·构造重铸全价 |
| P05 Cauchy 积分公式＋导数界 | 行 4-5 | 0.40 | PNT_with_Remainder `PNT_Complex_Analysis_Lemmas` 808 行（Schwarz_Lemma1/2 :310/:342·Borel_Caratheodory1-3 :375/:484/:497）＋ZZ `deriv_zeta_bound`:355 消费形 |
| P06 留数提取（单极点） | 行 6-7「Perron 截断」接缝件 | 0.35 | Perrons_Formula.thy 主链极点项处理（perron_indicator :26 与矩形分解 :129-153 间）＋PNT_with_Remainder Perron_Formula.thy perron_aux 链 :131-611 |
| P07 x^s/s 增长刻画 | 行 11-12「Dirichlet 级数竖线增长/±i∞ 衰减界」 | 0.40 | DSIIB 全件 515 行（`eval_fds_smallo_Im_going_to_infinity` :484-515·o(\|Im w\|^{1−a}) 显式） |
| P08 Perron 截断公式 | 行 6-7 | 0.35 | **两件互证**：Eberl `perron_effective_strong` :1208-1225（4(arctan(T/c)+π+1)·x^c·perron_bound）＋`perron_bound` :1019-1020（Σ\|a_n\|/(n^c(1+T\|ln(x/n)\|))）＋Song-Yao `perron_formula` :920（contour_integrable 形）/`perron_asymp` :936 |
| P09 水平尾项估计 | 行 6-7/8-10 交界 | 0.35 | `perron_aux_integral_bound` :96-124（arctan 闭形余项·perron_remainder :59-66）＋`perron_effective'_aux` :1273（\|ln(x/n)\|≥\|x−n\|/(bx)·MVT2' :1256） |
| P10 围道左移与贡献分解 | 行 3＋8-10 | 0.45 | rectpath 分解 :129-153（矩形四边闭合·Cauchy 零）＋`perron_indicator` :26-35（半整数指示·截断主项） |
| P11 左竖线＋四边合并→ψ 界 | 行 8-10「截断余项显式界」 | 0.45 | `perron_effective'` :1340-1354（**C1=4(3π+2)·C2=2(3π+2)C/ln2·C3 显式**·Tenenbaum Cor 2.1 正形）＋PNT_with_Remainder 3653 常数纪律 |
| P12 ψ 显式界 Q-离散化终装 | 行 8-10 常数面＋树内工艺 | 0.45 | 树内工艺先例为主（D1 GREEN 九件·piu_zz_pnt_qexp·B6/B7 锚）＋AFP 装配工艺旁证（Relation_of_PNTs/PNT_Subsummable 同构工艺·映射表 §①-2 行 7-8） |

正典重映射加权＝(2×0.55+0.35+2×0.40+0.35+0.40+2×0.35+2×0.45+0.45)/12＝**0.42**（映射表 0.425·同带·差 ±1 节点不确定度所致·**总估 20/40/60 不动**）。

**dVp 10（映射表 §①-2 四行 → Z01-Z10）**：

| 正典节点 | 所映行 | 行系数 | 对表先例坐标（本席实核·pntwr 解包） |
|---|---|---|---|
| Z01 −ζ'/ζ Dirichlet 级数 | 行 1-3「dVp 核心不等式/θ 变换」 | 0.40 | ZZ `fds_mangoldt_eq` :29-37（−ζ'/ζ＝mangoldt fds·逐字）＋`abs_conv_abscissa_log_deriv` :39＋`sums_mangoldt` :74＋`sums_Re_logderiv_zeta` :103＋`logderiv_zeta_ineq` :136-163 |
| Z02 三余弦不等式 | 行 1-3 | 0.40 | ZZ `cos_inequality_1` :9-23——**3+4cos x+cos 2x ≥ 0 逐字同构语句先例**（cards_C3-Z02 ① 与 AFP 件词面同构） |
| Z03 ζ(1+it)≠0 | 行 1-3 | 0.40 | ZZ 主链（logderiv_zeta_ineq :136 竞速输入＋zeta_nonzero_region :661/:728 中间形）＋mathlib `riemannZeta_ne_zero_of_one_le_re` :417＋strongpnt `ZetaNoZerosOn1Line'` :35 |
| Z04 ζ 主部展开 | 行 4-6「ζ′/ζ 界」 | 0.35 | ZZ `zeta_bound'` :197（\|ζ(s)\|≤Re ζ(Re s)）＋`zeta_bound_trivial'` :212（带内 12+2\|Im s\| 显式）＋`zeta_bound_gt_1` :244 |
| Z05 dVp ZFR 主定理 | 行 7-8「零点自由区装配」 | 0.40 | ZZ **`zeta_nonzero_region` :872-891（1−β≥C₁/ln(\|γ\|+2)·C₁=1/952320）**＋:748 θ/φ 形（1/29760）＋:874-882 常数换算链（ln(14+4\|γ\|)≤4ln(\|γ\|+2)） |
| Z06 ZFR 内 ζ'/ζ 界 | 行 4-6 | 0.35 | ZZ `deriv_zeta_bound` :355（B/r+1/\|s−1\|²）＋`logderiv_zeta_bound` :409/:618（5/4·1/(σ−1)·σ≤23/20）＋`Re_logderiv_zeta_bound` :486；strongpnt `LogDerivZetaHolcLargeT'` :242（**存在型对照·品质差锚**） |
| Z07 log ζ 解析分支 | 行 7-8 | 0.40 | PNT_Complex_Analysis_Lemmas `holomorphic_logderiv` :20＋`analytic_factorization` :288（零点因子分解·解析域机器）＋`zeta_analytic_on_region`（ZZ :582） |
| Z08 1/ζ 有效界 | 行 7-8 | 0.40 | ZZ `inverse_zeta_bound'` :180（Möbius 级数路线·\|1/ζ(s)\|≤Re ζ(Re s)）＋`inverse_zeta_bound` :343＋`zeta_lower_bound` :396 |
| Z09 小 \|t\| 段/τ₀ 窗 | 行 9-10「显式常数核算」 | 0.50 | ZZ `zeta_nonzero_small_imag'` :283-326（**显式常数链 13/22·129/100·79/50**）＋`zeta_nonzero_small_imag` :327-342（Re s>0 全段闭合） |
| Z10 常数一致化终装 | 行 9-10 | 0.50 | ZZ :872-891 常数换算链（1/952320↔1/29760·θ/φ→ln·PNT_const_C₁_def unfold）＋树内 KB72/zzPhi 证书工艺 |

正典重映射加权＝(3×0.40+2×0.35+3×0.40+2×0.50)/10＝**0.41**（映射表 ≈0.40·同带·**总估 12/22/28 不动**）。

---

# ③ · 翻转簇第一块 · Perron 12（吸收式四稿·P01-P12）

> 全景卡底册编号＝cards_C3 第一块（全景卡-γ解析核段85节点 :561-676）。先例主对表件＝AFP Perrons_Formula（Eberl 2026-06-17·2804 行全量在沙箱）·辅件＝AFP PNT_with_Remainder Perron_Formula/Zeta_Zerofree（5232 行本席解包在 prec_fetch/）。**吸收通道红线（映射表 §⓪）**：先例件证明物零移植——研读对表（数学路线）＋架构转录（结构分解）＋常数纪律参考；Coq Set 承载重证全价保留。⚠Perron 三义碰撞（Perron–Frobenius/Denjoy–Perron/ Perron 公式）照 cards_C3 块头警示。
> γ3 批内子序（映射表 §③-4·骨架先行定义殿后）：P03（0.35 抄骨架）→P08/P09（0.35 两件互证）→P07/P04/P05（0.40）→P10/P11/P12（0.45）→P01/P02（0.55 定义殿后）→P06 缝合。施工波号以规范 §3.4 机械表为准（本稿语句面稿 Require 头按之）。

---

## C3-P01 · 复线积分定义（分段光滑路径·构造性基元）〔W1·deps=[]〕

### P01-研读卡（先例件：AFP Perrons_Formula·覆盖度部分·系数 0.55）
- **先例语句面**（Perrons_Formula.thy 本席实读 :51-57）：`context fixes L defines L ≡ λc T. linepath (Complex c (-T)) (Complex c T)`；`definition perron_aux_integral a c T = contour_integral (L c T) (λz. of_real a powr z / z)`——竖线围道定义形。
- **逐引理映射**：AFP 的 `contour_integral`/`linepath`/`rectpath` 建在 **HOL-Analysis 内建**（`Cauchy_theorem_convex_simple` :137 用例、`contour_integral_primitive` :74 用例皆直接调用）——**AFP 全件消费不重证**；Coq 树内对应积分理论为零（KB34:98 原判·本会话无反证）→ P01/P02 的定义层本体＝**吸收通道覆盖不到的部分**·Set 承载自铸全价。
- **吸收清单**：①竖线 linepath 参数化形（实参数 t∈[−T,T]→c+i·t）为 P08/P09 围道语句面的形状正本；②`perron_aux_integral` 三实参 (a,c,T) 签名＝树内 Perron 积分算子签名参照；③摘要 :46-48「积分非绝对收敛·Cauchy 主值形」——树内语句面必须显式取有限 T 截断形（竖线段积分·Lebesgue 意义不存在的问题被截断消解）·**禁在树内语句面写 ∫_{c−i∞}^{c+i∞} 无穷限形**（红熔断风险登记）。
- **研读成本**：1673 行主件直读（本席已全表）·0.55 系数依据＝映射表 §①-1 行 1-2（语言差中等·承载差全价）。
- **复审条件**（cards_C3-P01 ④ 沿袭）：R4/闸 1 若检出 CoRN/UniMath 构造性积分论可转录形→本件研读卡扩线（现判维持）。

### P01-语句面稿（GaC3_P01_LineIntegralDef.v·语句骨架·不落盘）
```coq
(* GaC3_P01_LineIntegralDef.v —— C3-P01·W1·deps=[]（规范 §3.4 波表）
   红线路径 A：ℂ 承载＝born CxRealPairCore；禁 stdlib Complex/Reals（KB34:104）
   R2 分面：本件为证明拓扑面（数值面无·P09 常数证书另落 GaC3_P09_HorizTail_cert.v）
   全景卡：cards_C3-C3-P01；先例：AFP Perrons_Formula.thy:51-57（研读卡 P01） *)

(* Require 候位（LINT-0 锚检后定·跨段经 Iface §2.3）：
   Require Import CxRealPairCore.        (* born·裁 2 γ1 波末落装·保名 md5 dfcead7d *)
   Require Import CxRealPairExpLog.      (* born·c_exp/c_log·md5 728c7a34 *)
   Require Import GaC1_Iface_Real.       (* C1.1 实有效界（跨段） *)
   Require Import GaC1_Iface_Cx.         (* C1.4 收敛面（跨段） *) *)

Section P01_LineIntegral.
(* 承载位记法：ℂ=CxRealPairCore 型·ℝ=S04 real 线·落刀实名替换 *)

(* 分段 C¹ 路径＝有限段表：每段 (a,b,g)·g:[a,b]→ℂ 连续·[a,b] 上有连续复导数 *)
Definition seg_C1 (g : ℝ -> ℂ) (a b : ℝ) : Prop :=
  ContinuousOn ℝ g (closedQ a b) /\
  exists g' : ℝ -> ℂ,
    ContinuousOn ℝ g' (closedQ a b) /\
    (forall t, openQ a b t -> HasDerivativeAt ℝ ℂ g g' t).

Definition cpath : Type := list (sig (fun p : ℝ * ℝ * (ℝ -> ℂ) => uncurry² seg_C1 p)).

(* 实区间上复值函数的 Riemann 型积分基元（树内零积分理论·本件内含新铸面
   ——构造性 Riemann 和极限·一致连续→可积·显式模；此为全段最深定义） *)
Definition seg_integral (f : ℂ -> ℂ) (a b : ℝ) (g : ℝ -> ℂ) : ℂ := ...

Theorem seg_integral_welldef : forall f a b g h,
  seg_C1 g a b -> g_at_refinement_equal g h a b ->
  seg_integral f a b g = seg_integral f a b h.
(* ◇ 证明体施工位：γ3 施工席·良定（分段加细不变） *)

Definition line_integral (G : cpath) (f : ℂ -> ℂ) : ℂ :=
  fold_right (fun sg acc => cadd (seg_integral f (fst sg) (snd sg) (third sg)) acc) c0 G.

(* 竖线段特化（AFP L c T :56-57 形状转录·有限 T 截断——树内语句面唯一合法围道形） *)
Definition vline_seg (c T : ℝ) : cpath := ...  (* t ↦ c + i·t, t∈[−T,T] *)
End P01_LineIntegral.
```

### P01-REPL 预演脚本（零执行·施工席冒烟用·秒级）
```coqtop
(* 预演命令单——落刀后 coqtop 逐条·无 vm_compute·预期秒级 *)
Require Import GaC3_P01_LineIntegralDef.
Check (seg_integral : (ℂ -> ℂ) -> ℝ -> ℝ -> (ℝ -> ℂ) -> ℂ).
Check (line_integral_welldef : forall f a b g h, ... ).
Check (vline_seg 1 10 : cpath).
Print Assumptions line_integral_welldef.   (* 预期：Closed under the global context *)
```

### P01-验收判据
1. 波末四关四件套 rc=0／语句面具名项计数（seg_C1·seg_integral·line_integral·vline_seg 等 ≥6 名）／PA Closed／coqchk 过。
2. LINT-1..6 全过（本件无 cert 面→LINT-5 以「本件无可计算面」头注挂声明）。
3. 语句面禁形核验：树内语句/证明体**零**无穷限积分写法（∫_{c−i∞}^{c+i∞} 词面 grep=0·Cauchy 主值问题被有限 T 截断消解）。
4. R6 判词维持「需突破」·复审条件登记在案（CoRN/UniMath 检出即重估）·席时基准带 10-14（cards ⑥·不因吸收折价下调证明层全价——研读省路线不省自铸）。

---

## C3-P02 · 线积分代数（线性/拼接/反向/重参数化不变）〔W2·deps=[P01]〕

### P02-研读卡（先例件：AFP Perron_Prerequisites.thy·覆盖度部分-全·系数 0.55）
- **先例语句面**（本席实读）：`contour_integral_rmul` :447／`contour_integral_lmul` :462／`contour_integral_divide` :465（线性三件）；`perron_aux_integral_1` :68-94（c>0 时 perron_aux_integral 1 c T＝2·arctan(T/c)·i——闭形链·经 `contour_integral_primitive` :74→ln 差→Arg→arctan）。
- **逐引理映射**：AFP 线性/常数提取消耗 HOL-Analysis `contour_integral` 代数闭包——树内 P01 自铸后同构代数可照抄**骨架**（命题形状 1:1）·证明体重铸（Riemann 和逐件搬运）；拼接/反向/重参数化 AFP 本件未单列（由 path 代数隐含）→ 从零档·树内代数工艺判例密集（cards ② ln_rate_bound 系/HansonLcm）。
- **吸收清单**：①线性三件命题形状直取；②`perron_aux_integral_1` 的「原函数差→辐角差→arctan」路线为 P09 水平尾项 arctan 余项的路线正本（转录到树内 c_log 承载·born c_log 诚实接口）。
- **研读成本**：0.55·同 P01（同一行带）。

### P02-语句面稿（GaC3_P02_LineIntegralAlg.v）
```coq
(* GaC3_P02_LineIntegralAlg.v —— C3-P02·W2·deps=[C3-P01（stem 直依·同段跨波 §2.4-②）] *)
(* Require 候位：GaC3_P01_LineIntegralDef（W1<W2 ✓）＋born 两件＋GaC1_Iface_* *)
Section P02_Alg.
Variable f g : ℂ -> ℂ.
Variable alpha beta : ℂ.

Theorem line_integral_linear : forall G,
  line_integral G (fun z => cadd (cmul alpha (f z)) (cmul beta (g z)))
  = cadd (cmul alpha (line_integral G f)) (cmul beta (line_integral G g)).

Theorem line_integral_concat : forall G1 G2,
  line_integral (app G1 G2) f = cadd (line_integral G1 f) (line_integral G2 f).

Theorem line_integral_reverse : forall G,
  line_integral (path_reverse G) f = cneg (line_integral G f).

Theorem line_integral_reparam : forall G phi,
  monotone_C1_covering phi -> path_refine (path_reparam G phi) G ->
  line_integral (path_reparam G phi) f = line_integral G f.
End P02_Alg.
```

### P02-REPL 预演脚本
```coqtop
Require Import GaC3_P02_LineIntegralAlg.
Check (line_integral_linear : forall G, ...).
Check (line_integral_concat : forall G1 G2, ...).
Check (line_integral_reverse : forall G, ...).
Print Assumptions line_integral_reparam.  (* Closed 预期 *)
```

### P02-验收判据
1. 四关四件套＋LINT 全过；具名项 ≥4（linear/concat/reverse/reparam）。
2. cards ④ 判词「可及」·B6/B7 锚席时带 3-5（此为吸收式判据下仍从零施工的代数件·系数 0.55 指研读省时）。

---

## C3-P03 · ML 估计（路径长×上界·构造性）〔W3·deps=[P01,P02]〕

### P03-研读卡（先例件：AFP Perron_Prerequisites.thy·覆盖度全·系数 0.35）
- **先例语句面**（本席实读 :372-395）：`contour_integral_bound_linepath'`：f contour_integrable_on linepath a b → 0≤B → (∀x∈closed_segment a b, norm(f x)≤B) → c=norm(b−a) → norm(contour_integral (linepath a b) f) ≤ B·c——**ML 型逐字先例**；`contour_integral_linepath_same_Im` :378-395：竖线积分＝实区间积分（Im z=Im z'=T 时 contour_integral (linepath z z') f ＝ ∫_{a..b} f(Complex x T)）——竖线→实积分归约·P08 逐项积分的归约正本。
- **逐引理映射**：AFP ML 件→树内 P03 主定理（形状同构·承载换 CxRealPair）；`same_Im`→树内 vline 段归约引理（P01 vline_seg 直配）；矩形四边闭合分解（Perrons_Formula.thy:129-153 `R b＝rectpath (Complex c (−T)) (Complex b T)`·vline/hline/hline′ :106-108·Cauchy 零→四边和）——**论证骨架直接可抄**（映射表行 3 判词）·Isar→Coq 语言差中等。
- **吸收清单**：①ML 命题形状＋「显式上界 M 为输入证书形（非 sup 存在断言）」的构造性化形状；②hline/vline/hline′/rectpath 四路径记法族（P10 直接复用）；③路径长 L(γ)=Σ∫|γ′| 的闭式（水平/竖直段）→证书面。
- **研读成本**：0.35（行 3·骨架抄写最快段）。

### P03-语句面稿（GaC3_P03_MLEstimate.v＋GaC3_P03_MLEstimate_cert.v）
```coq
(* GaC3_P03_MLEstimate.v —— C3-P03·W3·deps=[C3-P01,C3-P02] *)
Section P03_ML.
Variable f : ℂ -> ℂ.  Variable M Lg : ℝ.

Theorem ML_bound : forall G,
  path_len G Lg ->
  (forall z, In_path_image G z -> cle (cmod (f z)) M) ->
  cle (cmod (line_integral G f)) (cmul M Lg).

(* 竖线归约（AFP same_Im :378 形状） *)
Theorem vline_integral_reduce : forall c T f,
  T > 0 -> line_integral (vline_seg c T) f
          = seg_integral (fun t => f (cadd (cofR c) (cmul ci (cofR t)))) (negR T) T (fun t => ci).
End P03_ML.

(* —— GaC3_P03_MLEstimate_cert.v（证书面·R2）：hline/vline 路径长 Q 闭式证书＋验收器
   Definition vline_len_cert : forall c T, T > 0 -> QleT (QofR (path_len (vline_seg c T))) (Qmul 2 T).
   Theorem vline_len_check : ... Proof. vm_compute; reflexivity. Qed.  (* cert 面豁免 LINT-5 *) *)
```

### P03-REPL 预演脚本
```coqtop
Require Import GaC3_P03_MLEstimate.
Check (ML_bound : forall G, ...).
Check (vline_integral_reduce : forall c T f, ...).
Check (vline_len_check : ...).   (* 证书面验收器·vm_compute 于 cert 内 *)
```

### P03-验收判据
1. 四关＋LINT 过；ML_bound 语句面与 AFP :372-375 逐形状对表（研读卡在案）；cert 面路径长证书值 vm_compute 绿。
2. 席时带 3-4（cards ⑥）；本件为 P09/P11 估计引擎（消费位普查：P09/P10/P11 Require 命中 ≥3·落刀后 LINT 前闸）。

---

## C3-P04 · Cauchy–Goursat 定理（矩形构造性版）〔W4·deps=[P01,P02,P03]〕

### P04-研读卡（先例件：AFP Perrons_Formula.thy＋HOL-Analysis 依赖内建·覆盖度全（路线）·系数 0.40）
- **先例语句面**（本席实读 :129-153）：矩形 R b＝rectpath (Complex c (−T)) (Complex b T)；`Cauchy_theorem_convex_simple` 用例 :136-140（f 全纯于 cbox→矩形围道积分=0）→ :143-153 展开为 vline c/vline b/hline/hline′ 四边和恒等式——**AFP 全件建在 HOL-Analysis Cauchy 理论上·本体不重证**。
- **逐引理映射**：树内需自铸的四分割 Goursat 迭代（cards ③「紧致性取极限须显式模重述」）——AFP 无此面（依赖内建）→**路线吸收（矩形→四边→零）·证明全价**；原函数存在推论（:74 `contour_integral_primitive` 用例·路径无关）同档。
- **吸收清单**：①矩形围道四边分解恒等式形状（P10 语句面直接消费）；②全纯性谓词在 cbox 上的承载形状（holomorphic_on cbox·树内 CxRealPair 复可微承载实况 cards 标「待勘」→落刀 LINT-0 时核 born 48 名）。
- **研读成本**：0.40（行 4-5）。

### P04-语句面稿（GaC3_P04_CauchyRect.v）
```coq
(* GaC3_P04_CauchyRect.v —— C3-P04·W4·deps=[C3-P01,C3-P02,C3-P03] *)
Section P04_Cauchy.
Variable f : ℂ -> ℂ.
Variable z1 z2 : ℂ.   (* 矩形对角·cbox 承载 *)

Definition is_holo_on_rect : Prop :=
  forall z, In_cbox z1 z2 z -> exists f' : ℂ, HasDerivativeAt ℂ f f' z.  (* 导数连续版足用·Goursat 免连续版列后续折价件·cards ① *)

Theorem cauchy_rect_zero : is_holo_on_rect ->
  line_integral (rect_boundary z1 z2) f = c0.

Theorem rect_decomp_identity : (* AFP :143-153 恒等式形状 *)
  line_integral (rect_boundary z1 z2) f
  = cadd (line_integral (vline_seg (cRe z2) (cIm z1) (cIm z2)) f) ... .

Theorem primitive_exists : is_holo_on_rect ->
  exists F : ℂ -> ℂ, (forall z, In_cbox z1 z2 z -> HasDerivativeAt ℂ F f z)
                   /\ path_independent_line_integral f.
End P04_Cauchy.
```

### P04-REPL 预演脚本
```coqtop
Require Import GaC3_P04_CauchyRect.
Check (cauchy_rect_zero : is_holo_on_rect z1 z2 f -> ...).
Check (rect_decomp_identity : ...).
Check (primitive_exists : ...).
```

### P04-验收判据
1. 四关＋LINT 过；语句面含 AFP 对表形状（rect_decomp_identity ↔ :143-153）。
2. cards ④「需突破」维持·席时带 8-12·证明层全价（0.40 指研读）；复审条件（Isabelle/mathlib Cauchy 可转录形→重估·cards ④）登记。

---

## C3-P05 · Cauchy 积分公式＋Cauchy 导数不等式〔W5·deps=[P01,P03,P04]〕

### P05-研读卡（先例件：AFP PNT_with_Remainder PNT_Complex_Analysis_Lemmas.thy·覆盖度全（语句面）·系数 0.40）
- **先例语句面**（本席实读·pntwr 解包 808 行）：`Schwarz_Lemma1` :310／`Schwarz_Lemma2` :342／`Borel_Caratheodory1` :375／`Borel_Caratheodory2` :484／`Borel_Caratheodory3` :497——Song-Yao 件自带 B–C 全套（**映射表 §①-3 行 11-18 判「P–L/B–C 构造性化」的实战形**）；ZZ `deriv_zeta_bound` :355-358：圆周上 \|pre_zeta 1 w\|≤B → \|ζ′(s)\|≤B/r＋1/\|s−1\|²——**Cauchy 导数不等式的消费形逐字先例**（显式形状·非抽象 k!·M/rᵏ）。
- **逐引理映射**：树内 CIF 主件从零重证（P04 消费）；**导数不等式取 AFP 消费形（B/r＋1/\|s−1\|² 特化）为语句面正本**——比抽象 k!·M/rᵏ 少一层几何常数泛化·与 Z06/P09/P11 消费直接同构（研读效率最高映射）；圆周参数化 z₀+re^{it} 吃 born c_exp＋**2π 周期归约断点（KB36R :149·C1.4 残件）**——cards ⑤ 强消费位登记。
- **吸收清单**：①deriv_zeta_bound 形状（r/B/1/\|s−1\|² 三参）；②B–C 三件命题形状（Z06 消费·本件语句面预留 Require 位）；③圆周积分归约形。

### P05-语句面稿（GaC3_P05_CauchyFormula.v）
```coq
(* GaC3_P05_CauchyFormula.v —— C3-P05·W5·deps=[C3-P01,C3-P03,C3-P04] *)
Section P05_CIF.
Variable f : ℂ -> ℂ.  Variable z0 : ℂ.  Variables r M : ℝ.

Theorem cauchy_integral_formula : (* 矩形/圆盘域·z₀ 内点 *)
  holo_on_disk f z0 r -> r > 0 ->
  f z0 = cmul (cinv (cmul (cofR (2*PI) ci)))   (* 2πi·c_exp 承载·2π 周期位=C1.4 残件消费槽 *)
              (line_integral (circle_seg z0 r) (fun z => cdiv (f z) (csub z z0))).

Theorem cauchy_deriv_bound : (* AFP ZZ deriv_zeta_bound :355 消费形·泛化到一般 f *)
  holo_on_disk f z0 r -> (forall w, on_circle z0 r w -> cle (cmod (f w)) M) ->
  exists f' : ℂ -> ℂ, (forall z, In_disk z0 r z -> HasDerivativeAt ℂ f f' z)
    /\ forall z, In_disk_inner z0 r z -> cle (cmod (f' z)) (cdiv M (cofR r)).

Theorem cauchy_deriv_bound_k : forall k, (* k 阶·k!·M/r^k·P11 常数面消费位 *)
  ... -> cle (cmod (deriv_k f k z)) (cdiv (cmul (cofR (fact k)) M) (cpowR r k)).
End P05_CIF.
```

### P05-REPL 预演脚本
```coqtop
Require Import GaC3_P05_CauchyFormula.
Check (cauchy_integral_formula : ...).
Check (cauchy_deriv_bound : ...).
Check (cauchy_deriv_bound_k : forall k, ...).
Print Assumptions cauchy_deriv_bound.  (* 预期：仅 2π 周期位槽（C1.4 残件落装前）·落装后 Closed *)
```

### P05-验收判据
1. 四关＋LINT 过；deriv_bound 语句与 ZZ :355-358 三参形状对表在案。
2. **前置硬闸**：P04 绿＋C1.4 残件（2π 周期）落装——双缺一阻塞（cards ④ 复审条件·落装即复勘）·席时带 6-9。

---

## C3-P06 · 留数提取（单极点·ζ'/ζ 极点面）〔W6·deps=[P04,P05,Z03,Z04]〕

### P06-研读卡（先例件：AFP 两件接缝·覆盖度全·系数 0.35）
- **先例语句面**：Eberl 件以 `perron_indicator` :26-35（半整数指示函数·sum_upto′ 定义 :23）＋矩形分解 :129-153 实现「极点项→主项」·显式留数定理未单列（隐于 perron_asymp_aux2 :792 主链）；Song-Yao 件 Perron_Formula.thy `perron_aux_1/2/3` :131/:286/:443/:460/:470/:611 接缝链（perron_integrable :124→perron_formula :920）。
- **逐引理映射**：树内留数定理＝P05 特化＋洛朗系数比较（cards ③）·AFP 无单列先例件→路线吸收·重铸全价；**Res(−ζ'/ζ,1)=1 由 Z04 主部系数证书直给**（cards ②·纯 Q 面·cert 面正位）；零点重数判别面——cards ③「待勘」+勘形修正注记（dVp 档零点全在围道外·P10 绕开重数）→本件语句面**只铸单极点情形**（禁铸 m 重泛化——降面注记·非降档：重数面归 γ4/W3 槽若需）。
- **吸收清单**：①sum_upto′（:23 `sum_upto' f x ＝ Σ_{n≤x}′ f n` 半权重）形状→树内 Perron 主项承载（P10/P08 消费）；②单极点残差=系数极限的构造性语句形。

### P06-语句面稿（GaC3_P06_ResidueSimple.v）
```coq
(* GaC3_P06_ResidueSimple.v —— C3-P06·W6·deps=[C3-P04,C3-P05,C3-Z03,C3-Z04] *)
Section P06_Residue.
Variable f : ℂ -> ℂ.  Variable s0 : ℂ.

Definition residue_at (f : ℂ -> ℂ) (s0 : ℂ) : ℂ :=
  lim (fun eps => cdiv (cmul (cofR eps) ...) ...)  (* 洛朗系数比较构造形·cards ③ *)

Theorem rect_single_pole_residue : (* P05 特化·域内唯一单极点 *)
  holo_on_rect_except f z1 z2 s0 -> is_simple_pole f s0 ->
  line_integral (rect_boundary z1 z2) f
  = cmul (cofR (2*PI) ci) (residue_at f s0).

(* 应用件（Z04 消费·证书面锚）：Res(−ζ'/ζ,1)=1 —— 纯 Q 系数证书·落 GaC3_Z04_cert 消费 *)
Theorem res_neg_logderiv_zeta_1 : residue_at (fun s => cneg (logderiv_zeta s)) c1 = cofR 1.
End P06_Residue.
```

### P06-REPL 预演脚本
```coqtop
Require Import GaC3_P06_ResidueSimple.
Check (rect_single_pole_residue : ...).
Check (res_neg_logderiv_zeta_1 : residue_at (fun s => cneg (logderiv_zeta s)) c1 = cofR 1).
```

### P06-验收判据
1. 四关＋LINT 过；语句面**无 m 重泛化**（重数判别面禁入·勘形修正注记执行位）；Res(−ζ'/ζ,1)=1 证书面绿。
2. 席时带 5-8；P10/P08 消费位普查 ≥2 命中。

---

## C3-P07 · x^s/s 与 x^ρ/ρ 增长刻画〔W1·deps=[]〕

### P07-研读卡（先例件：AFP Dirichlet_Series_At_I_Infinity_Bound.thy·覆盖度全·系数 0.40）
- **先例语句面**（本席实读 :484-515 全证）：`eval_fds_smallo_Im_going_to_infinity`：conv_abscissa f < c−a → a∈[0,1) → eval_fds f ∈ o[\|Im w\|→∞ within {Re s ≥ c}](λw. \|Im w\|^{1−a})——**±i∞ 衰减界独立 theory（515 行/9 语句）**；`fds_at_ii_infinity_bound` :48/:54（显式界函数对）；`dist_consec_nat_powr_complex_le` :11。
- **逐引理映射**：cards ① 的 \|x^s\|=x^σ（c_exp 极坐标恒等式）与 \|1/s\|≤1/max(σ,\|t\|)——**承载面 born c_exp 直给（KB36R :110-129 后延一件）·构造化中等**；零点项衰减 \|x^ρ/ρ\|≤x·exp(−(ln x)/(R ln τ))/\|ρ\|——实 exp 换算全显式→证书面主体（vm_compute Q 证书·KB72 工艺）；AFP DSIIB 的 o 形（渐近）**不直搬**（构造性承载禁渐近算子当证书）——取其「Re s 窗内一致界」的**定量重述**为语句面形状。
- **吸收清单**：①DSIIB 界函数对形状（:48-58）；②|e^z| 模恒等式→c_exp 极坐标（born 后延）；③ρ 衰减界的显式参数化（R·τ 槽形接 Z05）。

### P07-语句面稿（GaC3_P07_PowerGrowth.v＋cert）
```coq
(* GaC3_P07_PowerGrowth.v —— C3-P07·W1·deps=[]（L0：born c_exp＋S04＋C1.2 经 GaC1_Iface_Real） *)
Section P07_Growth.
Variables x sigma t : ℝ.
Lemma cexp_mod_identity : cmod (cexp (cmul (cofR sigma) ci) ...) = ...  (* |e^{(σ+it)ln x}|=e^{σ ln x}·c_exp 极坐标直给 *)
Theorem xpow_mod : x > 0 -> cmod (cpow x (cmk sigma t)) = cpowR x sigma.
Theorem inv_s_bound : sigma > 0 \/ t <> 0 -> cle (cmod (cinv (cmk sigma t))) (cinv (cofR (Rmax sigma (Rabs t)))).
(* 零点项衰减（证书面主体·R/τ 槽形） *)
Theorem zero_term_decay : forall R tau beta rho x,
  beta <= 1 - 1/(R * ln tau) -> rho = mk beta _ ->
  cle (cmod (cdiv (cpow x rho) rho)) (cmul x (cdiv (cexp (cnegR ((ln x)/(R*ln tau)))) (cmod rho))).
End P07_Growth.
(* cert：x^ρ/ρ 逐点 Q 证书·vm_compute（KB72 工艺·禁证明体内联巨算） *)
```

### P07-REPL 预演脚本
```coqtop
Require Import GaC3_P07_PowerGrowth.
Check (xpow_mod : forall x sigma t, ...).
Check (inv_s_bound : ...).
Check (zero_term_decay : ...).
```

### P07-验收判据
1. 四关＋LINT 过；cert 面衰减界样点带 vm_compute 绿（KB72 判例工艺）；语句面 vm_compute 词面=0（LINT-5）。
2. 席时带 2-4（B6/B7 直用带）；P08/P09/P10 消费位普查 ≥3。

---

## C3-P08 · Perron 截断公式（有限 T 竖线积分＝ψ(x)−误差）〔W2·deps=[P01,P07,Z01]〕

### P08-研读卡（先例件：AFP 两件互证·覆盖度全·系数 0.35——研读效率最高段）
- **先例主件**（Eberl·本席实读 :1007-1056/:1208-1245）：`perron_bound` :1019-1020 `perron_bound f c x T ＝ Σ_n \|a_n\|/(n^c·(1+T·\|ln(x/n)\|))`；`sums_perron_bound` :1026（级数收敛·comparison_test）；`perron_effective_strong` :1208-1225 `dist A B ≤ 4·(arctan(T/c)+π+1)·x^c·perron_bound f (c+Re z) x T`（A＝有限 T 竖线积分·B＝2πi·sum_upto′）；`perron_effective` :1230-1245（C＝6π+4 常数化推论）；:1007-1017 文注「C≤6π+4 for all T,c」（Tenenbaum II.2.1 Thm 2 正形）。
- **先例辅件**（Song-Yao·本席实读 :920-942）：`perron_formula` :920-926（b∈(0,T]·\|a_1\| 级数和 ≤B 假设下 contour_integrable 形）＋`perron_asymp` :936-942（x∉ℕ 限制下 T→∞ 极限形）——**两件独立成品互证·路线唯一性强**（映射表行 6-7 判词）。
- **逐引理映射**：树内语句面取 f := −ζ'/ζ Dirichlet 级数（Z01 承载）·z := 0 特化（sum_upto′(Λ(n)/1)→ψ 承载·D1 GREEN piu_zz_pnt_psi/rateup 消费）——perron_bound 级数→min(1,1/(T\|ln(x/n)\|)) 形（cards ①·Titchmarsh Thm 3.12/M-V Thm 5.3 同型·文献坐标 cards 自注「R4 复核」留闸 1）；**x 整数端点项**（Λ(x) 半整数位移·cards ③）＝sum_upto′ 半权重指示的语义位（AFP :26-35 perron_indicator 语句形状为对表锚）。
- **吸收清单**：①perron_bound 级数定义形状（树内 Z01 承载重述）；②4(arctan(T/c)+π+1) 常数链→树内 cert 面（P09 arctan 闭形 P02-研读卡联动）；③contour_integrable 前置件形状（:920）→树内可积性旁证（P01 seg_integrable 消费）。
- **研读成本**：0.35·截断段先例语句面与树内消费形几乎同构（映射表 §①-6 禁虚高理由③）。

### P08-语句面稿（GaC3_P08_PerronCutoff.v＋cert）
```coq
(* GaC3_P08_PerronCutoff.v —— C3-P08·W2·deps=[C3-P01,C3-P07,C3-Z01]（规范 §3.4 波表）
   跨段消费：GaC2_Iface_DS（C2.1/C2.2 上游·Z01 直依在段内）；L0：piu_zz_pnt_psi/rateup（D1 GREEN·ψ 承载） *)
Section P08_Cutoff.
Variables x c T : ℝ.
Variable zeta_logderiv_DS : DirichletSeries.  (* Z01 承载·−ζ'/ζ 级数形 *)

Definition perron_bound_ld (x c T : ℝ) : ℝ :=   (* AFP :1019 形状·Z01 系数 Λ(n) *)
  DS_series_sum (fun n => cmul (Lambda_n n) (cinv (cmul (cpowR n c)
                     (cadd 1 (cmul T (Rabs (ln (Rdiv x n)))))))).

Theorem perron_cutoff : x > 1 -> c > 1 -> T > 0 ->
  cabs (cadd (psi_carrier x)
             (cneg (cmul (cinv (cofR (2*PI) ci))
                         (line_integral (vline_seg c T)
                          (fun s => cdiv (cmul (logderiv_neg_zeta s) (cpow x s)) s)))))
        <= perron_bound_ld x c T.
(* R(T,x) 形＝Σ Λ(n)(x/n)^c·min(1,1/(T|ln(x/n)|))——AFP 4(arctan(T/c)+π+1)·x^c·perron_bound
   与 min 形的换算证书落 cert 面·两形并登记（禁只留其一：P11 T 竞速消费 min 形） *)
End P08_Cutoff.
(* cert：perron_bound_ld 有限截断 Q 证书＋min 形换算验收器（vm_compute） *)
```

### P08-REPL 预演脚本
```coqtop
Require Import GaC3_P08_PerronCutoff.
Check (perron_cutoff : forall x c T, ... ).
Check (perron_bound_ld 2 2 10 : ℝ).   (* 型检查·非求值 *)
Print Assumptions perron_cutoff.      (* 预期：GAPASUME 解析槽（Z01 级数形）·施工后闭合 *)
```

### P08-验收判据
1. 四关＋LINT 过；语句面与 AFP `perron_effective_strong` :1213 逐形状对表（研读卡在案）；min 形与 4(arctan+π+1) 形换算证书绿。
2. cards ④「需突破」维持·席时带 10-14；**复审条件**（cards ④·任何 ITP Perron 截断形式化→立即吸收式重估全块）——本研读卡已兑现该条件（AFP 两件在案）·剩余风险面收敛到构造重铸全价。
3. R2：证明体无巨型数字字面量（≥5000 禁入·cert 承载）。

---

## C3-P09 · 水平尾项估计（\|t\|=T 边·T 选取优化）〔W9·deps=[P03,P07,V05,Z06]〕

### P09-研读卡（先例件：AFP Perrons_Formula.thy·覆盖度全·系数 0.35）
- **先例语句面**（本席实读 :96-124/:1273-1282）：`perron_aux_integral_bound` :96-124——dist I (perron_indicator a) ≤ perron_remainder a c T·其中 `perron_remainder` :59-66 `a^c/(πT)·(if a=1 then c else 1/\|ln a\|)`——**arctan 闭形余项的显式形**；`perron_aux_integral_1` :68-94（arctan 路线：原函数差→Arg→arctan·arctan_le_self :121 用例）＋`perron_effective'_aux` :1273-1282（\|ln(x/n)\| ≥ \|x−n\|/(bx)·MVT2' :1256）——水平边 ln 估计的两个全部原料。
- **逐引理映射**：树内水平边=ML（P03）直接应用·cards ③「P03 绿后转录级」；T 优化表（T=τ^A·Dusart 2010 形·cards ①）——**A 表与 ln^b 常数全落 cert 面**（R2·vm_compute）；AFP perron_remainder 的 \|ln a\| 分情形（a=1 特化）形状→树内 x/n=1 端点分情形语句形（与 P08 min 形联动）。
- **吸收清单**：①perron_remainder 分情形形状；②arctan_le_self→树内 arctan 不等式承载位（c_log/c_exp born 承载·无 stdlib arctan——构造性 arctan 界为新铸小件·登记）；③MVT 实线件（C1.1 实有效界消费）。

### P09-语句面稿（GaC3_P09_HorizTail.v＋cert）
```coq
(* GaC3_P09_HorizTail.v —— C3-P09·W9·deps=[C3-P03,C3-P07,C3-V05,C3-Z06] *)
Section P09_Horiz.
Variables x c T eta Cb : ℝ.  Variable b : Q.   (* ln^b 档·b∈{2,3} 证书 *)

Theorem horizontal_edge_bound : T > 0 -> eta > 0 ->
  cle (cmod (line_integral (hline_seg (1 - eta) c T)   (* t=+T 水平边 *)
              (fun s => cdiv (cmul (logderiv_neg_zeta s) (cpow x s)) s)))
      (cmul (cofR (c - 1 + eta))
            (cmul (cofR (Cb * ln_pow tau T b)) (cdiv (cpowR x c) T))).
(* ML（P03）直接档·V05/Z06 边界界消费；t=−T 边同构引理对称 *)

(* T 优化表：T = τ^A·A 显式（cert 面 Q 表·Dusart 2010 形） *)
Definition T_opt_table : list (Q * Q) := ...   (* 证书面字面·A→尾项显式函数 *)
End P09_Horiz.
(* cert：A 表＋ln^b 常数族 vm_compute 证书＋验收器 *)
```

### P09-REPL 预演脚本
```coqtop
Require Import GaC3_P09_HorizTail.
Check (horizontal_edge_bound : ...).
Check (horizontal_edge_bound_sym : ...).   (* t=−T 对称件 *)
Check (T_opt_table : list (Q * Q)).
```

### P09-验收判据
1. 四关＋LINT 过；cert A 表绿；两水平边（±T）齐备（漏边=常见错·判据点名）。
2. 席时带 3-5；P11 消费位普查命中。

---

## C3-P10 · 围道左移与贡献分解（极点项 x·零点全在围道外）〔W8·deps=[P06,P07,V04,Z03,Z04,Z05]〕

### P10-研读卡（先例件：AFP Perrons_Formula.thy rectpath 链·覆盖度全·系数 0.45）
- **先例语句面**（本席实读 :112-153）：`consider "a ∈ {0<..<1} | a = 1 | a > 1"` :112 三分cases→a>1 支 :129-153：R b＝rectpath·`Cauchy_theorem_convex_simple` 零积分→`:143 四边和恒等式`→`vline c = vline b − hline + hline′`——**「矩形闭合+域内全纯→竖线等价变换」的骨架全件**。
- **逐引理映射**：树内「ZFR→围道域内无零点」接缝（cards ③ 经典默认跳步·形式化自铸）——AFP 的对应位＝rectpath 像集 ⊆ cbox ⊆ −{0} 链 :134-152（几何承载→解析条件的逐点传递形状）·**形状可抄·零点谓词面从零**（Z05/V04 消费位）；trivial 零点（s=−2m）与 s=0 域外核验——mathlib `riemannZeta_eq_zero_iff_of_re_nonpos` :483（Re s≤0 ⇔ 负偶）为语句面对表锚（本席实读·承载禁直用·形状参照）；留数退化单极点＝P06 消费。
- **吸收清单**：①rectpath 四边恒等式（:143 形状·P04 已转录）；②「像集⊆域→域内性质逐点传递」引理形状；③勘形修正注记（块头）执行位——**语句面禁铸 Σ_ρ x^ρ/ρ 逐零点项与 N(T) 零点计数**（零点全被 ZFR 挡在围道外·砍两类经典深坑·cards 块头勘形修正）。

### P10-语句面稿（GaC3_P10_ContourShift.v）
```coq
(* GaC3_P10_ContourShift.v —— C3-P10·W8·deps=[C3-P06,C3-P07,C3-V04,C3-Z03,C3-Z04,C3-Z05] *)
Section P10_Shift.
Variables x c T eta : ℝ.

(* ZFR→域内无零点接缝（自铸·Z05/V04 消费） *)
Definition contour_region (eta T c : ℝ) : Region := ...
Lemma zfr_implies_no_zero_in_region :
  (forall t, cle (cofR (Rabs t)) tau_param) ->   (* τ=max(|t|,τ₀) 参数化·Z09 闭合 *)
  ZFR_holds (R_slot) (tau0_slot) ->              (* GAPASUME 槽·Z10 证书族放电 *)
  NoZeroIn contour_region.

Theorem contour_shift_pole : x > 1 -> c > 1 -> T > 0 -> eta > 0 ->
  zfr_implies_no_zero_in_region ... ->
  cmul (cinv (cofR (2*PI) ci))
       (line_integral (rect_boundary (mk (1-eta) (negR T)) (mk c T))
                      (fun s => cdiv (cmul (logderiv_neg_zeta s) (cpow x s)) s))
  = cpowR x 1.   (* Res_{s=1}=x·单极点·P06 消费·无逐零点项 *)

Lemma trivial_zeros_outside : forall m:nat, In (cofR (-(2*m))) (rect_region ...) -> False.  (* mathlib :483 形状参照 *)
End P10_Shift.
```

### P10-REPL 预演脚本
```coqtop
Require Import GaC3_P10_ContourShift.
Check (zfr_implies_no_zero_in_region : ...).
Check (contour_shift_pole : ...).
Check (trivial_zeros_outside : ...).
```

### P10-验收判据
1. 四关＋LINT 过；语句面**无 Σ_ρ 逐零点项·无 N(T)**（勘形修正执行位·词面 grep=0）；zfr→no_zero 接缝引理在案。
2. 席时带 8-12；cards ④ 复审条件（Z05/V4 任一降档翻转即连带重估）登记·三档禁降。

---

## C3-P11 · 左竖线估计＋四边合并 → ψ(x) 显式界〔W10·deps=[P08,P09,P10,V05,Z06,Z09]〕

### P11-研读卡（先例件：AFP perron_effective′＋PNT_with_Remainder 常数纪律·覆盖度全（常数面部分）·系数 0.45）
- **先例语句面**（本席实读 :1332-1376）：`perron_effective'` :1340-1354——dist(A x, I) ≤ **C1·C3^(c+Re s)·B(2x)/x^{Re s}·(1+x/T·(4 ln T+9))** ＋ **C2·x^c·(c+Re s−σ_a)^{−α}/T**，C1=4(3π+2)·C2=2(3π+2)C/ln2·C3=2 或 1/2（分域）——**Tenenbaum Cor 2.1 的全显式常数展开**（文注 :1337-1338「Tenenbaum 版本以 Big-O 隐常数·本件显式化」——**正是树内全战役通病面（O 常数化）的先例正形**）。
- **先例辅件**：PNT_with_Remainder 主定理 π(x)=Li(x)+O(x·exp(−√(log x)/3653))（条目页 fetch·3653 常数纪律）＋ZZ C₁=1/952320 终形链 :872-891——**显式常数有限集的实战谱**。
- **逐引理映射**：树内四边合并（右竖线 P08 精确项＋水平 P09＋左竖线 Z06/V05×x^{1−η}/\|s\|＋极点 P10）·T 竞速逐常数——**项多易错·B6/B7 红点密度教训**（cards ③·勘形先清项表）；log² 档 C₉·x/ln²x 与 log³ 档 C₁₀·x·exp(−c₁₁(ln x)^{3/5}(ln ln x)^{−1/5})——**先例常数集≠树内消费常数**（映射表行 8-10 判词）·数值自算→cert 面全族 vm_compute；先例 (1+x/T·(4lnT+9)) 项结构为树内左竖线项分解的形状参照。
- **吸收清单**：①perron_effective′ 双项结构（截断主项＋T 衰减项）为四边合并的架构正本；②C1/C2/C3 常数命名纪律（显式·分域 if 形）；③左竖线段 \|−ζ'/ζ\|×x^{1−η}/\|s\|×段长的 ML 消费链（P03/Z06/V05）。

### P11-语句面稿（GaC3_P11_PsiBound.v＋cert）
```coq
(* GaC3_P11_PsiBound.v —— C3-P11·W10·deps=[C3-P08,C3-P09,C3-P10,C3-V05,C3-Z06,C3-Z09] *)
Section P11_Merge.
Variables x T : ℝ.
(* GAPASUME 双档槽（KB34 降链案 α 接口位·V06 双槽形联动） *)
Variable C9  : Q.   (* log² 档·x≥x1·显式 *)
Variable C10 c11 : Q.  (* log³ 档·Karatsuba–Korobov 品质 *)
Variable x1 : Q.

Theorem psi_explicit_log2 : x >= x1 ->
  cabs (csub (psi_carrier x) (cpowR x 1)) <= (QtoR C9) * x / (ln x)^2.
Theorem psi_explicit_log3 : x >= x1 ->
  cabs (csub (psi_carrier x) (cpowR x 1))
    <= (QtoR C10) * x * cexp (cnegR (c11 * (ln x)^(3/5) * (ln (ln x))^(-1/5))).
(* 四边合并证明拓扑：perron_cutoff（P08）＋horizontal_edge_bound（P09）
   ＋contour_shift_pole（P10）＋左竖线 ML 链（P03×Z06/V05）——项表勘形（cards ③）：
   右竖线主项 1｜水平 2｜左竖线 1｜极点 1——五项·合并竞速位＝T 选取（P09 cert A 表） *)
End P11_Merge.
(* cert：C9/C10/c11/x1 常数族 vm_compute 全值核算＋验收器（R2 正形·积形字面 ≥5000 全落此） *)
```

### P11-REPL 预演脚本
```coqtop
Require Import GaC3_P11_PsiBound.
Check (psi_explicit_log2 : forall x, ...).
Check (psi_explicit_log3 : forall x, ...).
Check (C9 : Q). Check (C10 : Q). Check (c11 : Q). Check (x1 : Q).
```

### P11-验收判据
1. 四关＋LINT 过；cert 常数族 vm_compute 绿＋验收器引理绿；双档语句齐备（log²⊕log³·禁只铸一档——KB34 α 案接口位）。
2. 席时带 8-12；**cards ④ 复审条件执行位**（P08/P10 绿后复勘·常数项表勘形不足即返工——R1 三稿先行的本块验证位·本四稿即其产物）。

---

## C3-P12 · ψ 显式界 Q-离散化终装（GAPASUME 槽放电对表形）〔W11·deps=[P11]〕

### P12-研读卡（先例件：树内工艺先例为主·系数 0.45＋工艺注）
- **先例面**：外部先例弱（AFP 为 π–Li 形·无 ψ-Q 离散化件）→**树内消费侧同工艺先例正位**：D1 GREEN 九件（piu_zz_pnt_qexp/ipow/rateup/assembly·KB57 五件接口）＋S03_QExp 证书机＋KB72 vm_compute 工艺＋pec_theta_bound（abl_Pr_erdos_theta:191·ψ−θ 尾项消费）——cards ③「D1-B5 同工艺重用·零新地形」。
- **逐引理映射**：P11 解析界→Q-exp 整数证书消费形·槽形对表 tau_enclosure_base:1214 HLn_rate_up/:1216 lo 槽（规范 §4.2 正形）·ε₀=1/6600@X₀=664000000 定常化点（KB34:67 消费形·cards ①）。
- **吸收清单**：①GAPASUME 放电语句形（hl_le_t 双向）；②验收器形状（zzPhi 正形）；③ψ−θ 桥尾项换算证书位。
- **注**：本件在映射表 12 推断节点中无独立行（其拆分含于「装配/常数面」）·主题映射归行 8-10（0.45）·树内工艺为主——**cards ④「可及」判词维持**。

### P12-语句面稿（GaC3_P12_QDiscret.v＋cert）
```coq
(* GaC3_P12_QDiscret.v —— C3-P12·W11·deps=[C3-P11]
   L0 消费：piu_zz_pnt_qexp/piu_zz_pnt_rateup（D1 GREEN）·S03_QExp·abl_Pr_erdos_theta:191（ψ−θ 桥） *)
Section P12_Discret.
Variable N0 : N.                    (* ε₀ 定常化窗端·消费域最小端 X₀=664000000 *)
Variable eps0 : Q.                  (* 1/6600·证书面字面 *)

Theorem psi_q_discret_up : forall M, (M >= N0)%N ->
  hl_le_t (QofR (psi_carrier (Z.of_nat M))) (psi_hi M).
Theorem psi_q_discret_lo : forall M, (M >= N0)%N ->
  hl_le_t (psi_lo M) (QofR (psi_carrier (Z.of_nat M))).
(* GAPASUME 槽放电对表形：tau_enclosure_base:1214 HLn_rate_up / :1216 lo 槽同构·KB34:67 消费形 *)
(* ψ−θ 尾项换算（pec_theta_bound 消费）落 cert 证书 *)
End P12_Discret.
(* cert：ε₀/X₀/psi_lo/psi_hi 字面族＋vm_compute 验收器（zzPhi 正形） *)
```

### P12-REPL 预演脚本
```coqtop
Require Import GaC3_P12_QDiscret.
Check (psi_q_discret_up : forall M, ...).
Check (psi_q_discret_lo : forall M, ...).
Print Assumptions psi_q_discret_up.  (* 预期：Closed（P11 链绿后·消费侧唯一非 Closed 槽消解位） *)
```

### P12-验收判据
1. 四关＋LINT 过；cert ε₀ 定常化字面族绿；**PA 恰显 GAPASUME 唯一槽→施工后 Closed**（全链整合首例成立条件④·映射表 §④）。
2. 席时带 2-4（B6/B7 直用带）；消费位（C4.2-01/02/04/05 经裁 4 重映射 Require GaC3_P12）普查 ≥4 命中。

---

# ④ · 翻转簇第二块 · dVp 零点自由区 10（吸收式四稿·Z01-Z10）

> 全景卡底册编号＝cards_C3 第二块（全景卡 :677-821）。主对表件＝AFP PNT_with_Remainder `Zeta_Zerofree` theory（891 行·本席解包全表·:9-23/:136-163/:180-215/:283-341/:355-360/:409-415/:486-492/:748-777/:872-891 全读）；辅件＝strongpnt ZetaZeroFree.lean（11588B·本席 fetch·**存在型品质对照锚**）；mathlib Nonvanishing.lean（493 行·本席 fetch·:391/:404/:417/:483）。**吸收通道红线同 §③ 块头。**

---

## C3-Z01 · −ζ'/ζ 的 Dirichlet 级数表示与绝对收敛界〔W1·deps=[]〕

### Z01-研读卡（先例件：ZZ theory·覆盖度全·系数 0.40）
- **先例语句面**（pntwr 解包·本席实读）：`multiplicative_fds_zeta` :25（ζ 完全乘性）→`fds_mangoldt_eq` :29-37 **`fds mangoldt_complex = −(fds_deriv fds_zeta / fds_zeta)`**——−ζ'/ζ＝Λ(n) Dirichlet 级数的**逐字先例**；`abs_conv_abscissa_log_deriv` :39（绝对收敛横坐标 ≤1）＋`abs_conv_abscissa_mangoldt` :44＋`sums_mangoldt` :74＋`sums_Re_logderiv_zeta` :103（实部 has_sum 形）＋`logderiv_zeta_ineq` :136-163（三余弦加权和 ≤0 的级数逐项形——Z02/Z03 竞速输入正本）＋`logderiv_zeta_bound` :409-411（1<σ≤23/20 ⇒ \|logderiv ζ σ\| ≤ 5/4·1/(σ−1)——**显式 C₁ 邻域界**）。
- **逐引理映射**：树内 Λ(n) 承载＝lcm 幂差分（D1-B3 GREEN·cards ②）——**承载差全价**（AFP 用 mangoldt 算子·树内用 lcmpow 差分）；级数逐项求导一致收敛交换（C2.1 消费·GaC2_Iface_DS）；σ≥1+δ 定量界 1/(σ−1)+C₁→cert 面截断证书（vm_compute）。
- **吸收清单**：①fds_mangoldt_eq 恒等式路线（对数导数=−Λ 级数）；②logderiv_zeta_ineq 的「has_sum 逐项→加权和非负」架构（Z03 直接消费）；③logderiv_zeta_bound 的 5/4·23/20 显式常数纪律（邻域形状→Z04/Z06 对表）。

### Z01-语句面稿（GaC3_Z01_LogDerivSeries.v＋cert）
```coq
(* GaC3_Z01_LogDerivSeries.v —— C3-Z01·W1·deps=[]
   跨段：GaC2_Iface_DS（C2.1 半平面收敛/C2.2 Euler 乘积）·L0：D1-B3 lcmpow（GREEN）·S04 *)
Section Z01_Series.
Variables s : ℂ.  Variables delta sigma : ℝ.

Definition logderiv_neg_zeta (s : ℂ) : ℂ := cneg (cdiv (zeta_deriv s) (zeta s)).  (* Z03/Z07 链承载 *)

Theorem logderiv_neg_zeta_series : Re s > 1 ->
  logderiv_neg_zeta s = DS_sum (fun n => cmul (Lambda_n n) (cpow n (cneg s))).
(* AFP fds_mangoldt_eq :29 恒等式路线·Λ(n)=lcmpow 差分承载·C2.1 交换消费 *)

Theorem logderiv_neg_zeta_absconv : Re s >= 1 + delta ->
  DS_absconv (fun n => cmul (Lambda_n n) (cpow n (cneg s)))
    /\ cle (cmod (logderiv_neg_zeta s)) (cadd (cinv (cofR delta)) (cofR C1_slot)).
Variable C1_slot : Q.   (* 显式 C₁·cert 字面·GAPASUME 槽 *)
End Z01_Series.
(* cert：ΣΛ(n)n^{−σ} 截断＋余项 Q 证书（vm_compute·lcmpow 核算·D1-B3 消费） *)
```

### Z01-REPL 预演脚本
```coqtop
Require Import GaC3_Z01_LogDerivSeries.
Check (logderiv_neg_zeta_series : forall s, ...).
Check (logderiv_neg_zeta_absconv : forall s delta, ...).
Print Assumptions logderiv_neg_zeta_series.  (* 预期：GAPASUME 解析槽族（C2 Iface 消费） *)
```

### Z01-验收判据
1. 四关＋LINT 过；cert 截断证书绿；Λ(n) 承载命中 D1-B3 lcmpow（消费位普查=1）。
2. cards ④「需突破」维持（树内 ζ/Dirichlet 级数词面零施工·重估 :34-35 实勘）·席时带 5.5-6.5。

---

## C3-Z02 · 三余弦不等式〔W1·deps=[]〕

### Z02-研读卡（先例件：ZZ `cos_inequality_1`·覆盖度**逐字同构**·系数 0.40）
- **先例语句面**（本席实读 :9-23 全证）：`cos_inequality_1 (x : real) : 3 + 4 * cos x + cos (2 * x) ≥ 0`——证明路线：cos_double→sin_squared_eq→2(1+cos x)²≥0——**与 cards_C3-Z02 ① 命题词面同构·与本席复算恒等式一致**。
- **逐引理映射**：树内三角承载＝rs_add_cos 系（S10_KVQuantTrig·KB36R :106 在树）＋实平方非负——**倍角面 cos 2u**（cards ②「三角代数延拓」）为唯一自铸位；等号面（cos u=−1 ⇔）需 2π 周期归约＝KB36R :149 诚实断点——**全链只需不等号→缩面**（cards ② 缩面注记执行位：语句面只铸不等号·等号面禁入·Z03 竞速仅消费不等号）。
- **吸收清单**：①倍角恒等式→平方和路线（AFP 同构）；②非负性构造形状（0 ≤ 2(1+cos u)²）。

### Z02-语句面稿（GaC3_Z02_ThreeCosine.v）
```coq
(* GaC3_Z02_ThreeCosine.v —— C3-Z02·W1·deps=[]（L0：S10_KVQuantTrig rs 三角面） *)
Lemma cos_double_rs : forall u:ℝ, rs_cos (2*u) = rs_sub (rs_mul 2 (rs_sq (rs_cos u))) 1.  (* 倍角延拓·自铸位 *)
Theorem three_cosine_nonneg : forall u:ℝ,
  rs_le 0 (rs_add 3 (rs_add (rs_mul 4 (rs_cos u)) (rs_cos (2*u)))).
Proof. (* 路线：cos_double_rs → 2·(1+cos u)² 非负·平方非负承载=树 real 线 *)
(* ◇ 证明体施工位·路线已在研读卡（AFP :9-23 同构） *)
```

### Z02-REPL 预演脚本
```coqtop
Require Import GaC3_Z02_ThreeCosine.
Check (three_cosine_nonneg : forall u, rs_le 0 (...)).
Compute (rs_sq (rs_cos 0)).   (* 冒烟·秒级·值=1 形 *)
```

### Z02-验收判据
1. 四关＋LINT 过；**等号面/2π 周期词面=0**（缩面执行位·grep 判据）；倍角引理在案。
2. cards ④「可及」·席时带 1.5-2.5（B6/B7 直用）·最小件。

---

## C3-Z03 · ζ(1+it) ≠ 0（非零线·定量版）〔W2·deps=[Z01,Z02]〕

### Z03-研读卡（先例件：ZZ 主链＋mathlib＋strongpnt 三线·覆盖度全·系数 0.40）
- **先例语句面**：ZZ `logderiv_zeta_ineq` :136-163（3Re(−ζ'/ζ(σ))+4Re(−ζ'/ζ(σ+it))+Re(−ζ'/ζ(σ+2it)) ≤ 0·σ>1·**级数逐项+三余弦非负的 has_sum 架构**——Z01+Z02 的消费正本）；mathlib `riemannZeta_ne_zero_of_one_le_re` :417（1≤Re s ⇒ ζ≠0——**结论级先例·非定量**）；strongpnt `ZetaNoZerosOn1Line'` :35（ζ(1+tI)≠0·**存在型结论·无显式矛盾半径**）。
- **逐引理映射**：树内竞速骨架（cards ①）：ζ(1+it₀)=0（m 重）→−Re ζ'/ζ(σ+it₀)=−m/(σ−1)+O(ln τ)→令 σ→1⁺ 矛盾——**零点邻域主部局部刻画＝自铸最深位**（复可微+零点因子分解·PNT_Complex_Analysis_Lemmas `analytic_factorization` :288 为解析域机器对表锚·本席实读语句表）；σ→1⁺ 竞速的构造性化（极限论证→显式矛盾半径·cards ③）→**定量版＝显式矛盾半径槽形**（先例三线皆无此面→品质差首例位·映射表 §④-1 条件②联动）。
- **吸收清单**：①logderiv_zeta_ineq 架构（Z01/Z02 装配形）；②「结论级存在→显式半径」的构造性化义务（禁照抄存在型·strongpnt 品质对照锚在案）。

### Z03-语句面稿（GaC3_Z03_NonzeroLine.v）
```coq
(* GaC3_Z03_NonzeroLine.v —— C3-Z03·W2·deps=[C3-Z01,C3-Z02]·跨段：GaC2_Iface_Eta（C2.3 ζ 延拓） *)
Section Z03_Nonzero.
Variable t : ℝ.
Theorem zeta_nonzero_line : t <> 0 -> zeta_carrier (cmk 1 t) <> c0.
Theorem zeta_nonzero_line_quant : t <> 0 ->
  exists rho : Q, 0 < rho /\   (* 显式矛盾半径·cert 字面·先例三线无·品质差位 *)
    (cabs (zeta_carrier (cmk 1 t)) < rho -> False).  (* 形：非零性定量承载·bool/hl 证书位 *)
End Z03_Nonzero.
```

### Z03-REPL 预演脚本
```coqtop
Require Import GaC3_Z03_NonzeroLine.
Check (zeta_nonzero_line : forall t, ...).
Check (zeta_nonzero_line_quant : forall t, ...).
```

### Z03-验收判据
1. 四关＋LINT 过；定量版半径 cert 字面绿；**存在型语句禁单铸**（三线品质对照·显式半径义务·判据点名）。
2. cards ④「需突破」维持·席时带 6-8·KB36R 新地形溢价带内。

---

## C3-Z04 · ζ 主部展开（ζ(s)=1/(s−1)+O_B(1) 显式常数化）〔W3·deps=[Z03]〕

### Z04-研读卡（先例件：ZZ 界件族·覆盖度全·系数 0.35）
- **先例语句面**（本席实读 :197-268）：`zeta_bound'` :197-211（1<Re s ⇒ \|ζ(s)\| ≤ Re ζ(Re s)——级数三角不等式直给）；`zeta_bound_trivial'` :212-215（**1/2≤Re s≤2 ∧ \|Im s\|≥1/11 ⇒ \|ζ(s)\| ≤ 12+2\|Im s\|——带状显式界**）；`zeta_bound_gt_1` :244／`zeta_bound_trivial` :268。
- **逐引理映射**：cards ① 目标形 |ζ(s)−1/(s−1)|≤B（条带 1/2≤σ≤2·\|t\|≤T）——先例给 \|ζ(s)\| 界（未减主部）→**减主部差=自铸位**（1/(s−1) 极点承载·cdiv 代数）；\|ζ′(s)+1/(s−1)²\|≤B′ 推论——P05 cauchy_deriv_bound_k 消费或直接法（cards ②）；O 常数化逐常数核算（Dusart 2010 附录型·cards ③）→B/B₂ 全落 cert。
- **吸收清单**：①zeta_bound_trivial′ 的显式常数纪律（12+2\|Im s\|·1/11 窗——树内 B 值核算的竞速对手形）；②带状界→主部差的路线。

### Z04-语句面稿（GaC3_Z04_ZetaMainPart.v＋cert）
```coq
(* GaC3_Z04_ZetaMainPart.v —— C3-Z04·W3·deps=[C3-Z03]·跨段：GaC2_Iface_VL（C2.4 竖线界）·GaC2_Iface_Eta *)
Section Z04_Main.
Variables B B2 : Q.   (* 显式·cert 字面·GAPASUME 槽 *)
Theorem zeta_main_part : forall s, in_strip 1/2 2 s -> cabs (csub (zeta_carrier s) (cinv (csub s c1))) <= QtoR B.
Theorem zeta_deriv_main_part : forall s, in_strip 1/2 2 s ->
  cabs (cadd (zeta_deriv s) (cinv (csq (csub s c1)))) <= QtoR B2.
Corollary logderiv_neg_zeta_main : forall s, in_strip 1/2 2 s -> Re s <> 1 ->
  cabs (csub (logderiv_neg_zeta s) (cinv (csub s c1))) <= QtoR B2'.  (* −ζ'/ζ=1/(s−1)+O_B₂(1)·cards ① *)
End Z04_Main.
```

### Z04-REPL 预演脚本
```coqtop
Require Import GaC3_Z04_ZetaMainPart.
Check (zeta_main_part : forall s, ...).
Check (logderiv_neg_zeta_main : forall s, ...).
Check (B : Q). Check (B2 : Q). Check (B2' : Q).
```

### Z04-验收判据
1. 四关＋LINT 过；B/B₂/B₂′ cert 绿；主部差形状（减 1/(s−1)）在案。
2. 席时带 5-7；P06（Res=1 证书）与 Z05/Z06 消费位普查 ≥3。

---

## C3-Z05 · dVp 零点自由区主定理（显式常数）〔W4·deps=[Z01,Z02,Z03,Z04]〕

### Z05-研读卡（先例件：ZZ 主定理·覆盖度全·系数 0.40——本块重心件）
- **先例语句面**（本席实读 :661-891）：`zeta_nonzero_region′` :661→`zeta_nonzero_region`（θ/φ 形）:728-777（1−β ≥ 1/29760·θ(2\|γ\|+1)/φ(2\|γ\|+1)·含 \|γ\|<13/22 小窗分域）→**`zeta_nonzero_region`（ln 终形）:872-891**：`1 − β ≥ C₁ / ln(\|γ\|+2)`·C₁=1/952320（PNT_const_C₁_def unfold :890）·:874-882 常数换算链（1/952320 ≤ 1/29760·(1/2)/(4 ln(12+2\|γ\|+1))·经 ln(14+4\|γ\|) ≤ 4ln(\|γ\|+2) `ln_bound_1`）。
- **逐引理映射**：cards ① 目标形 σ ≥ 1−1/(R·ln τ)·τ=max(\|t\|,τ₀)——**先例 τ 形＝ln(\|γ\|+2)（无 τ₀ 下界）→树内 τ=max 形的整编位**（Z09 闭合联动·cards ②「连带统一参数化」）；三余弦加权竞速（(1−σ)³ 加权·dVp 1899 原法·cards ②）——ZZ 的竞速机器在 `lemma_3_9_beta1/2/3` :518/:621/:763＋`zeta_bound_param_nonneg` :778（**方法学对表·不全读·317KB PNT4 同判**）；**显式 R 值选定待勘**（cards ①·Ford 5.5666307/Mossinghoff–Trudgian 5.573412/Kadiri 4.56383 候选——R4 fetch-before-cite 义务留施工席·本席禁猜）；bool/hl 证书承载（Set 消费形·cards ①）。
- **吸收清单**：①ln 终形语句形状（1−β ≥ C₁/ln(\|γ\|+2)）；②常数换算链架构（粗常数→细常数的 ≤ 链）；③小窗分域结构（\|γ\|<13/22 → Z09 联动）。

### Z05-语句面稿（GaC3_Z05_ZFRMain.v＋cert）
```coq
(* GaC3_Z05_ZFRMain.v —— C3-Z05·W4·deps=[C3-Z01,C3-Z02,C3-Z03,C3-Z04] *)
Section Z05_ZFR.
Variables R_zfr tau0 : Q.   (* GAPASUME 槽·显式 R 值 cert 字面·候选值 R4 义务（禁本席代选） *)
Definition tau (t : ℝ) : ℝ := Rmax (Rabs t) (QtoR tau0).

Theorem dvp_zfr_main : forall t sigma,
  sigma >= 1 - 1/(QtoR R_zfr * ln (tau t)) -> zeta_carrier (cmk sigma t) <> c0.

(* Set 消费形：非零性 bool/hl 证书承载（cards ①） *)
Definition zfr_bool (t : ℝ) (sigma : ℝ) : bool := ...
Corollary zfr_hl : forall t sigma, ... -> hl_of_bool (zfr_bool t sigma) = true.

(* 常数换算链（AFP :874-882 架构转录） *)
Lemma zfr_const_chain : QleT (Qinv (Qmul tau0' 4)) ... .  (* cert 面·vm_compute *)
End Z05_ZFR.
```

### Z05-REPL 预演脚本
```coqtop
Require Import GaC3_Z05_ZFRMain.
Check (dvp_zfr_main : forall t sigma, ...).
Check (zfr_hl : forall t sigma, ...).
Check (R_zfr : Q). Check (tau0 : Q).
Print Assumptions dvp_zfr_main.   (* 预期：R_zfr/tau0 Section 槽（Z10 放电前） *)
```

### Z05-验收判据
1. 四关＋LINT 过；R/τ₀ cert 字面绿＋**R 值文献坐标 fetch-before-cite 义务**（施工席三候选实 fetch 后定谳·本席登记候选禁猜）；τ=max 形整编在案。
2. 席时带 6-8；Z06/Z07/Z08/Z10/P10/V06 消费位普查 ≥5——**C3 段最大扇出件·扇入帽 LINT-4 核查位**。

---

## C3-Z06 · 零点自由区内 −ζ'/ζ 增长界（log² 型）〔W6·deps=[P05,Z04,Z05]〕

### Z06-研读卡（先例件：ZZ 界件＋strongpnt 品质对照·覆盖度全·系数 0.35）
- **先例语句面**（本席实读）：ZZ `deriv_zeta_bound` :355-358（\|ζ′(s)\| ≤ B/r＋1/\|s−1\|²·圆周界 B 输入形——**Cauchy 导数不等式消费形**）；`logderiv_zeta_bound` :409-411（5/4·1/(σ−1)·1<σ≤23/20）＋:618-660（region 形重载）＋`Re_logderiv_zeta_bound` :486-489（Re ≥ −5/4/(σ−1)——**Z03 竞速的定量输入**）；strongpnt `LogDerivZetaHolcLargeT'` :242-262（∃A∈Ioc(0,1/2)·∀T≥3·HolomorphicOn ζ'/ζ 于 ((1−A/log T)×[−T,T])∖{1}——**存在型·品质对照锚：树内必须显式 C₄ 禁存在型**）。
- **逐引理映射**：cards ① 目标 \|−ζ'/ζ\|≤C₄ ln²τ（σ≥1−1/(R ln τ) 分域：邻域内主部（Z04 B₂）/邻域外级数（Z01））——ZZ 邻域形（5/4/(σ−1)）+外域形未单列→**分域装配自铸·骨架同 Z06 cards ③**；B–C 消费位（C2.4 经 GaC2_Iface_VL·P05 双路 cards ②「归属待勘」——**本稿裁定取 P05 直路**（ZZ deriv_zeta_bound 即 Cauchy 消费形·P05 绿后转录）·备选直接法登记）。
- **吸收清单**：①deriv_zeta_bound 三参形状（r/B/1/\|s−1\|²）；②5/4·23/20 邻域常数纪律；③「存在型→显式型」品质义务（strongpnt 对照·映射表 §④-1 条件②同源）。

### Z06-语句面稿（GaC3_Z06_LogDerivBound.v＋cert）
```coq
(* GaC3_Z06_LogDerivBound.v —— C3-Z06·W6·deps=[C3-P05,C3-Z04,C3-Z05]·跨段：GaC2_Iface_VL *)
Section Z06_Bound.
Variables C3' C4 : Q.   (* 显式·cert 字面·GAPASUME 槽 *)
Theorem logderiv_neg_zeta_zfr_bound : forall t sigma,
  in_zfr_region (QtoR R_zfr) (QtoR tau0) t sigma ->
  cle (cmod (logderiv_neg_zeta (cmk sigma t))) (QtoR C4 * (ln (tau t))^2).
Theorem zeta_deriv_zfr_bound : forall t sigma, in_zfr_region ... ->
  cle (cmod (zeta_deriv (cmk sigma t))) (QtoR C3' * (ln (tau t))^b).  (* b∈{2,3}·双档 *)
(* 分域引理：邻域（Z04 主部）⊕外域（Z01 级数）→ 全域合取 *)
Lemma domain_split_logderiv : ... .
End Z06_Bound.
```

### Z06-REPL 预演脚本
```coqtop
Require Import GaC3_Z06_LogDerivBound.
Check (logderiv_neg_zeta_zfr_bound : forall t sigma, ...).
Check (zeta_deriv_zfr_bound : forall t sigma, ...).
Check (domain_split_logderiv : ...).
```

### Z06-验收判据
1. 四关＋LINT 过；C₃′/C₄ cert 绿；**存在型词面禁入**（∃C grep=0·品质义务判据）。
2. 席时带 5-7；P09/P11/V05 消费位普查 ≥3。

---

## C3-Z07 · log ζ 单值解析分支（零点自由+非极域）〔W5·deps=[P04,Z05]〕

### Z07-研读卡（先例件：PNT_Complex_Analysis_Lemmas＋ZZ region 机器·覆盖度全·系数 0.40）
- **先例语句面**（本席实读）：PNT_Complex_Analysis_Lemmas `holomorphic_logderiv` :20-24（ζ'/ζ 全纯性引理·holomorphic_intros 标注）＋`analytic_factorization` :288-309（解析函数零点因子分解·解析域机器）＋ZZ `cball_lm` :533／`cball_in_region` :552／`Re_s_gt_1` :575／`zeta_analytic_on_region` :582（region 上 ζ 解析——region 定义机器的正形）。
- **逐引理映射**：cards ① 构造性路线 g(z)=∫_{z₀}^z ζ'/ζ dξ＋log ζ(z₀)（经 P04 路径无关）——先例无独立 log-branch 件（隐于 ZZ 主定理证明内）→**路线吸收·本体自铸**（P04 primitive_exists 推论直接消费）；基点与分支规范化（cards ③）→z₀ 固定槽形。
- **吸收清单**：①region 谓词机器（cball/region 定义形状）；②「域内无零点+解析→ζ'/ζ 原函数存在」推理链形状。

### Z07-语句面稿（GaC3_Z07_AnalyticLog.v）
```coq
(* GaC3_Z07_AnalyticLog.v —— C3-Z07·W5·deps=[C3-P04,C3-Z05] *)
Section Z07_Log.
Variable z0 : ℂ.   (* 基点槽·分支规范化 *)
Theorem analytic_log_exists : z0 ∈ zfr_region \ {1} ->
  exists g : ℂ -> ℂ, AnalyticOn g zfr_region \ {1}
    /\ (forall z, In (zfr_region \ {1}) z -> cexp (g z) = zeta_carrier z)
    /\ g z0 = clog_spec (zeta_carrier z0).
End Z07_Log.
```

### Z07-REPL 预演脚本
```coqtop
Require Import GaC3_Z07_AnalyticLog.
Check (analytic_log_exists : ...).
```

### Z07-验收判据
1. 四关＋LINT 过；e^g=ζ 逐点式在案；基点槽形在案。
2. 席时带 4-6；**γ3 内部 DAG 交叉点**（cards ④·P 链未绿则阻塞——P04 W4→Z07 W5 波序已保安全·登记）；V04/Z08 消费位普查 ≥2。

---

## C3-Z08 · 1/ζ 在零点自由区的有效界〔W7·deps=[Z05,Z06,Z07]〕

### Z08-研读卡（先例件：ZZ 逆元界件·覆盖度全·系数 0.40）
- **先例语句面**（本席实读 :180-195/:343-395）：`inverse_zeta_bound′` :180-195（1<Re s ⇒ \|1/ζ(s)\| ≤ Re ζ(Re s)——**Möbius μ 级数路线**：inverse_zeta_sums+suminf_norm_bound）；`inverse_zeta_bound` :343＋`zeta_lower_bound` :396-408（ζ 下界·1/ζ 上界的另一路）。
- **逐引理映射**：cards ① σ≥1+1/ln τ：\|1/ζ\|≤ζ(σ)≤ln τ+C₅——先例 Möbius 路线→树内 μ 承载位（**树内 μ(n) 无 GREEN 承载→此路全价**·cards ② 未列 μ 件·缺口登记）；备选路＝ζ′·(1/ζ) 分解（cards ①·Z06/Z07 消费）——**本稿裁定主路取分解路**（μ 承载缺口避让·Möbius 路登记为备选·若分解路常数竞速失败回切）·fail-loud 双路登记。
- **吸收清单**：①zeta_lower_bound 形状（下界→上界倒换）；②C₅/C₆ 证书纪律。

### Z08-语句面稿（GaC3_Z08_InvZetaBound.v＋cert）
```coq
(* GaC3_Z08_InvZetaBound.v —— C3-Z08·W7·deps=[C3-Z05,C3-Z06,C3-Z07] *)
Section Z08_Inv.
Variables C5 C6 : Q.  Variable b : Q.
Theorem inv_zeta_right : forall t sigma, sigma >= 1 + 1/(ln (tau t)) ->
  cle (cmod (cinv (zeta_carrier (cmk sigma t)))) (cadd (ln (tau t)) (QtoR C5)).
Theorem inv_zeta_zfr : forall t sigma, in_zfr_region (QtoR R_zfr) (QtoR tau0) t sigma ->
  cle (cmod (cinv (zeta_carrier (cmk sigma t)))) (QtoR C6 * (ln (tau t))^b).
(* 主路=ζ′·(1/ζ) 分解（Z06/Z07 消费）·备选=Möbius（ZZ :180 路线·μ 承载缺口·回切登记） *)
End Z08_Inv.
```

### Z08-REPL 预演脚本
```coqtop
Require Import GaC3_Z08_InvZetaBound.
Check (inv_zeta_right : ...).
Check (inv_zeta_zfr : ...).
```

### Z08-验收判据
1. 四关＋LINT 过；C₅/C₆ cert 绿；双路登记在案（主路/备选 fail-loud）。
2. 席时带 4-6；P11/V05/θ 下界侧消费位普查 ≥2。

---

## C3-Z09 · 小 \|t\| 段与 τ₀ 有限窗显式核查〔W4·deps=[Z04]〕

### Z09-研读卡（先例件：ZZ small-imag 件·覆盖度全·系数 0.50——显式常数最密件）
- **先例语句面**（本席实读 :283-342）：`zeta_nonzero_small_imag′` :283-326（\|Im s\|≤**13/22** ∧ Re s≥1/2 ∧ Re s<1 ⇒ ζ(s)≠0——证明内显式常数链 \|s\|/Re s≤**79/50**·pre_zeta 界≤**129/100**）；`zeta_nonzero_small_imag` :327-342（Re s>0 ∧ s≠1 全段闭合：Re s≤1/2 用 zeta_zero_reflect_iff 对称·1/2≤Re s<1 用 ′ 件·Re s≥1 用 zeta_Re_ge_1_nonzero）——**小窗主定理 :748 的 \|γ\|<13/22 分域消费位（本席实读 :758-765 直接调用）**。
- **逐引理映射**：cards ① 目标＝\|t\|≤τ₀ 段无零点/有界性 Q 区间证书（vm_compute 全值核算）——**复数值区间求值器树内为零**（cards ② 缺口登记·S03_QExp 是 nat/Q 整幂证书机）→区间器新铸面（待勘档根源）；先例的「pre_zeta 级数部分和显式界」路线（129/100 链）为区间器的数学路线正本（**区间算术可用显式级数尾界替代·先例即此路线·非黑盒区间算术**——本研读卡勘形修正：cards ②「区间求值器」预期收窄为「级数尾界证书器」·量级降）。
- **吸收清单**：①13/22 窗形状＋三分闭合结构；②pre_zeta 部分和显式界路线（79/50·129/100 常数链纪律）；③τ=max(\|t\|,τ₀) 统一参数化整编位。

### Z09-语句面稿（GaC3_Z09_SmallTWindow.v＋cert）
```coq
(* GaC3_Z09_SmallTWindow.v —— C3-Z09·W4·deps=[C3-Z04]·跨段：GaC2_Iface_Eta（C2.3 数值求值面）·L0：S03_QExp *)
Section Z09_Small.
Variable tau0 : Q.
Theorem zeta_nonzero_small_t : forall t sigma, cabs t <= QtoR tau0 -> sigma > 0 ->
  (cmk sigma t) <> c1 -> zeta_carrier (cmk sigma t) <> c0.
Theorem zeta_bound_small_t : forall t sigma, cabs t <= QtoR tau0 -> 1/2 <= sigma <= 2 ->
  cle (cmod (zeta_carrier (cmk sigma t))) (bound_small_t_cert t sigma).  (* cert 显式界函数 *)
(* 统一参数化整编：Z05 等 τ=max(|t|,τ₀) 的 τ₀ 段闭合（cards ②） *)
Lemma tau_param_closes : forall t, tau (t) = tau0' when cabs t <= tau0'.  (* 形注 *)
End Z09_Small.
(* cert：τ₀ 窗级数尾界 Q 证书族（vm_compute·KB72 工艺·复区间器=级数尾界替代·研读卡勘形修正） *)
```

### Z09-REPL 预演脚本
```coqtop
Require Import GaC3_Z09_SmallTWindow.
Check (zeta_nonzero_small_t : ...).
Check (zeta_bound_small_t : ...).
Check (tau0 : Q).
```

### Z09-验收判据
1. 四关＋LINT 过；τ₀ 窗证书族绿；三分闭合结构（≤1/2·[1/2,1)·≥1）在案。
2. **cards ④「待勘」→ 本四稿勘形收窄**：区间器缺口以先例级数尾界路线替代·待勘面收敛为「尾界证书器工时」·席时带 4-8 维持（禁降档·待勘带不因收窄下调）·施工席复勘确认。

---

## C3-Z10 · dVp 链常数一致化与 ZFR 陈述层终装〔W8·deps=[Z05,Z06,Z08,Z09]〕

### Z10-研读卡（先例件：ZZ 常数换算链＋树内证书工艺·覆盖度全（工艺）·系数 0.50）
- **先例语句面**（本席实读 :872-891）：终形链 `theorem zeta_nonzero_region (β γ) : 1−β ≥ C₁/ln(\|γ\|+2)`·证明＝三级 ≤ 链（1/952320·1/ln(\|γ\|+2) ≤ 1/238080/(4ln(\|γ\|+2)) ≤ 1/238080/(ln(14+4\|γ\|)) ≤ 1−β）＋`PNT_const_C₁_def` unfold——**「粗常数→细常数→消费常数」的一致化链正形**；θ/φ 中间形 :748 与 ln 终形 :872 的双陈述共存（同一 theory 两层终装）。
- **逐引理映射**：cards ① 打包定理（∃ R,τ₀,C₃,C₄,C₅,B,B₂ 证书族·全链同源一致·GAPASUME 槽形输出）——树内工艺＝R2 正形（字面证书+验收器·zzPhi 判例·规范 §4.2）·KB72 vm_compute 折价；常量依赖图理清（cards ③·接口档）。
- **吸收清单**：①三级常数链架构；②双陈述层（内部竞速形/外部消费形）分离纪律（→Z05 内形/Z10 消费形）。

### Z10-语句面稿（GaC3_Z10_ConstUnify.v＋cert）
```coq
(* GaC3_Z10_ConstUnify.v —— C3-Z10·W8·deps=[C3-Z05,C3-Z06,C3-Z08,C3-Z09] *)
Section Z10_Unify.
(* 打包槽族（GAPASUME 输出形·P 链/C4 消费） *)
Record ZFR_Const_Pack : Type := mk_zfr_pack {
  pack_R : Q; pack_tau0 : Q; pack_C3 : Q; pack_C4 : Q;
  pack_C5 : Q; pack_B : Q; pack_B2 : Q }.

Theorem zfr_pack_consistent : forall p, pack_wf p ->
  (forall t sigma, ...) /\ (forall t sigma, ...) .  (* Z05∧Z06∧Z08∧Z09∧Z04 全链同源合取 *)
End Z10_Unify.
(* cert：pack 字面族 vm_compute 全值核算＋验收器（R2 正形）——本件 cert 面为主·证明面=接口档 *)
```

### Z10-REPL 预演脚本
```coqtop
Require Import GaC3_Z10_ConstUnify.
Check (mk_zfr_pack : Q -> Q -> Q -> Q -> Q -> Q -> Q -> ZFR_Const_Pack).
Check (zfr_pack_consistent : forall p, ...).
Print Assumptions zfr_pack_consistent.  (* 预期：Closed（消费全段 GREEN 件后） *)
```

### Z10-验收判据
1. 四关＋LINT 过；pack 七常数 cert 绿＋验收器绿；LINT-5 cert 面命中 ≥1（有计算面声明位）。
2. 席时带 2-4（KB72 折价带）；P10/V06/C4.3 消费位普查 ≥3。

---

# ⑤ · 维持簇 · 零点自由区 VK 核 6（从零四稿·V01-V06）

> 全景卡底册编号＝cards_C3 第三块（全景卡 :822-880）。**维持判词（映射表 §② 原文）**：C3.2 VK 层 18 节点「维持·查无·从零价不变——四库扫空（expdb＝数据库非 ITP 库·lean-bombieri-vinogradov＝蓝图两公理缺口自认·OpenAI quasi-RH＝稿件明言未形式化）·勘形悲观档不变·判词『需突破档』不因翻转整体降档」。本席辖核心 6（V01-V06）·**维持簇无先例可读→四稿第一稿＝数学命题卡·无研读卡·本席零 fetch（无对象）**。cards ⑦ 检索词全部留作闸 1 复检输入（dwfrun 靶标·复审条件随判据）。
> **跳过登记（裁 1）**：VK 残 12（V07-V18）＝γ4/C4 段辖·预留槽与初排依赖见规范 §3.5（W7-W11 波·V07←V03 等结构边系初排非勘形断言）——本席零四稿。

---

## C3-V01 · van der Corput 指数和第 2 阶估计（A-过程）〔W4·deps=[P01,P02,P03]〕

### V01-数学命题卡（从零·世界首例主阵地件）
- **命题**（cards ① 全录）：f∈C²([N,2N])、\|f″\|≍λ₂（双向显式常数）⇒ \|Σ_{N<n≤2N} e(f(n))\| ≤ C_vdc·(N·λ₂^{1/2}＋λ₂^{−1/2})·e(x)=e^{2πix}·**C_vdc 显式**；k 阶一般形列为残档（禁入语句面·降面注记：残档归 γ4 W1/W3 槽）。
- **构造性义务**：e(f(n)) 承载＝born c_exp（e^{2πi·f(n)}·**2π 周期归约断点消费位**——C1.4 残件·cards ②）；文献路线 Graham–Kolesnik/Iwaniec–Kowalski Ch.8（cards ② 文献坐标·R4 义务留施工席）——**A-过程证明含积分算子面（P01-P03 消费）+逐显式常数**（cards ③·深新地形）。
- **R6 三档**：需突破（cards ④·ITP 零先例·KB34 检索台账 #1）·**复审条件**：任何 ITP 出现 exponent pair/vdC 形式化→本件及 V 层全折价（W-3 复审②·闸 1 靶标）。
- **消费位**：V02（W5）/V03（W6）Require 命中 ≥2。

### V01-语句面稿（GaC3_V01_VdCSecond.v＋cert）
```coq
(* GaC3_V01_VdCSecond.v —— C3-V01·W4·deps=[C3-P01,C3-P02,C3-P03]·跨段：GaC1_Iface_Real *)
Section V01_VdC.
Variable C_vdc : Q.   (* 显式·cert 字面·GAPASUME 槽 *)
Variables N lam2 : Q.  Variable f : ℝ -> ℝ.   (* 相位·实值 C²·树 real 线 *)

Definition exp_sum (f : ℝ -> ℝ) (N : Q) : ℂ :=   (* Σ_{N<n≤2N} e(f(n))·e(x)=cexp(2πi·x)·born c_exp 承载 *)
  finsum (fun n => cexp (cmul (cofR (2*PI) ci) (cofR (f (Z.of_nat n))))).

Theorem vdc_second_derivative_test :
  (forall x, N <= x <= 2*N -> cle (QtoR lam2 / 2) (absR (f'' x)))
  -> (forall x, N <= x <= 2*N -> cle (absR (f'' x)) (QtoR lam2 * 2)) ->
  cle (cmod (exp_sum f N))
      (QtoR C_vdc * (cadd (QtoR N * rsqrt (QtoR lam2)) (rsqrt (Qinv (QtoR lam2))))).
(* A-过程证明拓扑：van der Corput 二阶检验逐显式常数·P03 ML 消费·2π 周期位槽登记 *)
End V01_VdC.
```

### V01-REPL 预演脚本
```coqtop
Require Import GaC3_V01_VdCSecond.
Check (vdc_second_derivative_test : ...).
Check (exp_sum : (ℝ -> ℝ) -> Q -> ℂ).
```

### V01-验收判据
1. 四关＋LINT 过；C_vdc cert 字面绿；k 阶泛化词面=0（降面判据）。
2. 席时带 8-10（新地形溢价上限带·cards ⑥）；复审条件在案·**禁降档**。

---

## C3-V02 · B-过程（完成法/泊松核）〔W5·deps=[P01,P03,V01]〕

### V02-数学命题卡（从零·最大依赖缺口件）
- **命题**（cards ① 全录）：光滑幅度 g、相位 f：Σ_{n∈[N,2N]} g(n)e(f(n)) ＝ Σ_m ∫ g(x)e(f(x)−mx) dx ＋ 余项（截断核 sin(πy)/(πy)·Srinivasan–vdC B-过程形·**余项显式常数**）。
- **构造性义务**：傅里叶变换理论树内为零（cards ② **最大依赖缺口登记**）——截断核积分表示＋余项常数＝复+实傅里叶双层新铸（cards ③）；mathlib PoissonSummation 在库与否 cards 标 R4 验证——**本席未 fetch 验证（维持簇无先例对象·验证义务留闸 1/施工席·fail-loud 登记不代裁）**；替代路线：B-过程若可被 A-过程迭代替代（文献有此路·cards ④ 复审条件）→降本重估位。
- **R6 三档**：需突破（cards ④）·复审条件：mathlib/CoRN 傅里叶实况（R4）；A-迭代替代路线确认→降本重估。

### V02-语句面稿（GaC3_V02_BProcess.v）
```coq
(* GaC3_V02_BProcess.v —— C3-V02·W5·deps=[C3-P01,C3-P03,C3-V01]·跨段：GaC1_Iface_Cx（C1.4 一致收敛） *)
Section V02_B.
Variable Rrem : Q.   (* 余项显式常数·cert·GAPASUME 槽 *)
Variables N : Q.  Variables g : ℝ -> ℝ.  Variable f : ℝ -> ℝ.

Definition trunc_kernel (y : ℝ) : ℝ := (* sin(πy)/(πy)·y=0 处构造性延拓=1 *)
  ... .
Theorem b_process_completion :
  smooth_decay g -> (forall x, N <= x <= 2*N -> cle (absR (f' x)) 1/2) ->
  exists E : ℂ, cmod E <= QtoR Rrem /\   (* 余项显式 *)
  exp_sum_weighted g f N = cadd (dual_sum g f N) E.   (* Σ_m ∫ g(x)e(f(x)−mx) dx·积分算子 P01-P03 消费 *)
End V02_B.
```

### V02-REPL 预演脚本
```coqtop
Require Import GaC3_V02_BProcess.
Check (b_process_completion : ...).
Check (trunc_kernel : ℝ -> ℝ).
```

### V02-验收判据
1. 四关＋LINT 过；Rrem cert 绿；截断核 y=0 延拓位在案（构造性纪律）。
2. 席时带 8-12；**傅里叶缺口复勘义务**（闸 1 mathlib PoissonSummation 实检·cards ④）登记。

---

## C3-V03 · ζ 与 ζ' 在 1-线附近的 Vinogradov 型界〔W6·deps=[V01,V02,Z01]〕

### V03-数学命题卡（从零·待勘档·跨段归属登记件）
- **命题**（cards ① 全录）：\|ζ(1+it)\| ≤ C_V·(ln τ)^{2/3}(ln ln τ)^{1/3}；\|ζ′(1+it)\| ≤ C′_V·(ln τ)^{4/3}(ln ln τ)^{1/3} 型（**C_V/C′_V 显式**·文献坐标 Vinogradov 1958/Korobov 1958/Karatsuba–Korobov 1963·最佳显式值待勘·R4 复核）——V04 竞速直接弹药。
- **构造性义务**：vdC 消费的 ζ 界逐常数化（部分和→部分求和→1-线·cards ③ 中等深新地形）；**跨段依赖边界待勘**（近似函数方程归属——cards ②「归属 C2 竖线 8 节点或本块残档·待 γ0 结构规范冻结裁定」——**规范 §3.4 定谳：本件 deps=[V01,V02,Z01]·近似函数方程不在 γ3 边集→归属 γ4/未辖·本稿按最坏情形从零预列·禁降档**）。
- **R6 三档**：待勘（cards ④·跨段归属未定）→**规范冻结后从零预列**·按需突破档预算（cards ④ 原文）·席时带 6-9。

### V03-语句面稿（GaC3_V03_VinoZeta.v＋cert）
```coq
(* GaC3_V03_VinoZeta.v —— C3-V03·W6·deps=[C3-V01,C3-V02,C3-Z01] *)
Section V03_Vino.
Variables CV CV' : Q.   (* 显式·cert·GAPASUME 槽·待勘值 R4 义务 *)
Theorem zeta_1line_vino : forall t, t <> 0 ->
  cle (cmod (zeta_carrier (cmk 1 t)))
      (QtoR CV * (ln (tau t))^(2/3) * (ln (ln (tau t)))^(1/3)).
Theorem zeta_deriv_1line_vino : forall t, t <> 0 ->
  cle (cmod (zeta_deriv (cmk 1 t)))
      (QtoR CV' * (ln (tau t))^(4/3) * (ln (ln (tau t)))^(1/3)).
End V03_Vino.
```

### V03-REPL 预演脚本
```coqtop
Require Import GaC3_V03_VinoZeta.
Check (zeta_1line_vino : forall t, ...).
Check (zeta_deriv_1line_vino : forall t, ...).
```

### V03-验收判据
1. 四关＋LINT 过；C_V/C′_V cert 绿；**近似函数方程词面=0**（跨段边界判据·归属 γ4 登记）。
2. 席时带 6-9（待勘带·按需突破预列·禁降档）；V04/V05 消费位普查 ≥2。

---

## C3-V04 · VK 零点自由区主定理〔W7·deps=[V01,V02,V03,Z01,Z02,Z03,Z04,Z07]〕

### V04-数学命题卡（从零·C3 段最深证明面）
- **命题**（cards ① 全录）：ζ(σ+it) ≠ 0 对 σ ≥ 1−c₁/((ln τ)^{2/3}(ln ln τ)^{1/3})（**c₁ 显式**·文献坐标 Korobov 1958/Vinogradov/Karatsuba–Korobov 1963 原法·显式常数候选 Kadiri–Lumley 2018/Ford 2016 形——选定值待勘·R4 复核）。
- **构造性义务**：VK 法全链（指数和 V01+1-线界 V03+1−σ 竞速逐显式常数·cards ③）＝**C3 段最深证明面**；竞速骨架复用 Z05 同型换界函数 ln→L(τ)（cards ②）——**骨架复用=树内工艺先例（非外部先例·维持簇定性不变）**；Z07 log 分支消费（域内解析性）。
- **R6 三档**：需突破（cards ④·KB34 定价 18/8.0 周独层·**禁降档**）·复审条件：VK 形式化库出现（KB34:136 W-3②·闸 1 在飞 dwfrun-c480aacc 靶标）→全 DAG 重估。
- **消费位**：V05（W8）/P10（W8）/V06 消费·扇出 ≥3。

### V04-语句面稿（GaC3_V04_VKZFR.v＋cert）
```coq
(* GaC3_V04_VKZFR.v —— C3-V04·W7·deps=[C3-V01,C3-V02,C3-V03,C3-Z01,C3-Z02,C3-Z03,C3-Z04,C3-Z07] *)
Section V04_VK.
Variables c1_vk tau0 : Q.   (* 显式·cert·GAPASUME 槽·候选值 R4 义务 *)
Definition L_tau (t : ℝ) : ℝ := (ln (tau t))^(2/3) * (ln (ln (tau t)))^(1/3).  (* 界函数·换 Z05 的 1/ln 形 *)
Theorem vk_zfr_main : forall t sigma,
  sigma >= 1 - (QtoR c1_vk) / L_tau t -> zeta_carrier (cmk sigma t) <> c0.
(* 竞速骨架=Z05 同型（树内工艺复用）·弹药=V01 指数和+V03 1-线界·分支=Z07 *)
End V04_VK.
```

### V04-REPL 预演脚本
```coqtop
Require Import GaC3_V04_VKZFR.
Check (vk_zfr_main : forall t sigma, ...).
Check (L_tau : ℝ -> ℝ).
Print Assumptions vk_zfr_main.   (* 预期：c1_vk/tau0 槽（V06 终装前） *)
```

### V04-验收判据
1. 四关＋LINT 过；c₁/τ₀ cert 绿；c₁ 候选值 R4 fetch-before-cite 义务（Kadiri–Lumley/Ford 坐标施工席实 fetch·本席禁猜）。
2. 席时带 8-12；**复审条件与抢先窗口登记**（lean-bombieri-vinogradov/quasi-RH 在途·映射表 §④-1 威胁）·禁降档。

---

## C3-V05 · VK 区内 ζ'/ζ 与 1/ζ 界（log^{2/3} 型）〔W8·deps=[P05,V04,Z07]〕

### V05-数学命题卡（从零·转录-半新档）
- **命题**（cards ① 全录）：VK 区内 \|−ζ'/ζ(σ+it)\| ≤ C₈·(ln τ)^{2/3}(ln ln τ)^{1/3} 型；\|1/ζ(σ+it)\| ≤ C₇·(ln τ)^{2/3}(ln ln τ)^{4/3} 型（显式）——P09/P11 log³ 档左竖线消费件。
- **构造性义务**：B–C 手法在 VK 区的常数化＝Z06/Z08 骨架复用换界函数（cards ③·树内工艺先例）；P05 Cauchy 导数界消费（wave 表 deps=[P05,V04,Z07]·cards ⑤ 的 P05 交叉依赖在波表已解）；C₇/C₈ cert。
- **R6 三档**：需突破（cards ④·V04 绿后转录-半新·视 C2.4 成色）。

### V05-语句面稿（GaC3_V05_VKLogDeriv.v＋cert）
```coq
(* GaC3_V05_VKLogDeriv.v —— C3-V05·W8·deps=[C3-P05,C3-V04,C3-Z07] *)
Section V05_VK.
Variables C7 C8 : Q.
Theorem logderiv_neg_zeta_vk_bound : forall t sigma, in_vk_region (QtoR c1_vk) (QtoR tau0) t sigma ->
  cle (cmod (logderiv_neg_zeta (cmk sigma t))) (QtoR C8 * L_tau t).
Theorem inv_zeta_vk_bound : forall t sigma, in_vk_region (QtoR c1_vk) (QtoR tau0) t sigma ->
  cle (cmod (cinv (zeta_carrier (cmk sigma t)))) (QtoR C7 * L_tau t * (ln (ln (tau t)))).
(* 骨架=Z06/Z08 同型·界函数 1/ln→L(τ) 换装·P05 圆周导数界消费 *)
End V05_VK.
```

### V05-REPL 预演脚本
```coqtop
Require Import GaC3_V05_VKLogDeriv.
Check (logderiv_neg_zeta_vk_bound : ...).
Check (inv_zeta_vk_bound : ...).
```

### V05-验收判据
1. 四关＋LINT 过；C₇/C₈ cert 绿；骨架同型消费（Z06/Z08 Require 命中）在案。
2. 席时带 6-8；P09/P11/V06 消费位普查 ≥3。

---

## C3-V06 · ZFR 陈述层统一（dVp⊕VK 双档输出槽）〔W9·deps=[V04,V05,Z10]〕

### V06-数学命题卡（从零·工艺装配件）
- **命题**（cards ① 全录）：零点自由区统一槽：η(τ) 双档（dVp：1/(R ln τ)｜VK：c₁/L(τ)）输出为同一 GAPASUME 槽形语句（σ ≥ 1−η(τ) ⇒ 非零性+ζ'/ζ 界+1/ζ 界三合取·**证书族双套**）——消费方（P 链/C4）按档位取用＝KB34 降链案 α 的接口位。
- **构造性义务**：接口归一（小·cards ③）＋双套证书族 vm_compute（cards ③ 主体）；GAPASUME 工艺（tau_enclosure_base:1214 先例形·cards ②）。
- **R6 三档**：可及（cards ④·零新地形）·席时带 2-4。

### V06-语句面稿（GaC3_V06_ZFRSlot.v＋cert）
```coq
(* GaC3_V06_ZFRSlot.v —— C3-V06·W9·deps=[C3-V04,C3-V05,C3-Z10] *)
Section V06_Slot.
Inductive zfr_tier := dvp_tier | vk_tier.   (* 档位枚举·α 案接口位 *)
Theorem zfr_unified_slot : forall (tier : zfr_tier) t sigma,
  sigma >= 1 - eta_of tier (tau t) ->
  zeta_carrier (cmk sigma t) <> c0
  /\ (cmod (logderiv_neg_zeta (cmk sigma t)) <= bound_logderiv tier (tau t))
  /\ (cmod (cinv (zeta_carrier (cmk sigma t))) <= bound_invzeta tier (tau t)).
(* η_of/bound_* 双档分派：dvp→Z10 pack·vk→V04/V05 槽——消费方按档位取用 *)
End V06_Slot.
(* cert：双套证书族 vm_compute＋验收器 *)
```

### V06-REPL 预演脚本
```coqtop
Require Import GaC3_V06_ZFRSlot.
Check (zfr_unified_slot : forall tier t sigma, ...).
Check (dvp_tier : zfr_tier). Check (vk_tier : zfr_tier).
Print Assumptions zfr_unified_slot.  (* 预期：Closed（Z10/V04/V05 全绿后） *)
```

### V06-验收判据
1. 四关＋LINT 过；双套证书族 cert 绿；双档分派完备性（两 tier 全查）在案。
2. 席时带 2-4；P10/P11/C4 消费位普查 ≥3。

---

# ⑥ · 段级验收·反验证锚·未竟事项

## 段级验收（工单 §1.2 验收项对应）
1. **四稿齐全**：本段 28 节点×4 稿＝112 件在案（§③ 12×4＋§④ 10×4＋§⑤ 6×4）·翻转簇 22（吸收式·研读卡全挂实核坐标）＋维持簇 6（从零·数学命题卡全挂 R6 复审条件）。
2. **抽检稿提名（每段 ≥3·fresh 复核候选）**：P08（两件互证映射最重件）·Z05（ZFR 主定理·952320 链）·V04（世界首例主阵地从零件）——复核员可对 AFP Perrons_Formula.thy/Zeta_Zerofree.thy 行号与本稿坐标逐点重核（全部本会话实读·无转抄未核坐标）。
3. **吸收系数抽验**：§② 重映射账·复核 WebFetch 先例件即可复算（正典加权 P 块 0.42/Z 块 0.41·映射表给 0.425/0.40·同带）。
4. **施工序提示（映射表 §③-4 子序）**：P03→P08/P09→P07/P04/P05→P10/P11/P12→P01/P02→P06（骨架先行·定义殿后）·**波号施工仍以规范 §3.4 机械表为准**（波序=依赖序·子序=波内优先序·两者不冲突）。

## 反验证锚
```bash
ls "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C3.md"                    # 本稿在盘
grep -c "研读卡" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C3.md"      # ≥22（翻转簇四稿一）
grep -c "REPL 预演脚本" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C3.md" # ≥28（四稿三·逐节点）
grep -c "数学命题卡" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C3.md"  # ≥6（维持簇四稿一）
ls "D:/ComplexAnalysis/attn/kbgamma_work_20261101/prec_fetch/"                     # fetch 遗物（pntwr/＋mathlib/strongpnt 件）
grep -c "V07" "D:/ComplexAnalysis/attn/kbgamma_work_20261101/drafts_C3.md"         # 跳过登记位＝4（席头辖属账＋§⑤ 块头＋本锚命令行自指＋§⑥ 未竟·零四稿正文）
```

## 未竟事项（fail-loud·候施工席/闸 1）
1. **零编译**：REPL 预演脚本全数未执行（工单 §1.3 冻结令·>60s 编译形态禁入）——四关四件套为 γ3 施工席义务。
2. **R 值/c₁ 值/文献坐标选定**：Z05 R 候选（Ford/Mossinghoff–Trudgian/Kadiri）·V04 c₁ 候选（Kadiri–Lumley/Ford）·Z05/V03 文献坐标（Titchmarsh/M-V/Dusart/Karatsuba–Korobov）——cards 自注「R4 复核」·本席禁猜禁代选·施工席 fetch-before-cite 定谳。
3. **mathlib 未读件**：Convergence/RiemannZeta/DirichletContinuation/PhragmenLindelof/EulerProduct 三件/PNT+ 第三线——尺寸核实内容未读（§① 未 fetch 清单）·其消费归 γ2 上游节点（C2.1-C2.4）·非本段语句面直接依赖。
4. **μ(n) 承载缺口**（Z08 主路裁定已避让·Möbius 备选回切登记）。
5. **2π 周期归约断点**（KB36R :149·P05/V01 消费位）——C1.4 残件落装时点（γ1 波）联动·落装即复勘。
6. **V07-V18**：γ4 辖·本席零四稿（裁 1）·规范 §3.5 预留槽警示原文适用。

——C3 段四稿勘形完（20261101·勘形员·C3·零编译零写树·28 节点 112 稿·吸收式 22/从零 6·fetch-before-cite 全程实录·VK 残 12 跳过登记候 γ4）
