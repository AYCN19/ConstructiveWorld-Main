// y 系列 γ 段·可选施工工作流样板（20261108 铸）
// ⚠ 现状：C2.3 六件与 C3-P08 已由王小雪在协调台登记在铸，她有自有施工流程。本样板只供日后没有自有流程的施工方参考，勿与在铸节点重复派工。
// 内容：P08 Perron 截断公式 ∥ C2.3 η 延拓波（C2.06∥C2.09 → C2.07 → C2.08 → C2.10 → GaC2_Iface_Eta）∥ 三个文献复审钩
// 前提：①本包根目录作为 ZCode 工作区打开；②50_toolkit/config.example.json 已复制为 50_toolkit/config.json 并按本机填好；
//       ③先读 01_施工方自验说明。提交方式：CreateWorkflow，path 指向本文件。
// 验收一律由 world.run 调 50_toolkit/accept_node.py 判定；子智能体只写节点文件，不自判通过。

interface NodeResult {
  /** 节点号，如 C3-P08、C2.06 */
  node: string;
  /** 本轮写入或修改的节点文件名（只写文件名，文件放在 work_dir/nodes/ 下） */
  files: string[];
  /** 文件中陈述的主定理名（Print Assumptions 审计名单；Iface 件可为空） */
  theorems: string[];
  /** 一句话：本轮完成到哪一步 */
  status: string;
  /** 阻塞项；没有就写「无」 */
  blockers: string[];
  /** 判据来源：加载的技能与读过的卡面条目 */
  standards: string;
}
interface NodeOutcome {
  node: string;
  accepted: boolean;
  rounds: number;
  files: string[];
  theorems: string[];
  gateTail: string;
  blockers: string[];
}
interface LitHook {
  /** 复审钩编号：H-1 / H-2 / H-3 */
  hook: string;
  /** 定谳一句话；取不到写「未定谳：卡在…」 */
  verdict: string;
  /** A＝一手逐字实取；B＝沿用未复核；C＝只有搜索摘要 */
  grade: "A" | "B" | "C";
  /** 证据：URL＋版本锚＋逐字摘录（≤600 字/条） */
  evidence: string[];
  notCovered: string[];
}
interface LitPack {
  hooks: LitHook[];
  standards: string;
}
interface ReviewItem {
  node: string;
  /** 语句忠实于卡面、红线守住、依赖方向正确，三者都满足才是 true */
  pass: boolean;
  /** 问题清单，带文件名:行号 */
  issues: string[];
}
interface ReviewPack {
  items: ReviewItem[];
  standards: string;
}
interface Finding {
  where: string;
  what: string;
  evidence: string;
  status: "verified" | "unconfirmed";
  severity: "low" | "medium" | "high";
}
interface WorkflowReport {
  conclusion: string;
  findings: Finding[];
  verified: string[];
  notCovered: string[];
}

const CFG = "50_toolkit/config.json";

artifact.table("e1board", {
  title: "E1 外派·节点验收台账",
  columns: [
    { field: "node", label: "节点" },
    { field: "accepted", label: "六道链" },
    { field: "rounds", label: "轮次" },
  ],
  key: "node",
});

phase("自检：数据包完整性与 9.3 环境");
const pkg = await world.run("python", ["50_toolkit/verify_pkg.py"], { timeoutMs: 600000, output: { tail: 8192 } });
const env = await world.run("python", ["50_toolkit/env_check.py", "--config", CFG], { timeoutMs: 1800000, output: { tail: 8192 } });
if (pkg.exitCode !== 0 || env.exitCode !== 0) {
  const r: WorkflowReport = {
    conclusion: "自检未过，未施工。先按输出修好数据包或环境再重跑。",
    findings: [{ where: "50_toolkit", what: "数据包或环境自检失败", evidence: (pkg.stdout + "\n" + env.stdout + "\n" + env.stderr).slice(-3000), status: "verified", severity: "high" }],
    verified: ["verify_pkg.py rc=" + pkg.exitCode, "env_check.py rc=" + env.exitCode],
    notCovered: ["准备与施工全部未执行"],
  };
  return r;
}
const cfg = JSON.parse(await files.read(CFG));
const NODES = String(cfg.work_dir) + "/nodes";

phase("准备：编译存档依赖链并逐件复核");
const prep = await world.run("python", ["50_toolkit/build_deposit.py", "--config", CFG, "--chk"], { timeoutMs: 43200000, output: { tail: 16384 } });
if (prep.exitCode !== 0) {
  const r: WorkflowReport = {
    conclusion: "存档依赖链编译或复核未过，未施工。",
    findings: [{ where: "50_toolkit/build_deposit.py", what: "依赖链准备失败 rc=" + prep.exitCode, evidence: prep.stdout.slice(-4000), status: "verified", severity: "high" }],
    verified: ["verify_pkg.py 通过", "env_check.py 通过"],
    notCovered: ["施工、复审未执行"],
  };
  return r;
}
log("存档依赖链已编译并逐件 coqchk 复核，开始三线并发");

const DISCIPLINE =
  "【第零步·两道】①技能：用 Skill 工具加载 cw-ci-sop、coq-toy-replacement、cw-tail-supply；本机若没有这三个技能，改读包内 40_skills/ 下同名的 SKILL-*.md，判据按其口径。②经验条目：读 20_specs/cards_*.md 与 drafts_*.md 里本节点的研读卡、坑位、验收判据段，以及 01 施工方自验说明 §6 已知问题；用到的写进 standards。\n" +
  "【只写一个地方】节点文件只写进 work_dir/nodes/（路径见下）；禁止修改 30_sources/、10_data/、20_specs/、work_dir/build/；禁 git 写；禁 taskkill；禁装卸软件。\n" +
  "【编译与预检】编译只用 `python 50_toolkit/build_deposit.py --config 50_toolkit/config.json --targets <模块名>`（已含温控配置）；预检可用 `python 50_toolkit/accept_node.py --config 50_toolkit/config.json --node <节点> --files <文件…> --static`。最终通过与否由工作流脚本跑完整验收判定，你不要自报通过。不要用 coqtop 交互模式喂脚本（E952：输出不刷新）。\n" +
  "【红线】①承载位一律 Set 形：数据见证用 sig/sigT/sumbool，禁用 Prop 的 ∃/∨ 承载数据（C3 红 2 判例）。②零全局假设：禁 Axiom/Parameter/Conjecture；常数假设走 Section 内 Hypothesis（GAPASUME 槽）并在 End 出节，Print Assumptions 必须 Closed under the global context。③R2：证明面文件禁 vm_compute/native_compute/vm_cast_no_check/Compute，数值事实落同名 _cert.v，证明面单向 Require 证书面。④单文件 ≤400 行，超了按引理簇拆 _a/_b（同波互不 Require）。⑤依赖单向：跨段只经 GaC<k>_Iface_*，且只向低段；非 Iface 文件禁 Require Export。⑥头注两段式＋五字段英文（Mission./Dependencies./References./Constructivity./Build.），全文 CJK=0，不出现 Admitted/admit/sorry/TODO 等字面。⑦语句忠实于卡面数学命题，禁止为了过闸改弱语句。\n" +
  "【诚实】检查无法通过、卡面与依赖件互相矛盾、或依赖件缺失时，直接在 blockers 里写清卡在哪，不要绕过。";

phase("三线并发：P08 ∥ C2.3 η 延拓波 ∥ 文献复审");

async function buildNode(builder: Agent, node: string, brief: string): Promise<NodeOutcome> {
  let feedback = "首轮，无反馈。";
  let files: string[] = [];
  let theorems: string[] = [];
  let blockers: string[] = [];
  for (let round = 1; round <= 4; round++) {
    const r = await builder.ask<NodeResult>(
      `${DISCIPLINE}\n\n节点文件目录（work_dir/nodes）：${NODES}\n\n${brief}\n\n【上一轮验收反馈】\n${feedback}`,
    );
    files = r.files;
    theorems = r.theorems;
    blockers = r.blockers;
    if (r.files.length === 0) {
      report({ node, accepted: "未交付", rounds: round }, "e1board");
      return { node, accepted: false, rounds: round, files, theorems, gateTail: "施工员未交付文件：" + r.status, blockers };
    }
    const gate = await world.run(
      "python",
      ["50_toolkit/accept_node.py", "--config", CFG, "--node", node, "--files", ...r.files, "--theorems", ...r.theorems],
      { timeoutMs: 21600000, output: { tail: 16384 } },
    );
    if (gate.exitCode === 0) {
      report({ node, accepted: "通过", rounds: round }, "e1board");
      return { node, accepted: true, rounds: round, files, theorems, gateTail: gate.stdout.slice(-2500), blockers };
    }
    feedback = ("退出码 " + gate.exitCode + "\n" + gate.stdout + "\n" + gate.stderr).slice(-6000);
  }
  report({ node, accepted: "未过（4 轮）", rounds: 4 }, "e1board");
  return { node, accepted: false, rounds: 4, files, theorems, gateTail: feedback, blockers };
}

const BRIEF_P08 =
  "【本席】C3-P08 · Perron 截断公式（有限 T 竖线积分＝ψ(x)−误差），C3 段 W2。\n" +
  "主文件 GaC3_P08_PerronCutoff.v；有数值常数证书则另建 GaC3_P08_PerronCutoff_cert.v。\n" +
  "必读：20_specs/cards_C3.md 第 93-102 行（数学命题卡）；20_specs/drafts_C3.md 第 419-466 行（研读卡、语句面稿、验收判据）；20_specs/gamma_module_spec.md §2-§4。\n" +
  "依赖（存档件，准备阶段已编译）：GaC3_P01_LineIntegralDef（复线积分）、GaC3_P07_PowerGrowth（x^s/s 增长）、GaC3_Z01_LogDerivSeries（−ζ'/ζ 的 Dirichlet 级数面）；跨段经 GaC2_Iface_DS（绝对收敛与尾界）、GaC1_Iface_Cx。卡面前置写作区间「P01-P07」：若确需 GaC3_P03_MLEstimate（ML 估计）或 P04-P06 的面，可以 Require，但按 spec §6 附记②把 P08 波号加深并在 blockers 里登记，禁止在本件重抄 ML 估计。\n" +
  "目标形态：绝对收敛区（c>1）上，截断竖线积分与 ψ(x) 之差有显式误差界，常数以 ℚ 字面落在 _cert.v。\n" +
  "对标（只对照语句形状与常数结构；禁止照搬经典证明、禁止引入经典公理）：10_data/r2_evidence/L2/E03_perron_formula.md（Song–Yao 修订版 Perron 公式）、10_data/r2_evidence/L2/E05_eberl_perrons_formula.md（Eberl 显式截断常数）。";
const BRIEF_06 =
  "【本席】C2.06 · 交错项单调面（n^{-σ} 递减→0·一致形），C2 段 W1（C2.3 η 延拓块第一件）。\n" +
  "文件 GaC2_06_AltMonoFace.v。必读：20_specs/cards_C2.md 第 87-96 行；20_specs/drafts_C2.md 第 491-551 行；spec §2-§4。\n" +
  "依赖：段内无；跨段经 GaC1_Iface_Real（C1.1 实有效界）。\n" +
  "背景：C2.06-C2.10 是 Z03 及其后全部零点自由区节点的前置——ζ 在 Re s=1 上的取值要靠 C2.10 的 η 延拓；本块目前全盘零文件。";
const BRIEF_09 =
  "【本席】C2.09 · 分母零点刻画（1−2^{1−s} 零点集·周期性缺口件），C2 段 W1。\n" +
  "文件 GaC2_09_DenomZeroSet.v。必读：20_specs/cards_C2.md 第 117-126 行；20_specs/drafts_C2.md 第 691-760 行；spec §2-§4。\n" +
  "依赖：跨段经 GaC1_Iface_Cx（C1.4 c_exp/c_log）。卡册登记过 CxRealPairExpLog 无 2π 周期性项（周期性缺口）：先查存档件 GaC1_17_TwoPiPeriod（经 GaC1_Iface_Cx 转供，见该件头注；准备阶段已逐件 coqchk 复核）能否供给，再决定是否需要新铸辅助引理。注意：drafts_C2.md:713 稿面 Require 头里的 GaC2_08_EtaZetaRelation 一行系草稿笔误（C2.09 依赖正典＝无 γ 内前置，同块挂卡行自证），勿照抄。";
const BRIEF_07 =
  "【本席】C2.07 · Dirichlet 判别法构造性化（Abel 分部＋显式尾界），C2 段 W2。\n" +
  "文件 GaC2_07_DirichletTestAbel.v。必读：20_specs/cards_C2.md 第 97-106 行；20_specs/drafts_C2.md 第 552-627 行。\n" +
  "依赖：GaC2_01_DirichletPartialSum（段内低波直依）、GaC2_06_AltMonoFace（本工作流上一件，已验收）；跨段柯西承载机经 GaC1_Iface_Cx（C1-14 部分和柯西承载形，见稿 Require 头 drafts_C2.md:572）。";
const BRIEF_08 =
  "【本席】C2.08 · η-ζ 代数关系（部分和恒等式·含显式修正项），C2 段 W3。\n" +
  "文件 GaC2_08_EtaZetaRelation.v。必读：20_specs/cards_C2.md 第 107-116 行；20_specs/drafts_C2.md 第 628-690 行。\n" +
  "依赖：GaC2_02_AbsConvTailBound、GaC2_07_DirichletTestAbel（已验收）。";
const BRIEF_10 =
  "【本席】C2.10 · 延拓良定与解析面（ζ̃:=η/(1−2^{1−s}) 于 Re s>0），C2 段 W4。\n" +
  "文件 GaC2_10_EtaContinuation.v（数值常数另建 _cert.v）。必读：20_specs/cards_C2.md 第 127-138 行；20_specs/drafts_C2.md 第 761-825 行。\n" +
  "依赖：GaC2_07_DirichletTestAbel、GaC2_08_EtaZetaRelation、GaC2_09_DenomZeroSet（均已验收）；跨段收敛机经 GaC1_Iface_Cx（C1-14/C1-15 局部一致收敛与双级数承载形·本卡最大消费方，见稿 Require 头 drafts_C2.md:782）。这是 Z03 的直接前置：做完后 ζ(1+it) 才有定义。";
const BRIEF_IFACE =
  "【本席】C2.3 波末接口片 GaC2_Iface_Eta.v。\n" +
  "只含 Require Import/Export 与具名项索引注释，零证明体零定义体；只转供 C2.06-C2.10 五件（spec §2.3 表）；转供数 ≤16；头注五字段同上。照存档里的 GaC2_Iface_DS.v 写法。";

const lineA = buildNode(agent("施工员·P08"), "C3-P08", BRIEF_P08);
const lineB = future(async () => {
  const main = agent("施工员·C2.3 主链");
  const pair = await Promise.all([
    buildNode(main, "C2.06", BRIEF_06),
    buildNode(agent("施工员·C2.09"), "C2.09", BRIEF_09),
  ]);
  const outs: NodeOutcome[] = [pair[0], pair[1]];
  if (!pair[0].accepted) return outs;
  const n07 = await buildNode(main, "C2.07", BRIEF_07);
  outs.push(n07);
  if (!n07.accepted) return outs;
  const n08 = await buildNode(main, "C2.08", BRIEF_08);
  outs.push(n08);
  if (!n08.accepted || !pair[1].accepted) return outs;
  const n10 = await buildNode(main, "C2.10", BRIEF_10);
  outs.push(n10);
  if (!n10.accepted) return outs;
  const iface = await buildNode(main, "C2-Iface-Eta", BRIEF_IFACE);
  outs.push(iface);
  return outs;
});
const lineC = agent("文献复审员").ask<LitPack>(
  "【本席】文献复审员：只读，不写任何项目文件；一手证据摘录存到 " + String(cfg.work_dir) + "/lit_evidence/ 下（每条一个 .md，文件头写来源 URL、版本锚、取件时间）。\n" +
  "第零步：加载 cw-deep-mining（没有就读 40_skills/SKILL-cw-deep-mining.md）；先读 10_data/回执-y文献考古第二轮差量报告-20261108.md 的 §1、§8、§10，弄清上一轮卡在哪。\n" +
  "精度规则：形式化先例只认源文件逐字陈述＋path:line＋commit sha；常数写清方向与适用域，不并分数；raw.githubusercontent.com 会静默截断，用 GitHub contents API（可带你自己的 token；匿名每小时 60 次，注意节流）；付费墙不重试；禁猜 ID、DOI、定理名。\n" +
  "H-1：arXiv 2603.21490 正文与 PNT+ 上游（AlexKontorovich/PrimeNumberTheoremAnd）IEANTN/ZetaSummary.lean 里的「BTY 4.896」是否同源；4.896 的确切定理、适用域（t≥3 还是 |t|≥2）、有条件还是无条件。据此判 MTY 5.558691 是否仍是已发表的最优 dVp 常数。\n" +
  "H-2：OscInt 先例表列出的 rwst/lean-code、TomasOrtega/Sidon、roos-j/lean-discretesw 三仓，有没有指数和型 van der Corput（A 过程 / Weyl 差分不等式）的形式化，常数是否显式；逐字摘陈述。据此判「Lean 中指数和型 vdC 显式常数未见先例」能否成立。\n" +
  "H-3：openai/math 仓 Family 003 的解答文件 lean/OAI/NumberTheory/DirichletL/Nonvanishing.lean（约 1247 字节）所 import 的证明模块：统计 sorry/axiom，找有无 `#print axioms` 或 CI 公理审计输出；AxiomMath/DedekindZetaZeroFree 有无新的公理审计或独立复核。只判形式化里证了什么、靠什么，不判数学真假。\n" +
  "返回 LitPack，三个钩每个至少一条 hooks 记录。",
);
const joined = await Promise.all([lineA, lineB, lineC]);
const outA = joined[0];
const outB = joined[1];
const lit = joined[2];
const allNodes: NodeOutcome[] = [outA, ...outB];

phase("独立复审与回执");
const passed = allNodes.filter((o) => o.accepted);
const review: ReviewPack =
  passed.length > 0
    ? await agent("独立复审员").ask<ReviewPack>(
        "你是独立复审员，没参与施工。第零步：加载 cw-ci-sop、cw-tail-supply（没有就读 40_skills/ 下同名卷）。\n" +
          "下面是验收脚本已判通过的节点、文件（在 " + NODES + "）与脚本输出尾部（含 REVIEW 项）：\n" +
          JSON.stringify(passed.map((o) => ({ node: o.node, files: o.files, theorems: o.theorems, gateTail: o.gateTail })), null, 1) +
          "\n逐件对照 20_specs 的卡面与草稿判三件事：①语句是否忠实于卡面数学命题（有没有改弱、加了不该有的前提）；②红线：承载位是否 Set 形、GAPASUME 槽是否只是常数假设而不是把要证的东西当前提；③依赖方向与 spec §2.4 一致。脚本输出里的 REVIEW 项逐条给结论。禁止修改任何文件。返回 ReviewPack。",
      )
    : { items: [], standards: "无验收通过件，未复审" };

const rows = allNodes.map(
  (o) => "| " + o.node + " | " + (o.accepted ? "通过" : "未过") + " | " + o.rounds + " | " + o.files.join(", ") + " | " + (o.blockers.join("；") || "无") + " |",
);
const md = [
  "# E1 外派回执：P08 ∥ C2.3 η 延拓波 ∥ 文献复审钩",
  "",
  "## 节点验收（六道链由 accept_node.py 判定）",
  "",
  "| 节点 | 六道链 | 轮次 | 文件 | 阻塞 |",
  "|---|---|---|---|---|",
  ...rows,
  "",
  "## 独立复审",
  "",
  ...review.items.map((i) => "- " + i.node + "：" + (i.pass ? "通过" : "不通过") + (i.issues.length ? "——" + i.issues.join("；") : "")),
  "",
  "## 文献复审钩",
  "",
  ...lit.hooks.map((h) => "- " + h.hook + "（" + h.grade + "）：" + h.verdict),
  "",
  "## 产物位置",
  "",
  "- 节点文件：" + NODES,
  "- 验收 JSON：" + String(cfg.work_dir) + "/accept/",
  "- md5 账：" + String(cfg.work_dir) + "/ledger/md5_ledger.txt",
  "- 编译与复核日志：" + String(cfg.work_dir) + "/logs/",
  "- 文献证据：" + String(cfg.work_dir) + "/lit_evidence/",
].join("\n");
await artifact.markdown("receipt", md, { title: "E1 外派回执", description: "P08、C2.3 延拓波各节点六道链验收、独立复审与文献复审钩结论", primary: true });

const findings: Finding[] = [];
for (const o of allNodes) {
  if (!o.accepted) {
    findings.push({ where: o.node, what: "节点未通过六道链验收（" + o.rounds + " 轮）", evidence: o.gateTail.slice(-1500), status: "verified", severity: "high" });
  }
}
for (const i of review.items) {
  if (!i.pass) {
    findings.push({ where: i.node, what: "独立复审不通过", evidence: i.issues.join("；").slice(0, 1500), status: "unconfirmed", severity: "high" });
  }
}
for (const h of lit.hooks) {
  findings.push({ where: "文献 " + h.hook, what: h.verdict, evidence: h.evidence.join(" | ").slice(0, 1500), status: h.grade === "A" ? "verified" : "unconfirmed", severity: "medium" });
}
const result: WorkflowReport = {
  conclusion:
    "E1 外派完成：" + passed.length + "/" + allNodes.length + " 个节点通过六道链验收（P08 " + (outA.accepted ? "通过" : "未过") +
    "；C2.3 波 " + outB.filter((o) => o.accepted).length + "/" + outB.length + "）；独立复审 " + review.items.filter((i) => i.pass).length + "/" + review.items.length +
    " 通过；文献复审钩 " + lit.hooks.length + " 条。",
  findings,
  verified: [
    "verify_pkg.py：数据包清单逐件 md5 一致",
    "env_check.py：coqc/coqchk 9.3.0、L0 .vo 对 925d454 参照逐件一致、魔数 90300",
    "build_deposit.py --chk：存档依赖链编译并逐件 coqchk -o -bytecode-compiler yes -norec",
    "accept_node.py：每个节点 lint＋gate4＋编译＋coqchk -norec＋Print Assumptions＋md5 账",
  ],
  notCovered: [
    "Z03 不在本轮：前置 C2.10 本轮才铸，Z03 须在 GaC2_Iface_Eta 通过后另派",
    "L0（Main 1020 模块）按 #19 att2 认证＋md5 对表信任，未在外派机重跑 coqchk",
  ],
};
return result;
