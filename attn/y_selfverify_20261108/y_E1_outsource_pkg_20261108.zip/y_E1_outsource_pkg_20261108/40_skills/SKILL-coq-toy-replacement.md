---
name: coq-toy-replacement
description: "Coq/Rocq 玩具级定理非平凡替换方法论。当需要在 Coq/Rocq 代码库中扫描、筛选并替换玩具级（TOY_STRONG/TOY_LIGHT）定理证明为非平凡实现时使用。覆盖微刀正体三式、不可化四类定谳、编译通路选择、金标代理筛分工法、质量验收四证、环境坑卡体系。适用于 Rocq/Coq 9.1.0 环境、Set 层构造性证明、逐件同名替换工作流。"
---

# Coq/Rocq 玩具级定理非平凡替换方法论

## 核心理念

将代码库中「玩具级」证明（单跳转发/reflexivity/定义性收口）替换为实质非平凡证明（定义层展开/显式 witness/结构性推导），同时严格保持语句面零改动、声明序不变、零新增 Require。

**红线**：不产假非平凡（把单跳拆成等价多行=注水）；不可化处如实标注不硬编；纯构造性 Set 层禁 Prop 泄露。

## 第一步：扫描与判级

用扫描器对目标 .v 文件做玩具定理判级：

```
TOY_STRONG = 证明 ≤2 步全平凡 tactic（单跳 apply / reflexivity / 转发）
TOY_LIGHT  = ≤5 步无重武器（无 induction / rewrite 链 / assert 等结构）
NONTRIVIAL = 其余（含 bullets / setoid / lia 等结构步）
ADMITTED   = 红线另案（出现即标记）
```

扫描器核心逻辑：剥嵌套注释 → 定理块状态机（声明面 → Proof. → 证明体 → Qed./Defined.）→ 证明句切分 → 判级。

**判级双判例**（防误判/防漏判）：
- 单句全显式 apply / 单 exact 确定性洞 = **已实质**，不烧刀
- 裸 `reflexivity` / 裸 `apply id_refl` = **真玩具**，可微刀化

## 第二步：筛分与定性

对每个玩具槽做三方比对定性（落件/Main 现版/vo_9.1 旧版）：

- **真可化未落地** → 落刀
- **恒等守恒**（刀体=原体）→ 标注结案
- **不可化四类** → 批量标注：
  1. 接口字段直转发（语句面即假设面）
  2. 判别语义（构造子互斥无多行路径）
  3. 单点序事实（改写即伪非平凡）
  4. 定义性收口（reflexivity 即定义展开）

**防误判**：「先勘母本体再判桥位」——放电母本多为装法 δ 面 reflexivity，可就地直造消转发，勿误判为接口桥位不可化。

## 第三步：落刀

### 微刀正体三式

| 层 | 原体 | 正体 |
|---|---|---|
| Q 层 | `reflexivity.` | `exact (Qeq_refl <右端显式项>).` |
| Set 层 Id | `apply id_refl.` | `exact (@id_refl _ <右端显式项>).` |
| Z 层 ι-计算 | `reflexivity.` | `exact (@eq_refl _ (Z.pos * Z.pos)%Z).` |

显式项从声明/定义面勘真形——非照抄占位符。

### 融合刀法

| 刀法 | 原体 | 正体 |
|---|---|---|
| 全参显式单 exact | 多段 apply/exact 链 | 单项 `exact (引理 <全参>).` |
| 定义层 unfold | 转发引理 | `unfold <定义名>.` + 直构 |
| 结构性归纳 | 列表/归纳引理转发 | `induction` 原地重演（nil/cons 分判） |
| 载体归纳换形 | sumd_list_sum 族 | `revert s0; induction l; intros s0; simpl`（IH 升格 forall） |
| Or 拆支 | lt_le_iff 转发 | `destruct` + lt/eq 支分别直构 |
| 存在 witness | 转发 existence | `exists <闭项>.` + 分步证 |

### 落刀执行规则

**禁手抄 heredoc**——用程序直取金标准文本+断言同文：

```python
# 手术脚本核心断言
assert text.count(old_body) == 1          # 唯一性
assert stmt_o == stmt_p                     # 语句面零改
assert len(new_body) > len(old_body)        # 替换体增长
assert text_new.count("(") == text_new.count(")")  # 括号配平
assert new_body in text_after               # 同文断言
```

**编译判绿四证**：
1. `rocq c` rc=0 ∧ 零 Error/Anomaly/inconsistent
2. .vo mtime > .v（非 stub）
3. Print Assumptions 全 `Closed under the global context`、Axioms 零命中
4. 落件↔室件 cmp 逐字 SAME

### 不可化四类批量标注

| 类 | 判据 | 处置 |
|---|---|---|
| 接口字段直转发 | 语句面即假设面，无定义面可展 | 批量标注「接口字段直转发」 |
| 判别语义 | 构造子互斥无多行路径 | 批量标注「判别语义边界」 |
| 单点序事实 | 改写即伪非平凡 | 批量标注「单点序事实」 |
| 定义性收口 | reflexivity 即定义展开 | 批量标注「定义性收口」 |

## 第四步：编译验证

### 编译通路选择

| 场景 | 通路 |
|---|---|
| 首选（CI 认证） | vo_ci_cache 只读锁定 `-Q vo_ci_cache ""`（602 .vo 隔壁认证） |
| 替代 | 现状树直编（vo_9.1 现状树 `-Q` 单根；降级口径不绿不阻塞） |
| 深依赖 | 净室分室（池底残留 .vo 撞库防）或影室（APFS cp -cR 克隆+池编顶替） |
| ⚠ 禁用 | `Live/vorebuild_901`（异 Stdlib 摘要，-Q 即报 inconsistent） |

### 编译验证降级口径

可用旧信任缓存直接编译；摘要失配/Inconsistent 不再阻塞交付（终局全库重编修复）。编译降为尽力而为旁证（假绿核查照旧 .vo mtime+体量非空）；刀位质量纪律不变。

### 假绿防线

- .vo mtime > .v（非 stub）
- 体量 ≥ 数 KB（非空壳）
- `rocq check` 单件隔离锚（裸模块名）
- Print Assumptions 全 Closed / Axioms 零命中

## 第五步：质量验收

- count==1（旧体唯一锚）
- Qed/Defined 计数守恒
- Require 面零改
- 语句面与原件零差
- 五禁词全零（Axiom/Admitted/Parameter/Conjecture/Abort）
- CRLF/LF 保真（newline='' 读写）
- 落件↔室件 cmp 逐字 SAME
- 证伪即回退双记

## 环境坑卡速查

| 坑 | 处方 |
|---|---|
| Qle_to_QleT' 显式值参居前须垫 `_` | `exact (Qle_to_QleT' _ _ H)` |
| real_eq 系逐点逼近 Set 非 Id 别名 | witness = `real_eq_refl` |
| Qeq 系 Definition 无 destruct 代换力 | `setoid rewrite <-` |
| Qmult_comp 系 Instance 非 Lemma | 函数式调用三形态参序全雾 |
| Qle_bool 系 S02 遮蔽件 | 全限定 `S02_CauchyComplete.Qle_bool` |
| lt_le_iff 的 Or = S01:67 自定义 Set 层和型别名 | 复刻类块必带 |
| plus_assoc 反向形 | `Id (x+(y+z)) ((x+y)+z)` |
| Qeq_sym 实参序 | `sym x y (H:req x y) : req y x` |
| real_lt 系 sigT 依赖型 | 见证参须保内联 |
| prod 型投影 | `fst`/`snd` 非 proj1/proj2 |
| Id 系 S01 自设恒等型非原生 eq | discriminate/destruct 不通→J 消去型卫 |
| 单行 `Proof.…Qed.` | 驱程补 inline 闭合解析 |
| 模内件 Print Assumptions | 限定名 `Module.定理名` |
| `-Q . 文件名` | 文件名吃进 -Q 静默空转，正确形 `-Q . ""` |
| opam 默认 switch 901 陷阱 | env.sh source 后确认 9.1.0 |
| CRLF 保真 | `newline=''` 读写+字节写回 |
| 跨日 /tmp 易失 | 工池资产落持久区 |
| 长编进程 | setsid 脱进程组 |

## 参考文件

- 交接文档 `交接文档-20260924.md` 修订层 A-F：全役状态+坑卡精要+融合工艺规范
- 总册 `消融50/T244-ToyR战役总册.md`：全役滚动记录+五态终计+候裁决
- 白皮书 `融合工艺白皮书-同事成果融入规范-v1.0-20260924.md`：三融合法+闭包精算+冻结名单
- 批量落刀器：各席工池 `/tmp/toyr_work_*/` 下 make_toyr 系/knife 系/手术脚本
